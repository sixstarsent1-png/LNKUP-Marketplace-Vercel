<?php
/**
 * Application workflow.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Applications {

	/**
	 * Submit application.
	 *
	 * @param int    $opportunity_id Opportunity ID.
	 * @param int    $user_id        Vendor user ID.
	 * @param string $message        Application message.
	 */
	public static function submit( $opportunity_id, $user_id, $message = '' ) {
		$profile_id = lnkup_get_vendor_profile_id( $user_id );
		if ( ! $profile_id ) {
			return new WP_Error( 'no_profile', __( 'Create your vendor profile before applying.', 'lnkup-marketplace' ) );
		}

		$existing = get_posts(
			array(
				'post_type'      => 'lnkup_application',
				'posts_per_page' => 1,
				'meta_query'     => array(
					'relation' => 'AND',
					array( 'key' => '_lnkup_opportunity_id', 'value' => $opportunity_id ),
					array( 'key' => '_lnkup_vendor_user_id', 'value' => $user_id ),
				),
				'post_status'    => 'any',
			)
		);
		if ( $existing ) {
			return new WP_Error( 'duplicate', __( 'You already applied to this opportunity.', 'lnkup-marketplace' ) );
		}

		$opp = get_post( $opportunity_id );
		if ( ! $opp || 'lnkup_opportunity' !== $opp->post_type ) {
			return new WP_Error( 'invalid', __( 'Invalid opportunity.', 'lnkup-marketplace' ) );
		}

		$spots = (int) get_post_meta( $opportunity_id, '_lnkup_spots_remaining', true );
		if ( $spots <= 0 ) {
			return new WP_Error( 'full', __( 'No spots remaining.', 'lnkup-marketplace' ) );
		}

		$event_id      = (int) get_post_meta( $opportunity_id, '_lnkup_event_id', true );
		$organizer_id  = $event_id ? (int) get_post_meta( $event_id, '_lnkup_organizer_user_id', true ) : 0;
		$event         = $event_id ? get_post( $event_id ) : null;

		$app_id = wp_insert_post(
			array(
				'post_title'   => sprintf(
					/* translators: 1: vendor name, 2: event name */
					__( 'Application: %1$s → %2$s', 'lnkup-marketplace' ),
					wp_get_current_user()->display_name,
					$event ? $event->post_title : $opp->post_title
				),
				'post_type'    => 'lnkup_application',
				'post_status'  => 'publish',
				'post_content' => sanitize_textarea_field( $message ),
			)
		);

		if ( is_wp_error( $app_id ) ) {
			return $app_id;
		}

		update_post_meta( $app_id, '_lnkup_vendor_profile_id', $profile_id );
		update_post_meta( $app_id, '_lnkup_vendor_user_id', $user_id );
		update_post_meta( $app_id, '_lnkup_opportunity_id', $opportunity_id );
		update_post_meta( $app_id, '_lnkup_event_id', $event_id );
		update_post_meta( $app_id, '_lnkup_organizer_user_id', $organizer_id );
		update_post_meta( $app_id, '_lnkup_application_status', 'submitted' );
		update_post_meta( $app_id, '_lnkup_submitted_at', current_time( 'mysql' ) );

		LNKup_Notifications::send_application_submitted( $app_id );
		LNKup_Marketplace_Index::increment_applications( $opportunity_id );
		do_action( 'lnkup_application_submitted', $app_id );

		return $app_id;
	}

	/**
	 * Transition application status.
	 *
	 * @param int    $app_id Application ID.
	 * @param string $status New status.
	 * @param array  $extra  Extra data.
	 */
	public static function transition( $app_id, $status, $extra = array() ) {
		$status = LNKup_Security::sanitize_application_status( $status );
		$prev   = get_post_meta( $app_id, '_lnkup_application_status', true );

		update_post_meta( $app_id, '_lnkup_application_status', $status );

		if ( 'approved' === $status ) {
			update_post_meta( $app_id, '_lnkup_approved_at', current_time( 'mysql' ) );
			LNKup_Payments::create_from_application( $app_id );
			update_post_meta( $app_id, '_lnkup_application_status', 'payment_required' );
			update_post_meta( $app_id, '_lnkup_payment_due_at', gmdate( 'Y-m-d H:i:s', strtotime( '+7 days' ) ) );
			LNKup_Notifications::send_application_approved( $app_id );
		} elseif ( 'rejected' === $status ) {
			if ( ! empty( $extra['reason'] ) ) {
				update_post_meta( $app_id, '_lnkup_rejection_reason', sanitize_textarea_field( $extra['reason'] ) );
			}
			LNKup_Notifications::send_application_rejected( $app_id );
		} elseif ( 'waitlisted' === $status ) {
			LNKup_Notifications::send_application_waitlisted( $app_id );
		} elseif ( 'paid' === $status ) {
			if ( 'paid' === $prev ) {
				return true;
			}
			update_post_meta( $app_id, '_lnkup_paid_at', current_time( 'mysql' ) );
			LNKup_Packets::unlock_for_application( $app_id );
			LNKup_Notifications::send_payment_confirmed( $app_id );
			if ( class_exists( 'LNKup_Organizer_CRM' ) ) {
				LNKup_Organizer_CRM::log_activity(
					'packet_unlocked',
					(int) get_post_meta( $app_id, '_lnkup_organizer_user_id', true ),
					(int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true ),
					array( 'application_id' => $app_id, 'event_id' => (int) get_post_meta( $app_id, '_lnkup_event_id', true ) )
				);
			}
		}

		do_action( 'lnkup_application_status_changed', $app_id, $prev, get_post_meta( $app_id, '_lnkup_application_status', true ) );

		return true;
	}

	/**
	 * Allowed transitions for organizer actions.
	 *
	 * @param string $action Action.
	 */
	public static function handle_organizer_action( $app_id, $action, $user_id ) {
		if ( ! LNKup_Capabilities::user_owns_post( $app_id, $user_id, '_lnkup_organizer_user_id' ) && ! LNKup_Capabilities::user_has_manage_all( $user_id ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'lnkup-marketplace' ) );
		}

		$map = array(
			'approve'   => 'approved',
			'reject'    => 'rejected',
			'waitlist'  => 'waitlisted',
			'review'    => 'under_review',
		);

		if ( empty( $map[ $action ] ) ) {
			return new WP_Error( 'invalid', __( 'Invalid action.', 'lnkup-marketplace' ) );
		}

		$extra = array();
		if ( 'reject' === $action && ! empty( $_POST['rejection_reason'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$extra['reason'] = sanitize_textarea_field( wp_unslash( $_POST['rejection_reason'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		return self::transition( $app_id, $map[ $action ], $extra );
	}
}
