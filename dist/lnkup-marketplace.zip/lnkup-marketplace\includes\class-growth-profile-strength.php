<?php
/**
 * Vendor profile strength checklist.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Growth_Profile_Strength {

	public static function checklist( $user_id = 0 ) {
		$user_id    = $user_id ?: get_current_user_id();
		$profile_id = lnkup_get_vendor_profile_id( $user_id );
		$items      = array();

		$checks = array(
			'logo'           => array( 'label' => __( 'Logo', 'lnkup-marketplace' ), 'weight' => 8 ),
			'cover'          => array( 'label' => __( 'Cover Photo', 'lnkup-marketplace' ), 'weight' => 6 ),
			'gallery'        => array( 'label' => __( 'Gallery', 'lnkup-marketplace' ), 'weight' => 8 ),
			'description'    => array( 'label' => __( 'Description', 'lnkup-marketplace' ), 'weight' => 8 ),
			'products'       => array( 'label' => __( 'Products', 'lnkup-marketplace' ), 'weight' => 6 ),
			'categories'     => array( 'label' => __( 'Categories', 'lnkup-marketplace' ), 'weight' => 8 ),
			'cities'         => array( 'label' => __( 'Cities', 'lnkup-marketplace' ), 'weight' => 5 ),
			'website'        => array( 'label' => __( 'Website', 'lnkup-marketplace' ), 'weight' => 4 ),
			'instagram'      => array( 'label' => __( 'Instagram', 'lnkup-marketplace' ), 'weight' => 3 ),
			'phone'          => array( 'label' => __( 'Phone', 'lnkup-marketplace' ), 'weight' => 4 ),
			'email'          => array( 'label' => __( 'Email', 'lnkup-marketplace' ), 'weight' => 3 ),
			'insurance'      => array( 'label' => __( 'Insurance', 'lnkup-marketplace' ), 'weight' => 8 ),
			'license'        => array( 'label' => __( 'License', 'lnkup-marketplace' ), 'weight' => 6 ),
			'health_permit'  => array( 'label' => __( 'Health Permit', 'lnkup-marketplace' ), 'weight' => 6 ),
			'tax_documents'  => array( 'label' => __( 'Tax Documents', 'lnkup-marketplace' ), 'weight' => 5 ),
			'reviews'        => array( 'label' => __( 'Reviews', 'lnkup-marketplace' ), 'weight' => 6 ),
			'verification'   => array( 'label' => __( 'Verification', 'lnkup-marketplace' ), 'weight' => 6 ),
		);

		foreach ( $checks as $key => $meta ) {
			$done = self::check_item( $key, $profile_id, $user_id );
			$items[] = array(
				'key'      => $key,
				'label'    => $meta['label'],
				'weight'   => $meta['weight'],
				'complete' => $done,
				'tip'      => $done ? '' : self::tip_for( $key ),
			);
		}
		return $items;
	}

	public static function score( $user_id = 0 ) {
		$items  = self::checklist( $user_id );
		$total  = 0;
		$earned = 0;
		foreach ( $items as $item ) {
			$total += (int) $item['weight'];
			if ( $item['complete'] ) {
				$earned += (int) $item['weight'];
			}
		}
		$pct = $total ? (int) round( ( $earned / $total ) * 100 ) : 0;
		return array(
			'score'      => $pct,
			'items'      => $items,
			'incomplete' => array_values( array_filter( $items, function ( $i ) { return ! $i['complete']; } ) ),
		);
	}

	private static function check_item( $key, $profile_id, $user_id ) {
		if ( ! $profile_id ) {
			return false;
		}
		switch ( $key ) {
			case 'logo':
				return (bool) get_post_thumbnail_id( $profile_id );
			case 'cover':
				return (bool) get_post_meta( $profile_id, '_lnkup_cover_image_id', true );
			case 'gallery':
				$gallery = get_post_meta( $profile_id, '_lnkup_gallery_ids', true );
				return is_array( $gallery ) && count( $gallery ) >= 2;
			case 'description':
				$p = get_post( $profile_id );
				return $p && strlen( wp_strip_all_tags( $p->post_content ) ) > 50;
			case 'products':
				return (bool) get_post_meta( $profile_id, '_lnkup_products', true );
			case 'categories':
				$terms = wp_get_post_terms( $profile_id, 'lnkup_vendor_category' );
				return ! is_wp_error( $terms ) && count( $terms ) > 0;
			case 'cities':
				return (bool) get_post_meta( $profile_id, '_lnkup_city', true );
			case 'website':
				return (bool) get_post_meta( $profile_id, '_lnkup_website', true );
			case 'instagram':
				return (bool) get_post_meta( $profile_id, '_lnkup_instagram', true );
			case 'phone':
				return (bool) get_post_meta( $profile_id, '_lnkup_phone', true );
			case 'email':
				$user = get_userdata( $user_id );
				return (bool) get_post_meta( $profile_id, '_lnkup_email', true ) || ( $user && (bool) $user->user_email );
			case 'insurance':
				return self::doc_verified( $user_id, 'certificate_of_insurance' );
			case 'license':
				return self::doc_verified( $user_id, 'business_license' );
			case 'health_permit':
				return self::doc_verified( $user_id, 'health_permit' );
			case 'tax_documents':
				return self::doc_verified( $user_id, 'w9' ) || self::doc_verified( $user_id, 'sales_tax_certificate' );
			case 'reviews':
				$rep = LNKup_Vendor_Reputation::get( $profile_id );
				return (int) ( $rep['review_count'] ?? 0 ) > 0;
			case 'verification':
				$badges = LNKup_Vendor_Badges::get_active_slugs( $profile_id );
				return in_array( 'verified_vendor', $badges, true );
		}
		return false;
	}

	private static function doc_verified( $user_id, $type ) {
		foreach ( LNKup_Documents::get_for_vendor( $user_id ) as $doc ) {
			if ( $type === get_post_meta( $doc->ID, '_lnkup_document_type', true )
				&& 'verified' === get_post_meta( $doc->ID, '_lnkup_verification_status', true ) ) {
				return true;
			}
		}
		return false;
	}

	private static function tip_for( $key ) {
		$tips = array(
			'logo'          => __( 'Add a logo to build trust with organizers.', 'lnkup-marketplace' ),
			'gallery'       => __( 'Upload more photos to showcase your setup.', 'lnkup-marketplace' ),
			'categories'    => __( 'Add categories to improve match scores.', 'lnkup-marketplace' ),
			'insurance'     => __( 'Verified insurance speeds up approvals.', 'lnkup-marketplace' ),
			'verification'  => __( 'Complete verification to earn the Verified badge.', 'lnkup-marketplace' ),
		);
		return $tips[ $key ] ?? __( 'Complete this item to strengthen your profile.', 'lnkup-marketplace' );
	}
}
