<?php
/**
 * Marketplace cron jobs — notifications and trending refresh.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Marketplace_Cron {

	const HOOK_DAILY = 'lnkup_marketplace_daily';

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( self::HOOK_DAILY, array( __CLASS__, 'run_daily' ) );
		add_action( 'publish_lnkup_opportunity', array( __CLASS__, 'on_new_opportunity' ), 20, 2 );
		add_action( 'init', array( __CLASS__, 'sync_with_phase' ), 25 );
	}

	/**
	 * Schedule or clear cron based on marketplace phase (1C only).
	 */
	public static function sync_with_phase() {
		if ( lnkup_marketplace_phase_at_least( '1c' ) ) {
			self::schedule();
		} else {
			self::unschedule();
		}
	}

	/**
	 * Schedule cron on activation.
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK_DAILY ) ) {
			wp_schedule_event( time(), 'daily', self::HOOK_DAILY );
		}
	}

	/**
	 * Clear cron on deactivation.
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK_DAILY );
	}

	/**
	 * Daily tasks.
	 */
	public static function run_daily() {
		self::check_saved_searches();
		self::check_deadline_reminders();
		self::check_almost_full();
		self::mark_post_event_reviewable();
		LNKup_Marketplace_Index::rebuild_all();
		if ( class_exists( 'LNKup_Intelligence_Cron' ) ) {
			LNKup_Intelligence_Cron::run_daily();
		}
	}

	/**
	 * Mark paid applications reviewable after event date passes.
	 */
	public static function mark_post_event_reviewable() {
		$apps = get_posts(
			array(
				'post_type'      => 'lnkup_application',
				'posts_per_page' => 100,
				'meta_query'     => array(
					array(
						'key'     => '_lnkup_application_status',
						'value'   => array( 'paid', 'completed' ),
						'compare' => 'IN',
					),
					array(
						'key'     => '_lnkup_event_completed_at',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
		$today = gmdate( 'Y-m-d' );
		foreach ( $apps as $app ) {
			$event_id = (int) get_post_meta( $app->ID, '_lnkup_event_id', true );
			$event_date = $event_id ? get_post_meta( $event_id, '_lnkup_event_date', true ) : '';
			if ( $event_date && $event_date < $today ) {
				update_post_meta( $app->ID, '_lnkup_event_completed_at', current_time( 'mysql' ) );
				$organizer_id = (int) get_post_meta( $app->ID, '_lnkup_organizer_user_id', true );
				if ( $organizer_id && ! get_post_meta( $app->ID, '_lnkup_review_id', true ) ) {
					LNKup_Notifications::send_post_event_review_prompt( $organizer_id, $app->ID );
				}
			}
		}
	}

	/**
	 * Notify on new opportunity publish.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function on_new_opportunity( $post_id, $post ) {
		if ( ! lnkup_marketplace_phase_at_least( '1c' ) ) {
			return;
		}
		$row = LNKup_Marketplace_Index::get_row( $post_id );
		if ( ! $row ) {
			LNKup_Marketplace_Index::sync_opportunity( $post_id );
			$row = LNKup_Marketplace_Index::get_row( $post_id );
		}
		if ( ! $row ) {
			return;
		}

		LNKup_Notifications::send_favorite_organizer_new_event( (int) $row['organizer_user_id'], $post_id );
		self::notify_saved_search_matches( $row );
		self::notify_profile_matches( $row );
	}

	/**
	 * Check saved searches for all vendors.
	 */
	private static function check_saved_searches() {
		$vendors = get_users( array( 'role' => 'lnkup_vendor', 'fields' => 'ID' ) );
		foreach ( $vendors as $user_id ) {
			$searches = LNKup_Vendor_Personalization::get_saved_searches( $user_id );
			foreach ( $searches as $search ) {
				$result = LNKup_Discovery::search( array_merge( $search['filters'] ?? array(), array( 'per_page' => 5, 'sort' => 'newest' ) ) );
				if ( ! empty( $result['items'] ) ) {
					LNKup_Notifications::send_saved_search_match( $user_id, $search['name'], count( $result['items'] ) );
				}
			}
		}
	}

	/**
	 * Deadline approaching notifications.
	 */
	private static function check_deadline_reminders() {
		global $wpdb;
		$table = LNKup_Marketplace_Index::table_name();
		$rows  = $wpdb->get_results( $wpdb->prepare(
			"SELECT opportunity_id, title, deadline FROM {$table} WHERE deadline = %s",
			gmdate( 'Y-m-d', strtotime( '+3 days' ) )
		), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( (array) $rows as $row ) {
			$apps = get_posts( array(
				'post_type' => 'lnkup_application', 'posts_per_page' => -1,
				'meta_query' => array(
					array( 'key' => '_lnkup_opportunity_id', 'value' => $row['opportunity_id'] ),
					array( 'key' => '_lnkup_application_status', 'value' => array( 'submitted', 'under_review', 'approved', 'payment_required' ), 'compare' => 'IN' ),
				),
			) );
			foreach ( $apps as $app ) {
				$vendor_id = (int) get_post_meta( $app->ID, '_lnkup_vendor_user_id', true );
				LNKup_Notifications::send_deadline_approaching( $vendor_id, $row['title'], $row['deadline'] );
			}
		}
	}

	/**
	 * Almost full notifications.
	 */
	private static function check_almost_full() {
		global $wpdb;
		$table = LNKup_Marketplace_Index::table_name();
		$rows  = $wpdb->get_results( "SELECT opportunity_id, title, spots_remaining, spots_total FROM {$table} WHERE spots_total > 0 AND spots_remaining > 0 AND (spots_remaining / spots_total) <= 0.1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( (array) $rows as $row ) {
			$fav_users = get_users( array( 'role' => 'lnkup_vendor', 'fields' => 'ID' ) );
			foreach ( $fav_users as $uid ) {
				if ( LNKup_Vendor_Personalization::is_favorite( $uid, 'opportunities', $row['opportunity_id'] ) ) {
					LNKup_Notifications::send_almost_full( $uid, $row['title'], $row['spots_remaining'] );
				}
			}
		}
	}

	/**
	 * Notify vendors with matching saved searches for new row.
	 */
	private static function notify_saved_search_matches( $row ) {
		$vendors = get_users( array( 'role' => 'lnkup_vendor', 'fields' => 'ID' ) );
		foreach ( $vendors as $user_id ) {
			$searches = LNKup_Vendor_Personalization::get_saved_searches( $user_id );
			foreach ( $searches as $search ) {
				$result = LNKup_Discovery::search( array_merge( $search['filters'] ?? array(), array( 'per_page' => 50 ) ) );
				foreach ( $result['items'] as $item ) {
					if ( (int) $item['opportunity_id'] === (int) $row['opportunity_id'] ) {
						LNKup_Notifications::send_saved_search_match( $user_id, $search['name'], 1 );
						break 2;
					}
				}
			}
		}
	}

	/**
	 * Notify vendors whose profile matches new opportunity.
	 */
	private static function notify_profile_matches( $row ) {
		$row_cats = json_decode( $row['categories'] ?? '[]', true ) ?: array();
		if ( empty( $row_cats ) ) {
			return;
		}

		$vendors = get_users( array( 'role' => 'lnkup_vendor' ) );
		foreach ( $vendors as $user ) {
			$profile_id = lnkup_get_vendor_profile_id( $user->ID );
			if ( ! $profile_id ) {
				continue;
			}
			$cats = wp_get_post_terms( $profile_id, 'lnkup_vendor_category', array( 'fields' => 'names' ) );
			if ( is_wp_error( $cats ) ) {
				continue;
			}
			if ( array_intersect( $cats, $row_cats ) ) {
				LNKup_Notifications::send_profile_match( $user->ID, $row['title'] );
			}
		}
	}
}
