<?php
/**
 * Email notifications.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Notifications {

	/**
	 * Send branded email.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    HTML body.
	 */
	public static function send( $to, $subject, $body ) {
		$settings = lnkup_get_settings();
		$html     = self::wrap_template( $body );
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );
		return wp_mail( $to, $subject, $html, $headers );
	}

	/**
	 * Email wrapper template.
	 *
	 * @param string $content Content.
	 */
	public static function wrap_template( $content ) {
		ob_start();
		include LNKUP_PLUGIN_DIR . 'templates/emails/wrapper.php';
		return ob_get_clean();
	}

	/**
	 * Send application submitted.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_submitted( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application submitted — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your application has been submitted. The organizer will review it soon.', 'lnkup-marketplace' ) . '</p>'
		);

		$organizer_id = (int) get_post_meta( $app_id, '_lnkup_organizer_user_id', true );
		$organizer    = get_userdata( $organizer_id );
		if ( $organizer && ! empty( $settings['notify_organizer'] ) ) {
			self::send(
				$organizer->user_email,
				__( 'New vendor application — LNKup', 'lnkup-marketplace' ),
				'<p>' . esc_html__( 'A vendor has applied to one of your opportunities.', 'lnkup-marketplace' ) . '</p>'
			);
		}
	}

	/**
	 * Send application approved.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_approved( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application approved — payment required', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Congratulations! You have been approved. Please complete payment to secure your spot.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send payment required.
	 *
	 * @param int $app_id     Application ID.
	 * @param int $payment_id Payment ID.
	 */
	public static function send_payment_required( $app_id, $payment_id ) {
		self::send_application_approved( $app_id );
	}

	/**
	 * Send payment confirmed.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_payment_confirmed( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Payment confirmed — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your payment has been received. Your vendor packet is now unlocked.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send packet unlocked.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_packet_unlocked( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Vendor packet unlocked — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your load-in details and QR pass are now available in your dashboard.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send application rejected.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_rejected( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		$reason = get_post_meta( $app_id, '_lnkup_rejection_reason', true );
		$body   = '<p>' . esc_html__( 'Your application was not accepted for this event.', 'lnkup-marketplace' ) . '</p>';
		if ( $reason ) {
			$body .= '<p><strong>' . esc_html__( 'Reason:', 'lnkup-marketplace' ) . '</strong> ' . esc_html( $reason ) . '</p>';
		}
		self::send( $user->user_email, __( 'Application update — LNKup', 'lnkup-marketplace' ), $body );
	}

	/**
	 * Send waitlisted notification.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_waitlisted( $app_id ) {
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application waitlisted — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'You have been waitlisted for this opportunity. The organizer may contact you if a spot opens.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Notify organizer of vendor payment.
	 *
	 * @param int $payment_id Payment ID.
	 */
	public static function send_organizer_vendor_paid( $payment_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_organizer'] ) ) {
			return;
		}
		$organizer_id = (int) get_post_meta( $payment_id, '_lnkup_organizer_user_id', true );
		$user         = get_userdata( $organizer_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Vendor payment received — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'A vendor has completed payment for your event.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Notify admin of pending document.
	 *
	 * @param int $doc_id Document ID.
	 */
	public static function send_document_pending_admin( $doc_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_admin'] ) ) {
			return;
		}
		$email = $settings['support_email'] ?: get_option( 'admin_email' );
		self::send(
			$email,
			__( 'Document pending verification — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'A new vendor document requires verification.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Saved search match notification.
	 *
	 * @param int    $user_id User ID.
	 * @param string $name    Search name.
	 * @param int    $count   Match count.
	 */
	public static function send_saved_search_match( $user_id, $name, $count ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'New opportunities match your saved search — LNKup', 'lnkup-marketplace' ),
			'<p>' . sprintf(
				/* translators: 1: search name, 2: count */
				esc_html__( '%1$d new opportunities match your saved search "%2$s".', 'lnkup-marketplace' ),
				(int) $count,
				esc_html( $name )
			) . '</p>'
		);
	}

	/**
	 * Favorite organizer posted new event.
	 *
	 * @param int $organizer_id Organizer user ID.
	 * @param int $opp_id       Opportunity ID.
	 */
	public static function send_favorite_organizer_new_event( $organizer_id, $opp_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$row = LNKup_Marketplace_Index::get_row( $opp_id );
		if ( ! $row ) {
			return;
		}
		$vendors = get_users( array( 'role' => 'lnkup_vendor' ) );
		foreach ( $vendors as $user ) {
			if ( ! LNKup_Vendor_Personalization::is_favorite( $user->ID, 'organizers', $organizer_id ) ) {
				continue;
			}
			self::send(
				$user->user_email,
				__( 'Favorite organizer posted a new event — LNKup', 'lnkup-marketplace' ),
				'<p>' . sprintf(
					/* translators: %s: event title */
					esc_html__( 'An organizer you follow posted: %s', 'lnkup-marketplace' ),
					esc_html( $row['title'] )
				) . '</p>'
			);
		}
	}

	/**
	 * Application deadline approaching.
	 */
	public static function send_deadline_approaching( $user_id, $title, $deadline ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application deadline approaching — LNKup', 'lnkup-marketplace' ),
			'<p>' . sprintf(
				/* translators: 1: event title, 2: deadline */
				esc_html__( 'The deadline for %1$s is %2$s.', 'lnkup-marketplace' ),
				esc_html( $title ),
				esc_html( $deadline )
			) . '</p>'
		);
	}

	/**
	 * Opportunity almost full.
	 */
	public static function send_almost_full( $user_id, $title, $spots ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Opportunity almost full — LNKup', 'lnkup-marketplace' ),
			'<p>' . sprintf(
				/* translators: 1: event title, 2: spots remaining */
				esc_html__( '%1$s has only %2$d spots remaining.', 'lnkup-marketplace' ),
				esc_html( $title ),
				(int) $spots
			) . '</p>'
		);
	}

	/**
	 * New event matches vendor profile.
	 */
	public static function send_profile_match( $user_id, $title ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'New opportunity matches your profile — LNKup', 'lnkup-marketplace' ),
			'<p>' . sprintf(
				/* translators: %s: event title */
				esc_html__( 'A new opportunity matches your vendor profile: %s', 'lnkup-marketplace' ),
				esc_html( $title )
			) . '</p>'
		);
	}

	/**
	 * Vendor invite to apply/rebook.
	 *
	 * @param int    $invite_id Invite post ID.
	 * @param string $link      Invite URL.
	 */
	public static function send_vendor_invite( $invite_id, $link ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $invite_id, '_lnkup_vendor_user_id', true );
		$user = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		$message = get_post_meta( $invite_id, '_lnkup_invite_message', true );
		$body = '<p>' . esc_html__( 'An organizer invited you to apply for an event on LNKup.', 'lnkup-marketplace' ) . '</p>';
		if ( $message ) {
			$body .= '<p>' . esc_html( $message ) . '</p>';
		}
		$body .= '<p><a href="' . esc_url( $link ) . '">' . esc_html__( 'View invitation', 'lnkup-marketplace' ) . '</a></p>';
		self::send( $user->user_email, __( 'You are invited to apply — LNKup', 'lnkup-marketplace' ), $body );
	}

	/**
	 * Prompt organizer to review vendors after event.
	 *
	 * @param int $organizer_id   Organizer user ID.
	 * @param int $application_id Application ID.
	 */
	public static function send_post_event_review_prompt( $organizer_id, $application_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_organizer'] ) ) {
			return;
		}
		$user = get_userdata( $organizer_id );
		if ( ! $user ) {
			return;
		}
		$event_id = (int) get_post_meta( $application_id, '_lnkup_event_id', true );
		$roster_url = add_query_arg(
			array( 'event' => $event_id, 'roster' => 1 ),
			lnkup_page_url_helper( 'organizer-dashboard' )
		);
		$body = '<p>' . esc_html__( 'Your event has ended. Please review your vendors on LNKup.', 'lnkup-marketplace' ) . '</p>';
		$body .= '<p><a href="' . esc_url( $roster_url ) . '">' . esc_html__( 'Review vendors', 'lnkup-marketplace' ) . '</a></p>';
		self::send( $user->user_email, __( 'Review your vendors — LNKup', 'lnkup-marketplace' ), $body );
	}

	/**
	 * Notify vendors of operations broadcast.
	 *
	 * @param int   $event_id   Event ID.
	 * @param array $vendor_ids Vendor user IDs.
	 * @param string $message   Message body.
	 */
	public static function send_ops_broadcast( $event_id, $vendor_ids, $message ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$title = get_the_title( $event_id );
		$body  = '<p>' . esc_html( $message ) . '</p>';
		$body .= '<p><a href="' . esc_url( add_query_arg( 'view', 'operations', lnkup_page_url_helper( 'vendor-dashboard' ) ) ) . '">' . esc_html__( 'View in dashboard', 'lnkup-marketplace' ) . '</a></p>';
		foreach ( $vendor_ids as $vendor_id ) {
			$user = get_userdata( $vendor_id );
			if ( $user ) {
				self::send( $user->user_email, sprintf( __( 'Event update: %s', 'lnkup-marketplace' ), $title ), $body );
			}
		}
	}
}
