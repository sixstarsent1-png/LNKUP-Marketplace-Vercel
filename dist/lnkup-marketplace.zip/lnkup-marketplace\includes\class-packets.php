<?php
/**
 * Vendor packet lock/unlock logic.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Packets {

	/**
	 * Unlock packet for paid application.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function unlock_for_application( $app_id ) {
		$packets = get_posts(
			array(
				'post_type'      => 'lnkup_packet',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
			)
		);

		if ( $packets ) {
			update_post_meta( $packets[0]->ID, '_lnkup_packet_locked', false );
			LNKup_Notifications::send_packet_unlocked( $app_id );
			$payment = LNKup_Payments::get_for_application( $app_id );
			do_action( 'lnkup_packet_unlocked', $app_id, $payment ? (int) $payment->ID : 0 );
			return $packets[0]->ID;
		}

		$event_id = (int) get_post_meta( $app_id, '_lnkup_event_id', true );
		$opp_id   = (int) get_post_meta( $app_id, '_lnkup_opportunity_id', true );
		$vendor   = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$event    = $event_id ? get_post( $event_id ) : null;
		$settings = lnkup_get_settings();

		$packet_id = wp_insert_post(
			array(
				'post_title'  => sprintf( __( 'Packet: Application #%d', 'lnkup-marketplace' ), $app_id ),
				'post_type'   => 'lnkup_packet',
				'post_status' => 'publish',
			)
		);

		update_post_meta( $packet_id, '_lnkup_application_id', $app_id );
		update_post_meta( $packet_id, '_lnkup_event_id', $event_id );
		update_post_meta( $packet_id, '_lnkup_opportunity_id', $opp_id );
		update_post_meta( $packet_id, '_lnkup_vendor_user_id', $vendor );
		update_post_meta( $packet_id, '_lnkup_packet_locked', false );
		update_post_meta( $packet_id, '_lnkup_qr_pass', 'LNKUP-' . strtoupper( wp_generate_password( 8, false ) ) );

		if ( $event ) {
			$venue = get_post_meta( $event_id, '_lnkup_venue_address', true );
			update_post_meta( $packet_id, '_lnkup_venue_address', $venue );
			update_post_meta( $packet_id, '_lnkup_load_in_time', get_post_meta( $event_id, '_lnkup_start_time', true ) );
			update_post_meta( $packet_id, '_lnkup_vendor_rules', __( 'Follow all venue and organizer guidelines. Check in at vendor registration on arrival.', 'lnkup-marketplace' ) );
		}

		LNKup_Notifications::send_packet_unlocked( $app_id );
		$payment = LNKup_Payments::get_for_application( $app_id );
		do_action( 'lnkup_packet_unlocked', $app_id, $payment ? (int) $payment->ID : 0 );

		return $packet_id;
	}

	/**
	 * Check if packet is accessible.
	 *
	 * @param int $packet_id Packet ID.
	 */
	public static function is_unlocked( $packet_id ) {
		$locked = get_post_meta( $packet_id, '_lnkup_packet_locked', true );
		if ( false === $locked || '0' === $locked || 0 === $locked ) {
			return true;
		}
		$app_id = (int) get_post_meta( $packet_id, '_lnkup_application_id', true );
		$payment = $app_id ? LNKup_Payments::get_for_application( $app_id ) : null;
		if ( $payment && 'paid' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Get venue address visibility for event.
	 *
	 * @param int $event_id Event ID.
	 * @param int $app_id   Application ID.
	 */
	public static function get_venue_address( $event_id, $app_id = 0 ) {
		$hidden = (bool) get_post_meta( $event_id, '_lnkup_venue_hidden', true );
		if ( ! $hidden ) {
			return get_post_meta( $event_id, '_lnkup_venue_address', true );
		}
		if ( $app_id ) {
			$payment = LNKup_Payments::get_for_application( $app_id );
			if ( $payment && 'paid' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) {
				return get_post_meta( $event_id, '_lnkup_venue_address', true );
			}
		}
		return __( 'Hidden until payment is complete.', 'lnkup-marketplace' );
	}

	/**
	 * Render packet for vendor.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function render_for_vendor( $app_id ) {
		$packets = get_posts(
			array(
				'post_type'      => 'lnkup_packet',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
			)
		);
		if ( ! $packets ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Packet not yet available.', 'lnkup-marketplace' ) . '</p>';
		}

		$packet = $packets[0];
		if ( ! self::is_unlocked( $packet->ID ) ) {
			return '<div class="lnkup-alert lnkup-alert--warning">' . esc_html__( 'Complete payment to unlock your vendor packet.', 'lnkup-marketplace' ) . '</div>';
		}

		ob_start();
		?>
		<div class="lnkup-panel">
			<h3 class="lnkup-panel__title"><?php esc_html_e( 'Vendor Packet', 'lnkup-marketplace' ); ?></h3>
			<p><strong><?php esc_html_e( 'QR Pass:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_qr_pass', true ) ); ?></p>
			<p><strong><?php esc_html_e( 'Load-in:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_load_in_time', true ) ?: '—' ); ?></p>
			<p><strong><?php esc_html_e( 'Booth:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_booth_assignment', true ) ?: __( 'TBD', 'lnkup-marketplace' ) ); ?></p>
			<p><strong><?php esc_html_e( 'Venue:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_venue_address', true ) ); ?></p>
			<p><strong><?php esc_html_e( 'Parking:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_parking_info', true ) ?: '—' ); ?></p>
			<p><?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_vendor_rules', true ) ); ?></p>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Packet section definitions.
	 */
	public static function sections() {
		return array(
			'welcome'     => __( 'Welcome', 'lnkup-marketplace' ),
			'overview'    => __( 'Event Overview', 'lnkup-marketplace' ),
			'venue'       => __( 'Venue & GPS', 'lnkup-marketplace' ),
			'schedule'    => __( 'Schedule', 'lnkup-marketplace' ),
			'loadin'      => __( 'Load-In Instructions', 'lnkup-marketplace' ),
			'booth'       => __( 'Booth Assignment', 'lnkup-marketplace' ),
			'parking'     => __( 'Parking Pass', 'lnkup-marketplace' ),
			'map'         => __( 'Site Map', 'lnkup-marketplace' ),
			'rules'       => __( 'Rules', 'lnkup-marketplace' ),
			'power'       => __( 'Power', 'lnkup-marketplace' ),
			'wifi'        => __( 'Wi-Fi', 'lnkup-marketplace' ),
			'emergency'   => __( 'Emergency Contacts', 'lnkup-marketplace' ),
			'weather'     => __( 'Weather Plan', 'lnkup-marketplace' ),
			'faq'         => __( 'FAQ', 'lnkup-marketplace' ),
			'support'     => __( 'Support', 'lnkup-marketplace' ),
			'qr'          => __( 'QR Pass', 'lnkup-marketplace' ),
		);
	}

	/**
	 * Build interactive packet DTO.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function get_dto( $app_id ) {
		$packets = get_posts(
			array(
				'post_type'      => 'lnkup_packet',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => absint( $app_id ),
			)
		);
		if ( ! $packets ) {
			return null;
		}
		$packet = $packets[0];
		if ( ! self::is_unlocked( $packet->ID ) ) {
			return array( 'locked' => true );
		}
		$event_id = (int) get_post_meta( $app_id, '_lnkup_event_id', true );
		$event = get_post( $event_id );
		$booth = class_exists( 'LNKup_Booths' ) ? LNKup_Booths::get_for_application( $app_id ) : null;
		$parking = class_exists( 'LNKup_Parking' ) ? LNKup_Parking::get_for_application( $app_id ) : null;
		$loadin = class_exists( 'LNKup_Loadin_Schedule' ) ? LNKup_Loadin_Schedule::get_for_application( $app_id ) : null;
		$map_id = (int) get_post_meta( $event_id, '_lnkup_venue_map_attachment_id', true );
		return array(
			'packet_id'   => $packet->ID,
			'locked'      => false,
			'qr_pass'     => get_post_meta( $packet->ID, '_lnkup_qr_pass', true ),
			'sections'    => array(
				'welcome'   => array( 'title' => self::sections()['welcome'], 'body' => sprintf( __( 'Welcome to %s!', 'lnkup-marketplace' ), $event ? $event->post_title : '' ) ),
				'overview'  => array( 'title' => self::sections()['overview'], 'body' => $event ? $event->post_content : '' ),
				'venue'     => array( 'title' => self::sections()['venue'], 'body' => get_post_meta( $packet->ID, '_lnkup_venue_address', true ) ),
				'schedule'  => array( 'title' => self::sections()['schedule'], 'body' => get_post_meta( $event_id, '_lnkup_event_date', true ) . ' ' . get_post_meta( $event_id, '_lnkup_start_time', true ) ),
				'loadin'    => array( 'title' => self::sections()['loadin'], 'body' => $loadin ? $loadin['label'] . ' — Gate ' . $loadin['gate'] : get_post_meta( $packet->ID, '_lnkup_load_in_time', true ) ),
				'booth'     => array( 'title' => self::sections()['booth'], 'body' => $booth ? $booth['booth_number'] : get_post_meta( $packet->ID, '_lnkup_booth_assignment', true ) ),
				'parking'   => array( 'title' => self::sections()['parking'], 'body' => $parking ? $parking['label'] : get_post_meta( $packet->ID, '_lnkup_parking_info', true ) ),
				'map'       => array( 'title' => self::sections()['map'], 'body' => $map_id ? wp_get_attachment_url( $map_id ) : '' ),
				'rules'     => array( 'title' => self::sections()['rules'], 'body' => get_post_meta( $packet->ID, '_lnkup_vendor_rules', true ) ),
				'emergency' => array( 'title' => self::sections()['emergency'], 'body' => class_exists( 'LNKup_Event_Operations' ) ? LNKup_Event_Operations::emergency_contacts( $event_id ) : array() ),
				'weather'   => array( 'title' => self::sections()['weather'], 'body' => get_post_meta( $event_id, '_lnkup_weather_placeholder', true ) ),
				'qr'        => array( 'title' => self::sections()['qr'], 'body' => get_post_meta( $packet->ID, '_lnkup_qr_pass', true ) ),
			),
			'engagement'  => self::get_engagement( $packet->ID ),
		);
	}

	/**
	 * Record packet section engagement.
	 *
	 * @param int    $packet_id   Packet ID.
	 * @param string $section_key Section key.
	 * @param string $action      viewed|downloaded|acknowledged|completed.
	 */
	public static function record_engagement( $packet_id, $section_key, $action = 'viewed' ) {
		global $wpdb;
		$wpdb->insert(
			LNKup_Operations_Tables::packet_engagement_table(),
			array(
				'packet_id'    => absint( $packet_id ),
				'section_key'  => sanitize_key( $section_key ),
				'action'       => sanitize_key( $action ),
				'created_at'   => current_time( 'mysql' ),
			)
		);
		$app_id = (int) get_post_meta( $packet_id, '_lnkup_application_id', true );
		if ( $app_id ) {
			LNKup_Vendor_Readiness::refresh( $app_id );
		}
		return true;
	}

	/**
	 * Check engagement exists.
	 *
	 * @param int    $packet_id   Packet ID.
	 * @param string $section_key Section key.
	 * @param string $action      Action slug.
	 */
	public static function has_engagement( $packet_id, $section_key, $action ) {
		global $wpdb;
		$table = LNKup_Operations_Tables::packet_engagement_table();
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE packet_id = %d AND section_key = %s AND action = %s LIMIT 1",
				absint( $packet_id ),
				sanitize_key( $section_key ),
				sanitize_key( $action )
			)
		);
	}

	/**
	 * Get engagement summary for packet.
	 *
	 * @param int $packet_id Packet ID.
	 */
	public static function get_engagement( $packet_id ) {
		global $wpdb;
		$table = LNKup_Operations_Tables::packet_engagement_table();
		$rows  = $wpdb->get_results(
			$wpdb->prepare( "SELECT section_key, action FROM {$table} WHERE packet_id = %d", absint( $packet_id ) ),
			ARRAY_A
		);
		$out = array();
		foreach ( $rows as $row ) {
			$out[ $row['section_key'] ][] = $row['action'];
		}
		return $out;
	}

	/**
	 * Render tabbed packet for vendor dashboard.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function render_interactive( $app_id ) {
		$dto = self::get_dto( $app_id );
		if ( ! $dto ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Packet not yet available.', 'lnkup-marketplace' ) . '</p>';
		}
		if ( ! empty( $dto['locked'] ) ) {
			return '<div class="lnkup-alert lnkup-alert--warning">' . esc_html__( 'Complete payment to unlock your vendor packet.', 'lnkup-marketplace' ) . '</div>';
		}
		$active_section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'welcome'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $dto['sections'][ $active_section ] ) ) {
			$active_section = 'welcome';
		}
		ob_start();
		?>
		<div class="lnkup-ops-packet lnkup-ops-packet--sidebar" id="lnkup-ops-packet" data-app-id="<?php echo esc_attr( (string) $app_id ); ?>" data-packet-id="<?php echo esc_attr( (string) $dto['packet_id'] ); ?>">
			<div class="lnkup-ops-packet__layout">
				<nav class="lnkup-ops-packet__sidebar" aria-label="<?php esc_attr_e( 'Packet sections', 'lnkup-marketplace' ); ?>">
					<?php foreach ( $dto['sections'] as $key => $section ) : ?>
						<?php
						$viewed = self::has_engagement( $dto['packet_id'], $key, 'viewed' );
						$acked  = self::has_engagement( $dto['packet_id'], $key, 'acknowledged' );
						$done   = $acked || ( 'rules' !== $key && $viewed );
						?>
						<button type="button" class="lnkup-ops-packet-tab lnkup-ops-packet-tab--sidebar<?php echo $active_section === $key ? ' is-active' : ''; ?><?php echo $done ? ' is-complete' : ''; ?>" data-section="<?php echo esc_attr( $key ); ?>">
							<span class="lnkup-ops-packet-tab__dot" aria-hidden="true"></span>
							<span class="lnkup-ops-packet-tab__label"><?php echo esc_html( $section['title'] ); ?></span>
						</button>
					<?php endforeach; ?>
				</nav>
				<select class="lnkup-ops-packet__mobile-select lnkup-input" aria-label="<?php esc_attr_e( 'Packet section', 'lnkup-marketplace' ); ?>">
					<?php foreach ( $dto['sections'] as $key => $section ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $active_section, $key ); ?>><?php echo esc_html( $section['title'] ); ?></option>
					<?php endforeach; ?>
				</select>
				<div class="lnkup-ops-packet__panels">
				<?php foreach ( $dto['sections'] as $key => $section ) : ?>
					<div class="lnkup-ops-packet__panel<?php echo $active_section === $key ? ' is-active' : ''; ?>" data-section-panel="<?php echo esc_attr( $key ); ?>">
						<h3><?php echo esc_html( $section['title'] ); ?></h3>
						<?php if ( 'qr' === $key ) : ?>
							<div class="lnkup-ops-qr" data-qr="<?php echo esc_attr( $section['body'] ); ?>"></div>
							<p><code><?php echo esc_html( $section['body'] ); ?></code></p>
						<?php elseif ( 'map' === $key ) : ?>
							<div class="lnkup-map-packet-wrap" data-app-id="<?php echo esc_attr( (string) $app_id ); ?>"></div>
							<?php if ( $section['body'] ) : ?>
								<img src="<?php echo esc_url( $section['body'] ); ?>" alt="" class="lnkup-ops-map-img lnkup-muted" style="margin-top:0.5rem;opacity:0.6" />
							<?php endif; ?>
						<?php elseif ( 'emergency' === $key && is_array( $section['body'] ) ) : ?>
							<ul><?php foreach ( $section['body'] as $c ) : ?><li><?php echo esc_html( ( $c['name'] ?? '' ) . ' — ' . ( $c['phone'] ?? '' ) ); ?></li><?php endforeach; ?></ul>
						<?php else : ?>
							<p><?php echo esc_html( is_string( $section['body'] ) ? $section['body'] : '' ); ?></p>
						<?php endif; ?>
						<?php if ( 'rules' === $key ) : ?>
							<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-ops-packet-ack" data-section="rules"><?php esc_html_e( 'I accept the rules', 'lnkup-marketplace' ); ?></button>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}
