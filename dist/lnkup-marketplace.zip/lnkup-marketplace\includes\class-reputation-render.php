<?php
/**
 * Reputation UI render helpers.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Reputation_Render {

	/**
	 * Score badge HTML.
	 */
	public static function score_badge( $score, $label = '', $is_new = false ) {
		if ( $is_new ) {
			return '<span class="lnkup-rep-score lnkup-rep-score--new">' . esc_html__( 'New Vendor — Building Reputation', 'lnkup-marketplace' ) . '</span>';
		}
		$class = 'lnkup-rep-score';
		if ( $score >= 90 ) {
			$class .= ' lnkup-rep-score--elite';
		} elseif ( $score >= 80 ) {
			$class .= ' lnkup-rep-score--trusted';
		} elseif ( $score < 50 ) {
			$class .= ' lnkup-rep-score--risk';
		}
		$html = '<span class="' . esc_attr( $class ) . '">';
		$html .= esc_html( sprintf( __( 'LNKup Score: %d / 100', 'lnkup-marketplace' ), (int) $score ) );
		if ( $label ) {
			$html .= ' <em>' . esc_html( $label ) . '</em>';
		}
		$html .= '</span>';
		return $html;
	}

	/**
	 * Star rating display.
	 */
	public static function star_rating( $rating, $count = 0 ) {
		$rating = (float) $rating;
		$full   = (int) floor( $rating );
		$html   = '<span class="lnkup-rep-stars" aria-label="' . esc_attr( sprintf( __( '%s out of 5 stars', 'lnkup-marketplace' ), $rating ) ) . '">';
		for ( $i = 1; $i <= 5; $i++ ) {
			$html .= '<span class="lnkup-rep-stars__star' . ( $i <= $full ? ' is-filled' : '' ) . '">★</span>';
		}
		$html .= ' <span class="lnkup-rep-stars__value">' . esc_html( number_format( $rating, 1 ) ) . '</span>';
		if ( $count ) {
			$html .= ' <span class="lnkup-muted">(' . esc_html( (string) $count ) . ')</span>';
		}
		$html .= '</span>';
		return $html;
	}

	/**
	 * Badge grid.
	 */
	public static function badge_grid( $badges ) {
		if ( ! $badges ) {
			return '<p class="lnkup-muted">' . esc_html__( 'No badges yet.', 'lnkup-marketplace' ) . '</p>';
		}
		$html = '<div class="lnkup-rep-badge-grid">';
		foreach ( $badges as $badge ) {
			$html .= '<span class="lnkup-badge lnkup-badge--secondary lnkup-rep-badge" title="' . esc_attr( $badge['label'] ) . '">' . esc_html( $badge['label'] ) . '</span>';
		}
		$html .= '</div>';
		return $html;
	}

	/**
	 * Reliability meter rows.
	 */
	public static function reliability_meter( $metrics ) {
		if ( ! $metrics ) {
			return '';
		}
		$rows = array(
			array( __( 'Completed events', 'lnkup-marketplace' ), (string) $metrics['completed_events'], null ),
			array( __( 'No-show rate', 'lnkup-marketplace' ), $metrics['no_show_rate'] . '%', 100 - $metrics['no_show_rate'] ),
			array( __( 'Payment completion', 'lnkup-marketplace' ), $metrics['payment_completion_rate'] . '%', $metrics['payment_completion_rate'] ),
			array( __( 'Document compliance', 'lnkup-marketplace' ), $metrics['document_compliance_rate'] . '%', $metrics['document_compliance_rate'] ),
			array( __( 'On-time check-ins', 'lnkup-marketplace' ), $metrics['on_time_check_in_rate'] . '%', $metrics['on_time_check_in_rate'] ),
			array( __( 'Avg organizer rating', 'lnkup-marketplace' ), number_format( $metrics['avg_organizer_rating'], 1 ) . ' / 5', $metrics['avg_organizer_rating'] * 20 ),
		);
		$html = '<dl class="lnkup-rep-meter">';
		foreach ( $rows as $row ) {
			$html .= '<div class="lnkup-rep-meter__row"><dt>' . esc_html( $row[0] ) . '</dt><dd>' . esc_html( $row[1] );
			if ( null !== $row[2] ) {
				$html .= '<div class="lnkup-rep-meter__bar"><span style="width:' . esc_attr( min( 100, (float) $row[2] ) ) . '%"></span></div>';
			}
			$html .= '</dd></div>';
		}
		$html .= '</dl>';
		return $html;
	}

	/**
	 * Review card.
	 */
	public static function review_card( $review ) {
		ob_start();
		?>
		<article class="lnkup-rep-review-card">
			<header>
				<?php echo self::star_rating( $review['overall_rating'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="lnkup-muted"><?php echo esc_html( $review['event_title'] ); ?> · <?php echo esc_html( $review['created_at'] ); ?></span>
			</header>
			<?php if ( ! empty( $review['public_text'] ) ) : ?>
				<p><?php echo esc_html( $review['public_text'] ); ?></p>
			<?php endif; ?>
		</article>
		<?php
		return ob_get_clean();
	}

	/**
	 * Completed events timeline.
	 */
	public static function completed_events_timeline( $events, $limit = 10 ) {
		$events = array_slice( $events, 0, $limit );
		if ( ! $events ) {
			return '<p class="lnkup-muted">' . esc_html__( 'No completed events yet.', 'lnkup-marketplace' ) . '</p>';
		}
		$html = '<ul class="lnkup-rep-timeline">';
		foreach ( $events as $ev ) {
			$html .= '<li class="lnkup-rep-timeline__item">';
			$html .= '<strong>' . esc_html( $ev['event_name'] ) . '</strong>';
			$html .= ' <span class="lnkup-muted">' . esc_html( $ev['date'] ) . ' · ' . esc_html( $ev['city'] . ( $ev['state'] ? ', ' . $ev['state'] : '' ) ) . '</span>';
			if ( $ev['verified'] ) {
				$html .= ' <span class="lnkup-badge lnkup-badge--accent">' . esc_html__( 'Verified', 'lnkup-marketplace' ) . '</span>';
			}
			if ( $ev['rating'] ) {
				$html .= ' ' . self::star_rating( $ev['rating'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			$html .= '</li>';
		}
		$html .= '</ul>';
		return $html;
	}

	/**
	 * Score breakdown panel.
	 */
	public static function score_breakdown_panel( $breakdown ) {
		if ( ! $breakdown || ! is_array( $breakdown ) ) {
			return '';
		}
		$html = '<ul class="lnkup-rep-breakdown">';
		foreach ( $breakdown as $key => $val ) {
			$html .= '<li><span>' . esc_html( ucwords( str_replace( '_', ' ', $key ) ) ) . '</span> <strong>' . esc_html( (string) $val ) . '</strong></li>';
		}
		$html .= '</ul>';
		return $html;
	}

	/**
	 * Risk indicator.
	 */
	public static function risk_indicator( $metrics ) {
		$risk = 'low';
		if ( $metrics['no_show_rate'] > 10 || $metrics['dispute_count'] > 0 ) {
			$risk = 'high';
		} elseif ( $metrics['no_show_rate'] > 3 || $metrics['cancellation_rate'] > 15 ) {
			$risk = 'medium';
		}
		return '<span class="lnkup-rep-risk lnkup-rep-risk--' . esc_attr( $risk ) . '">' . esc_html( ucfirst( $risk ) . ' risk' ) . '</span>';
	}

	/**
	 * Reputation summary card.
	 */
	public static function summary_card( $reputation ) {
		ob_start();
		?>
		<div class="lnkup-rep-summary">
			<?php echo self::score_badge( $reputation['score'], $reputation['label'], ! empty( $reputation['is_new'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php if ( $reputation['review_count'] ) : ?>
				<?php echo self::star_rating( $reputation['avg_rating'], $reputation['review_count'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<?php echo self::badge_grid( $reputation['badges'] ?? array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
