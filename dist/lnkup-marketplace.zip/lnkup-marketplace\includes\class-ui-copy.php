<?php
/**
 * LNKup marketplace UI copy registry.
 *
 * @package LNKup_Marketplace
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * Centralized marketplace-facing labels (display only — not routes/CPT slugs).
 */
class LNKup_UI_Copy {

	/**
	 * Copy key map.
	 *
	 * @return array<string, string>
	 */
	public static function registry(): array {
		return array(
			'applications'              => __( 'Vendor requests', 'lnkup-marketplace' ),
			'vendor_requests'           => __( 'Vendor requests', 'lnkup-marketplace' ),
			'review_applications'       => __( 'Review vendor requests', 'lnkup-marketplace' ),
			'confirmed_vendors'         => __( 'Confirmed vendors', 'lnkup-marketplace' ),
			'vendors_booked'            => __( 'Confirmed vendors', 'lnkup-marketplace' ),
			'vendor_revenue'            => __( 'Vendor revenue', 'lnkup-marketplace' ),
			'revenue'                   => __( 'Vendor revenue', 'lnkup-marketplace' ),
			'event_readiness'           => __( 'Event readiness', 'lnkup-marketplace' ),
			'vendor_roster'             => __( 'Vendor roster', 'lnkup-marketplace' ),
			'launch_event'              => __( 'Launch event', 'lnkup-marketplace' ),
			'create_event'              => __( 'Launch event', 'lnkup-marketplace' ),
			'open_financial_center'     => __( 'Open financial center', 'lnkup-marketplace' ),
			'open_financials'           => __( 'Open financial center', 'lnkup-marketplace' ),
			'vendor_packet'             => __( 'Vendor packet', 'lnkup-marketplace' ),
			'event_issues'              => __( 'Event issues', 'lnkup-marketplace' ),
			'vendors_not_event_ready'   => __( 'Vendors not event-ready', 'lnkup-marketplace' ),
			'missing_documents'         => __( 'Vendors not event-ready', 'lnkup-marketplace' ),
			'command_center'            => __( 'Event command center', 'lnkup-marketplace' ),
			'organizer_command_center'  => __( 'Organizer Command Center', 'lnkup-marketplace' ),
			'invite_vendors'            => __( 'Invite vendors', 'lnkup-marketplace' ),
			'expand_financials'         => __( 'Expand financials', 'lnkup-marketplace' ),
			'expand_intelligence'       => __( 'Expand intelligence', 'lnkup-marketplace' ),
			'expand_vendors'            => __( 'Expand vendors', 'lnkup-marketplace' ),
			'view_insights'             => __( 'View insights', 'lnkup-marketplace' ),
			'manage_lists'              => __( 'Manage lists', 'lnkup-marketplace' ),
			'view_all_events'           => __( 'View all events', 'lnkup-marketplace' ),
			'view_all_vendor_requests'  => __( 'Review all vendor requests', 'lnkup-marketplace' ),
			'todays_priority'           => __( "Today's priority", 'lnkup-marketplace' ),
			'launch_opportunity_title'  => __( 'Launch a vendor opportunity', 'lnkup-marketplace' ),
			'launch_opportunity_copy'   => __( 'Create an event, define vendor slots, and publish your first opportunity to Find Events.', 'lnkup-marketplace' ),
			'start_event_setup'         => __( 'Start event setup', 'lnkup-marketplace' ),
			'live_events'               => __( 'Live events', 'lnkup-marketplace' ),
			'financial_snapshot'        => __( 'Financial snapshot', 'lnkup-marketplace' ),
			'quick_actions'             => __( 'Quick actions', 'lnkup-marketplace' ),
			'recent_activity'           => __( 'Recent activity', 'lnkup-marketplace' ),
			'vendor_requests_snapshot'  => __( 'Vendor requests', 'lnkup-marketplace' ),
			'your_events_snapshot'      => __( 'Your events', 'lnkup-marketplace' ),
			'payout_status_active'      => __( 'Payouts active', 'lnkup-marketplace' ),
			'payout_status_setup'       => __( 'Finish payout setup', 'lnkup-marketplace' ),
			'available_balance'         => __( 'Available balance', 'lnkup-marketplace' ),
			'collected_to_date'         => __( 'Collected to date', 'lnkup-marketplace' ),
			'payout_destination'        => __( 'Payout destination', 'lnkup-marketplace' ),
			'funds_processing'          => __( 'Funds processing', 'lnkup-marketplace' ),
			'ready_for_payout'          => __( 'Ready for payout', 'lnkup-marketplace' ),
			'payment_activity'          => __( 'Payment activity', 'lnkup-marketplace' ),
			'refunds'                   => __( 'Refunds', 'lnkup-marketplace' ),
			'financial_center'          => __( 'Financial center', 'lnkup-marketplace' ),
			'new_vendor_requests'       => __( 'New vendor requests', 'lnkup-marketplace' ),
			'new_applications'          => __( 'New vendor requests', 'lnkup-marketplace' ),
			'active_events'             => __( 'Active events', 'lnkup-marketplace' ),
			'discover_vendors'          => __( 'Discover vendors', 'lnkup-marketplace' ),
			'vendor_directory'          => __( 'Discover vendors', 'lnkup-marketplace' ),
			'find_events'               => __( 'Find events', 'lnkup-marketplace' ),
			'empty_vendor_requests'     => __( 'No new vendor requests yet. Invite vendors or share this opportunity to start filling your roster.', 'lnkup-marketplace' ),
			'empty_confirmed_vendors'   => __( 'No vendors confirmed yet. Approve requests or invite vendors to start building your event roster.', 'lnkup-marketplace' ),
			'empty_financial'           => __( 'No financial activity yet. Payments will appear here once vendors start booking.', 'lnkup-marketplace' ),
			'empty_documents'           => __( 'No documents uploaded yet. Required vendor documents will appear here for review.', 'lnkup-marketplace' ),
			'empty_applications'        => __( 'Vendor requests will appear here once vendors apply to your opportunities.', 'lnkup-marketplace' ),
			'panel_error'               => __( 'We couldn\'t load this section. Try refreshing or contact support.', 'lnkup-marketplace' ),
			'retry'                     => __( 'Try again', 'lnkup-marketplace' ),
		);
	}

	/**
	 * Get copy string by key.
	 *
	 * @param string $key     Registry key.
	 * @param string $fallback Optional fallback if key missing.
	 */
	public static function get( string $key, string $fallback = '' ): string {
		$registry = self::registry();
		if ( isset( $registry[ $key ] ) ) {
			return $registry[ $key ];
		}
		return $fallback ?: $key;
	}

	/**
	 * Export copy for JS localization.
	 *
	 * @return array<string, string>
	 */
	public static function for_js(): array {
		return self::registry();
	}
}

/**
 * Shorthand for UI copy.
 *
 * @param string $key Registry key.
 */
function lnkup_copy( string $key ): string {
	return LNKup_UI_Copy::get( $key );
}
