<?php
/**
 * Vendor invites and rebooking.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Vendor_Invites {

	const STATUS_SENT     = 'sent';
	const STATUS_OPENED   = 'opened';
	const STATUS_ACCEPTED = 'accepted';
	const STATUS_DECLINED = 'declined';
	const STATUS_EXPIRED  = 'expired';

	/**
	 * Create invite.
	 */
	public static function create( $organizer_id, $vendor_id, $args = array() ) {
		if ( ! LNKup_Capabilities::organizer_can_manage_vendor( $organizer_id, $vendor_id ) ) {
			LNKup_Organizer_CRM::ensure_relationship( $organizer_id, $vendor_id );
		}
		$type = sanitize_key( $args['type'] ?? 'apply' );
		$opp_id = absint( $args['opportunity_id'] ?? 0 );
		$event_id = absint( $args['event_id'] ?? 0 );
		if ( $opp_id && ! $event_id ) {
			$event_id = (int) get_post_meta( $opp_id, '_lnkup_event_id', true );
		}
		$token = wp_generate_password( 32, false );
		$expires = gmdate( 'Y-m-d H:i:s', strtotime( '+14 days' ) );
		$vendor = get_userdata( $vendor_id );
		$invite_id = wp_insert_post(
			array(
				'post_type'   => 'lnkup_vendor_invite',
				'post_status' => 'publish',
				'post_title'  => sprintf(
					__( 'Invite: %1$s', 'lnkup-marketplace' ),
					$vendor ? $vendor->display_name : '#' . $vendor_id
				),
				'post_author' => $organizer_id,
			)
		);
		update_post_meta( $invite_id, '_lnkup_organizer_user_id', $organizer_id );
		update_post_meta( $invite_id, '_lnkup_vendor_user_id', $vendor_id );
		update_post_meta( $invite_id, '_lnkup_opportunity_id', $opp_id );
		update_post_meta( $invite_id, '_lnkup_event_id', $event_id );
		update_post_meta( $invite_id, '_lnkup_status', self::STATUS_SENT );
		update_post_meta( $invite_id, '_lnkup_token', $token );
		update_post_meta( $invite_id, '_lnkup_expires_at', $expires );
		update_post_meta( $invite_id, '_lnkup_type', $type );
		if ( ! empty( $args['message'] ) ) {
			update_post_meta( $invite_id, '_lnkup_invite_message', sanitize_textarea_field( $args['message'] ) );
		}
		$link = add_query_arg( 'invite', $token, lnkup_page_url_helper( 'opportunities' ) );
		LNKup_Notifications::send_vendor_invite( $invite_id, $link );
		self::add_vendor_notice( $vendor_id, $invite_id );
		LNKup_Organizer_CRM::log_activity(
			'invite_sent',
			$organizer_id,
			$vendor_id,
			array(
				'event_id'       => $event_id,
				'payload'        => array( 'invite_id' => $invite_id, 'type' => $type ),
			)
		);
		return array(
			'invite_id' => $invite_id,
			'token'     => $token,
			'link'      => $link,
			'expires'   => $expires,
		);
	}

	/**
	 * Add dashboard notice for vendor.
	 */
	public static function add_vendor_notice( $vendor_id, $invite_id ) {
		$notices = get_user_meta( $vendor_id, 'lnkup_vendor_notices', true );
		if ( ! is_array( $notices ) ) {
			$notices = array();
		}
		array_unshift( $notices, array( 'invite_id' => $invite_id, 'at' => current_time( 'mysql' ) ) );
		update_user_meta( $vendor_id, 'lnkup_vendor_notices', array_slice( $notices, 0, 20 ) );
	}

	/**
	 * Get invite by token.
	 */
	public static function get_by_token( $token ) {
		$posts = get_posts(
			array(
				'post_type'      => 'lnkup_vendor_invite',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_token',
				'meta_value'     => sanitize_text_field( $token ),
			)
		);
		return $posts ? $posts[0] : null;
	}

	/**
	 * Vendor respond to invite.
	 */
	public static function respond( $token, $accept ) {
		$invite = self::get_by_token( $token );
		if ( ! $invite ) {
			return new WP_Error( 'invalid', __( 'Invalid invite.', 'lnkup-marketplace' ) );
		}
		$expires = get_post_meta( $invite->ID, '_lnkup_expires_at', true );
		if ( $expires && strtotime( $expires ) < time() ) {
			update_post_meta( $invite->ID, '_lnkup_status', self::STATUS_EXPIRED );
			return new WP_Error( 'expired', __( 'This invite has expired.', 'lnkup-marketplace' ) );
		}
		$status = $accept ? self::STATUS_ACCEPTED : self::STATUS_DECLINED;
		update_post_meta( $invite->ID, '_lnkup_status', $status );
		$organizer_id = (int) get_post_meta( $invite->ID, '_lnkup_organizer_user_id', true );
		$vendor_id = (int) get_post_meta( $invite->ID, '_lnkup_vendor_user_id', true );
		LNKup_Organizer_CRM::log_activity(
			$accept ? 'invite_accepted' : 'invite_declined',
			$organizer_id,
			$vendor_id,
			array( 'payload' => array( 'invite_id' => $invite->ID ) )
		);
		if ( $accept ) {
			LNKup_Organizer_CRM::log_activity( 'rebooked', $organizer_id, $vendor_id, array( 'payload' => array( 'invite_id' => $invite->ID ) ) );
		}
		return true;
	}

	/**
	 * Mark invite opened.
	 */
	public static function mark_opened( $token ) {
		$invite = self::get_by_token( $token );
		if ( $invite && self::STATUS_SENT === get_post_meta( $invite->ID, '_lnkup_status', true ) ) {
			update_post_meta( $invite->ID, '_lnkup_status', self::STATUS_OPENED );
		}
	}

	/**
	 * Get invites for organizer.
	 */
	public static function get_for_organizer( $organizer_id, $limit = 20 ) {
		$invites = get_posts(
			array(
				'post_type'      => 'lnkup_vendor_invite',
				'posts_per_page' => $limit,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $organizer_id,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$items = array();
		foreach ( $invites as $invite ) {
			$vendor_id = (int) get_post_meta( $invite->ID, '_lnkup_vendor_user_id', true );
			$vendor = get_userdata( $vendor_id );
			$token  = (string) get_post_meta( $invite->ID, '_lnkup_token', true );
			$link   = $token ? add_query_arg( 'invite', $token, lnkup_page_url_helper( 'opportunities' ) ) : '';
			$items[] = array(
				'id'       => $invite->ID,
				'vendor'   => $vendor ? $vendor->display_name : '',
				'status'   => get_post_meta( $invite->ID, '_lnkup_status', true ),
				'type'     => get_post_meta( $invite->ID, '_lnkup_type', true ),
				'event_id' => (int) get_post_meta( $invite->ID, '_lnkup_event_id', true ),
				'created'  => $invite->post_date,
				'link'     => $link,
			);
		}
		return $items;
	}
}
