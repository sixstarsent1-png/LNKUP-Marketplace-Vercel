<?php
/**
 * Configurable marketplace fee engine.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Fee_Engine {

	const PROCESSING_RATE = 0.029;
	const PROCESSING_FLAT = 0.30;

	/**
	 * Calculate fee breakdown for a booking.
	 *
	 * @param array $context vendor_fee, organizer_id, event_id, category, opportunity_id.
	 * @return array
	 */
	public static function calculate( $context ) {
		$vendor_fee   = max( 0, (float) ( $context['vendor_fee'] ?? 0 ) );
		$organizer_id = absint( $context['organizer_id'] ?? 0 );
		$event_id     = absint( $context['event_id'] ?? 0 );
		$category     = sanitize_key( $context['category'] ?? '' );
		$discount     = max( 0, (float) ( $context['discount'] ?? 0 ) );
		$credit       = max( 0, (float) ( $context['credit'] ?? 0 ) );

		$vendor_checkout_fee  = self::resolve_vendor_checkout_fee( $organizer_id, $event_id, $category );
		$organizer_commission = self::resolve_organizer_commission( $vendor_fee, $organizer_id, $event_id, $category );
		$platform_fee         = round( $vendor_checkout_fee + $organizer_commission, 2 );
		$subtotal             = round( $vendor_fee + $vendor_checkout_fee, 2 );
		$processing           = round( $subtotal * self::PROCESSING_RATE + self::PROCESSING_FLAT, 2 );
		$tax_rate             = self::resolve_tax_rate( $organizer_id, $event_id );
		$taxable              = max( 0, $subtotal - $discount );
		$tax_amount           = round( $taxable * $tax_rate, 2 );
		$total                = max( 0, round( $subtotal + $processing + $tax_amount - $discount - $credit, 2 ) );
		$organizer_net        = max( 0, round( $vendor_fee - $organizer_commission, 2 ) );

		return array(
			'vendor_fee'              => round( $vendor_fee, 2 ),
			'vendor_checkout_fee'     => round( $vendor_checkout_fee, 2 ),
			'organizer_commission'    => round( $organizer_commission, 2 ),
			'platform_fee'            => $platform_fee,
			'booth_reservation_total' => $subtotal,
			'organizer_net'           => $organizer_net,
			'processing_fee'          => $processing,
			'tax_amount'              => $tax_amount,
			'tax_rate'                => $tax_rate,
			'discount'                => round( $discount, 2 ),
			'credit'                  => round( $credit, 2 ),
			'subtotal'                => $subtotal,
			'total'                   => $total,
		);
	}

	/**
	 * Flat fee charged to vendor at checkout (bundled with booth).
	 *
	 * @param int    $organizer_id Organizer user ID.
	 * @param int    $event_id     Event ID.
	 * @param string $category     Vendor category slug.
	 */
	public static function resolve_vendor_checkout_fee( $organizer_id = 0, $event_id = 0, $category = '' ) {
		$rule = self::match_rule( $organizer_id, $event_id, $category );
		if ( $rule && 'flat' === ( $rule['fee_type'] ?? '' ) ) {
			return self::apply_rule( $rule, 0 );
		}
		$settings = lnkup_get_settings();
		if ( isset( $settings['vendor_checkout_fee'] ) && '' !== (string) $settings['vendor_checkout_fee'] ) {
			return round( (float) $settings['vendor_checkout_fee'], 2 );
		}
		$legacy = (float) ( $settings['application_fee_flat'] ?? $settings['default_fee'] ?? 5.99 );
		return round( $legacy, 2 );
	}

	/**
	 * Commission on booth price deducted from organizer revenue.
	 *
	 * @param float  $vendor_fee   Booth price.
	 * @param int    $organizer_id Organizer user ID.
	 * @param int    $event_id     Event ID.
	 * @param string $category     Vendor category slug.
	 */
	public static function resolve_organizer_commission( $vendor_fee, $organizer_id = 0, $event_id = 0, $category = '' ) {
		$rule = self::match_rule( $organizer_id, $event_id, $category );
		if ( $rule && in_array( $rule['fee_type'] ?? '', array( 'percent', 'hybrid' ), true ) ) {
			return self::apply_rule( $rule, $vendor_fee );
		}
		$settings = lnkup_get_settings();
		$pct      = (float) ( $settings['organizer_commission_percent'] ?? 6 );
		return round( max( 0, $vendor_fee ) * ( $pct / 100 ), 2 );
	}

	/**
	 * Total marketplace revenue (Stripe application_fee).
	 *
	 * @param float  $vendor_fee   Booth price.
	 * @param int    $organizer_id Organizer user ID.
	 * @param int    $event_id     Event ID.
	 * @param string $category     Vendor category slug.
	 */
	public static function resolve_platform_fee( $vendor_fee, $organizer_id = 0, $event_id = 0, $category = '' ) {
		return round(
			self::resolve_vendor_checkout_fee( $organizer_id, $event_id, $category )
			+ self::resolve_organizer_commission( $vendor_fee, $organizer_id, $event_id, $category ),
			2
		);
	}

	/**
	 * @param int    $organizer_id Organizer ID.
	 * @param int    $event_id     Event ID.
	 * @param string $category     Category slug.
	 */
	private static function match_rule( $organizer_id, $event_id, $category ) {
		global $wpdb;
		$table = LNKup_Financial_Tables::fee_rules_table();
		if ( ! LNKup_Financial_Tables::table_exists( $table ) ) {
			return null;
		}
		$rules = $wpdb->get_results(
			"SELECT * FROM {$table} WHERE status = 'active' ORDER BY priority ASC, id ASC",
			ARRAY_A
		);
		foreach ( $rules as $rule ) {
			$scope = $rule['scope_type'] ?? 'global';
			$scope_id = $rule['scope_id'] ?? '';
			if ( 'organizer' === $scope && (int) $scope_id !== $organizer_id ) {
				continue;
			}
			if ( 'event' === $scope && (int) $scope_id !== $event_id ) {
				continue;
			}
			if ( 'category' === $scope && $scope_id !== $category ) {
				continue;
			}
			return $rule;
		}
		return null;
	}

	/**
	 * @param array $rule       Rule row.
	 * @param float $vendor_fee Base amount.
	 */
	private static function apply_rule( $rule, $vendor_fee ) {
		$type  = $rule['fee_type'] ?? 'flat';
		$value = (float) ( $rule['fee_value'] ?? 0 );
		$min   = isset( $rule['fee_min'] ) ? (float) $rule['fee_min'] : null;
		$max   = isset( $rule['fee_max'] ) ? (float) $rule['fee_max'] : null;
		$fee   = 0;

		switch ( $type ) {
			case 'percent':
				$fee = round( $vendor_fee * ( $value / 100 ), 2 );
				break;
			case 'hybrid':
				$fee = round( (float) ( $rule['fee_flat'] ?? 0 ) + $vendor_fee * ( $value / 100 ), 2 );
				break;
			default:
				$fee = round( $value, 2 );
		}
		if ( null !== $min ) {
			$fee = max( $fee, $min );
		}
		if ( null !== $max ) {
			$fee = min( $fee, $max );
		}
		return $fee;
	}

	/**
	 * @param int $organizer_id Organizer ID.
	 * @param int $event_id     Event ID.
	 */
	private static function resolve_tax_rate( $organizer_id, $event_id ) {
		$profile = LNKup_Tax_Profiles::get_or_create( $organizer_id );
		return (float) ( $profile['sales_tax_rate'] ?? 0 );
	}

	/**
	 * Full treasury breakdown for a completed payment.
	 *
	 * @param int $payment_id Payment post ID.
	 * @return array
	 */
	public static function calculate_for_payment( $payment_id ) {
		$vendor_fee   = (float) get_post_meta( $payment_id, '_lnkup_vendor_spot_fee', true );
		$organizer_id = (int) get_post_meta( $payment_id, '_lnkup_organizer_user_id', true );
		$event_id     = (int) get_post_meta( $payment_id, '_lnkup_event_id', true );
		$discount     = (float) get_post_meta( $payment_id, '_lnkup_discount_amount', true );
		$credit       = (float) get_post_meta( $payment_id, '_lnkup_credit_applied', true );
		$gross        = (float) get_post_meta( $payment_id, '_lnkup_total_amount', true );

		$base = self::calculate( array(
			'vendor_fee'   => $vendor_fee,
			'organizer_id' => $organizer_id,
			'event_id'     => $event_id,
			'discount'     => $discount,
			'credit'       => $credit,
		) );

		$platform_fee      = (float) ( $base['platform_fee'] ?? 0 );
		$organizer_net     = (float) ( $base['organizer_net'] ?? 0 );
		$settings          = lnkup_get_settings();
		$reserve_pct       = (float) ( $settings['reserve_percent'] ?? 0 );
		$reserve_amt       = round( $organizer_net * ( $reserve_pct / 100 ), 2 );
		$payout_eligible   = max( 0, round( $organizer_net - $reserve_amt, 2 ) );
		$stripe_fee_est    = round( $gross * self::PROCESSING_RATE + self::PROCESSING_FLAT, 2 );
		$fee_payer         = $settings['fee_payer_mode'] ?? 'vendor';

		return array(
			'gross_amount'             => round( $gross, 2 ),
			'vendor_fee'               => round( $vendor_fee, 2 ),
			'vendor_checkout_fee'      => (float) ( $base['vendor_checkout_fee'] ?? 0 ),
			'organizer_commission'     => (float) ( $base['organizer_commission'] ?? 0 ),
			'booth_reservation_total'  => (float) ( $base['booth_reservation_total'] ?? 0 ),
			'organizer_net'            => $organizer_net,
			'lnkup_platform_fee'       => $platform_fee,
			'platform_fee'             => $platform_fee,
			'processing_fee'           => (float) ( $base['processing_fee'] ?? 0 ),
			'stripe_fee'               => $stripe_fee_est,
			'tax_amount'               => (float) ( $base['tax_amount'] ?? 0 ),
			'discount_amount'          => round( $discount, 2 ),
			'credit_amount'            => round( $credit, 2 ),
			'reserve_amount'           => $reserve_amt,
			'reserve_hold'             => $reserve_amt,
			'payout_eligible_amount'   => $payout_eligible,
			'fee_payer_mode'           => $fee_payer,
			'fee_rule_id'              => 0,
			'credits_applied'          => round( $credit, 2 ),
		);
	}

	/**
	 * Seed default global fee rule if none exist.
	 */
	public static function seed_defaults() {
		global $wpdb;
		$table = LNKup_Financial_Tables::fee_rules_table();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		if ( $count > 0 ) {
			return;
		}
		$settings = lnkup_get_settings();
		$wpdb->insert(
			$table,
			array(
				'name'       => 'Default organizer commission',
				'scope_type' => 'global',
				'scope_id'   => '',
				'fee_type'   => 'percent',
				'fee_value'  => (float) ( $settings['organizer_commission_percent'] ?? 6 ),
				'priority'   => 100,
				'status'     => 'active',
				'created_at' => current_time( 'mysql' ),
			)
		);
	}
}
