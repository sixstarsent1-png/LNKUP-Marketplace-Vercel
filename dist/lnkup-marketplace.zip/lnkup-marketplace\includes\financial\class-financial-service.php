<?php
/**
 * Central financial service — single entry point for all payment operations.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Financial_Service {

	public static function init() {
		LNKup_Payment_Timeline::init();
		LNKup_Financial_Activity::init_hooks();
		LNKup_Stripe_Webhooks::init();
	}

	/**
	 * Get active payment provider.
	 */
	public static function provider() {
		return LNKup_Payment_Provider::get_instance();
	}

	/**
	 * Checkout amount after credits/installments/deposits.
	 *
	 * @param int $payment_id Payment post ID.
	 */
	public static function get_checkout_amount( $payment_id ) {
		$total       = (float) get_post_meta( $payment_id, '_lnkup_total_amount', true );
		$credit      = (float) get_post_meta( $payment_id, '_lnkup_credit_applied', true );
		$installment = (float) get_post_meta( $payment_id, '_lnkup_installment_amount', true );
		if ( $installment > 0 ) {
			return max( 0, round( $installment - $credit, 2 ) );
		}
		return max( 0, round( $total - $credit, 2 ) );
	}

	/**
	 * Create checkout (legacy redirect or embedded prepare).
	 *
	 * @param int   $payment_id Payment ID.
	 * @param array $args       mode: embedded|redirect.
	 */
	public static function create_checkout( $payment_id, $args = array() ) {
		$mode = $args['mode'] ?? 'embedded';
		if ( 'redirect' === $mode ) {
			return self::provider()->create_checkout_session( $payment_id );
		}
		return LNKup_Checkout::prepare( $payment_id, $args );
	}

	/**
	 * @param int $payment_id Payment ID.
	 */
	public static function get_checkout_summary( $payment_id ) {
		return LNKup_Checkout::get_summary( $payment_id );
	}

	/**
	 * @param int   $payment_id Payment ID.
	 * @param array $args       Args.
	 */
	public static function prepare_checkout( $payment_id, $args = array() ) {
		return LNKup_Checkout::prepare( $payment_id, $args );
	}

	/**
	 * @param int   $payment_id Payment ID.
	 * @param float $amount     Credit amount.
	 */
	public static function apply_wallet_credits( $payment_id, $amount = 0 ) {
		return LNKup_Checkout::apply_credits( $payment_id, $amount );
	}

	/**
	 * Finalize payment after Stripe confirmation.
	 *
	 * @param int    $payment_id Payment ID.
	 * @param string $intent_id  Stripe intent ID.
	 * @param array  $context    Extra context.
	 */
	public static function finalize_payment( $payment_id, $intent_id = '', $context = array() ) {
		$status = get_post_meta( $payment_id, '_lnkup_payment_status', true );
		if ( 'paid' === $status ) {
			if ( class_exists( 'LNKup_Financial_Audit' ) ) {
				LNKup_Financial_Audit::log( 'finalize_skipped', 'payment', $payment_id, array_merge( $context, array( 'reason' => 'already_paid' ) ) );
			}
			return array( 'already_paid' => true );
		}

		if ( $intent_id ) {
			self::backfill_stripe_payment_meta( $payment_id, $intent_id );
		}

		LNKup_Payments::mark_paid( $payment_id, $intent_id );
		LNKup_Transactions::sync_extended_fields( $payment_id );

		self::settle_treasury( $payment_id );

		if ( class_exists( 'LNKup_Financial_Audit' ) ) {
			LNKup_Financial_Audit::log( 'finalize_completed', 'payment', $payment_id, array_merge( $context, array(
				'ledger' => class_exists( 'LNKup_Organizer_Wallet' ) && LNKup_Organizer_Wallet::has_connect_settlement_for_payment( $payment_id ),
			) ) );
		}

		do_action( 'lnkup_payment_completed', $payment_id );

		return array( 'success' => true, 'payment_id' => $payment_id, 'context' => $context );
	}

	/**
	 * Idempotent reconcile when webhooks were missed or ledger is empty.
	 *
	 * @param int    $payment_id Payment post ID.
	 * @param string $intent_id  Optional Stripe PaymentIntent ID.
	 */
	public static function reconcile_payment( $payment_id, $intent_id = '' ) {
		$payment_id = absint( $payment_id );
		if ( ! $payment_id || 'lnkup_payment' !== get_post_type( $payment_id ) ) {
			return new WP_Error( 'invalid_payment', __( 'Invalid payment.', 'lnkup-marketplace' ), array( 'status' => 400 ) );
		}

		self::backfill_stripe_payment_meta( $payment_id, $intent_id );

		$status = get_post_meta( $payment_id, '_lnkup_payment_status', true );
		if ( 'paid' !== $status ) {
			return self::finalize_payment( $payment_id, $intent_id, array( 'source' => 'reconcile' ) );
		}

		$mode = get_post_meta( $payment_id, '_lnkup_settlement_mode', true );
		if ( 'destination' === $mode && class_exists( 'LNKup_Organizer_Wallet' ) ) {
			if ( ! LNKup_Organizer_Wallet::has_connect_settlement_for_payment( $payment_id ) ) {
				self::settle_treasury( $payment_id );
				return array( 'success' => true, 'action' => 'settlement_backfilled', 'payment_id' => $payment_id );
			}
		}

		return array( 'success' => true, 'action' => 'already_settled', 'payment_id' => $payment_id );
	}

	/**
	 * Sync Stripe PaymentIntent amounts into payment meta.
	 *
	 * @param int    $payment_id Payment post ID.
	 * @param string $intent_id  Stripe PaymentIntent ID.
	 */
	public static function backfill_stripe_payment_meta( $payment_id, $intent_id = '' ) {
		$intent_id = $intent_id ?: (string) get_post_meta( $payment_id, '_lnkup_stripe_payment_intent', true );
		if ( ! $intent_id || ! class_exists( 'LNKup_Stripe_Client' ) ) {
			return false;
		}

		$client = new LNKup_Stripe_Client();
		$intent = $client->retrieve_payment_intent( $intent_id );
		if ( is_wp_error( $intent ) ) {
			return $intent;
		}

		$amount_cents    = (int) ( $intent['amount'] ?? 0 );
		$app_fee_cents   = (int) ( $intent['application_fee_amount'] ?? 0 );
		$destination     = $intent['transfer_data']['destination'] ?? '';

		if ( $amount_cents > 0 ) {
			update_post_meta( $payment_id, '_lnkup_stripe_charge_amount_cents', $amount_cents );
		}
		if ( $app_fee_cents > 0 ) {
			update_post_meta( $payment_id, '_lnkup_application_fee_cents', $app_fee_cents );
			update_post_meta( $payment_id, '_lnkup_lnkup_fee', $app_fee_cents / 100 );
		}
		if ( $destination ) {
			update_post_meta( $payment_id, '_lnkup_stripe_destination_account', sanitize_text_field( $destination ) );
		}
		if ( $amount_cents > 0 && $app_fee_cents >= 0 ) {
			update_post_meta( $payment_id, '_lnkup_stripe_destination_amount', ( $amount_cents - $app_fee_cents ) / 100 );
		}

		return true;
	}

	/**
	 * Treasury settlement pipeline after payment marked paid.
	 *
	 * @param int $payment_id Payment post ID.
	 */
	public static function settle_treasury( $payment_id ) {
		if ( ! class_exists( 'LNKup_Fee_Engine' ) ) {
			return;
		}
		$organizer_id = (int) get_post_meta( $payment_id, '_lnkup_organizer_user_id', true );
		$breakdown    = LNKup_Fee_Engine::calculate_for_payment( $payment_id );
		if ( class_exists( 'LNKup_Stripe_Connect' ) ) {
			LNKup_Stripe_Connect::persist_payment_settlement_meta( $payment_id, $organizer_id, $breakdown );
		}
		$mode = get_post_meta( $payment_id, '_lnkup_settlement_mode', true ) ?: 'platform_treasury';
		if ( class_exists( 'LNKup_Transactions' ) ) {
			LNKup_Transactions::sync_settlement_fields( $payment_id, $breakdown, $mode );
		}
		if ( class_exists( 'LNKup_Platform_Fees' ) ) {
			LNKup_Platform_Fees::record( $payment_id, $breakdown );
		}
		if ( class_exists( 'LNKup_Reserves' ) ) {
			LNKup_Reserves::maybe_hold( $payment_id, $breakdown );
		}
		if ( class_exists( 'LNKup_Organizer_Wallet' ) ) {
			LNKup_Organizer_Wallet::credit_from_payment( $payment_id, $breakdown );
		}
		if ( 'platform_treasury' === $mode && class_exists( 'LNKup_Escrow' ) ) {
			LNKup_Escrow::maybe_hold( $payment_id, $breakdown );
		}
		if ( class_exists( 'LNKup_Payment_Timeline' ) ) {
			$note = 'destination' === $mode
				? __( 'Connect destination settlement recorded (ledger mirror)', 'lnkup-marketplace' )
				: __( 'Treasury settlement recorded', 'lnkup-marketplace' );
			LNKup_Payment_Timeline::record( $payment_id, 'settled', array( 'notes' => $note ) );
		}
		if ( class_exists( 'LNKup_Financial_Activity' ) ) {
			LNKup_Financial_Activity::record( 'payment_settled', array(
				'user_id'     => $organizer_id,
				'role'        => 'organizer',
				'entity_type' => 'payment',
				'entity_id'   => $payment_id,
				'message'     => sprintf(
					/* translators: 1: settlement mode 2: amount */
					__( 'Payment settled (%1$s) — organizer net $%2$s', 'lnkup-marketplace' ),
					$mode,
					number_format( (float) ( $breakdown['organizer_net'] ?? 0 ), 2 )
				),
			) );
		}
		LNKup_Financial_Audit::log( 'treasury_settled', 'payment', $payment_id, array_merge( $breakdown, array( 'settlement_mode' => $mode ) ) );
	}

	/**
	 * Request organizer cashout.
	 *
	 * @param int    $user_id Organizer user ID.
	 * @param float  $amount  Amount.
	 * @param string $type    Payout type.
	 */
	public static function request_organizer_cashout( $user_id, $amount, $type = 'standard' ) {
		return LNKup_Organizer_Payouts::request_cashout( $user_id, $amount, $type );
	}

	/**
	 * Get organizer wallet balances.
	 *
	 * @param int $user_id Organizer user ID.
	 */
	public static function organizer_wallet( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		$balances = LNKup_Organizer_Wallet::get_balances( $user_id );
		$connect  = class_exists( 'LNKup_Stripe_Connect' ) ? LNKup_Stripe_Connect::onboarding_status( $user_id ) : array( 'status' => 'not_started', 'available' => false );
		$stripe_balance = self::organizer_stripe_balance( $user_id );
		if ( ! empty( $stripe_balance['synced'] ) ) {
			$balances['stripe_balance'] = $stripe_balance;
		}
		return array(
			'balances'       => $balances,
			'entries'        => LNKup_Organizer_Wallet::list_entries( $user_id ),
			'escrow'         => class_exists( 'LNKup_Escrow' ) ? LNKup_Escrow::list_for_user( $user_id ) : array(),
			'reserves'       => class_exists( 'LNKup_Reserves' ) ? LNKup_Reserves::list_for_user( $user_id ) : array(),
			'connect'        => $connect,
			'stripe_balance' => $stripe_balance,
		);
	}

	/**
	 * Stripe Connect balance for destination-mode organizers.
	 *
	 * @param int $user_id Organizer user ID.
	 */
	public static function organizer_stripe_balance( $user_id ) {
		if ( ! class_exists( 'LNKup_Stripe_Connect' ) ) {
			return array( 'available' => 0, 'pending' => 0, 'synced' => false );
		}
		if ( 'destination' !== LNKup_Stripe_Connect::settlement_mode_for_organizer( $user_id ) ) {
			return array( 'available' => 0, 'pending' => 0, 'synced' => false );
		}
		return LNKup_Stripe_Connect::retrieve_connect_balance( $user_id );
	}

	/**
	 * Confirm checkout from client after Payment Element success.
	 *
	 * @param int    $payment_id Payment ID.
	 * @param string $intent_id  Intent ID.
	 */
	public static function confirm_checkout( $payment_id, $intent_id ) {
		$provider = self::provider();
		$intent   = $provider->confirm_payment_intent( $intent_id );
		if ( is_wp_error( $intent ) ) {
			return $intent;
		}
		$status = is_array( $intent ) ? ( $intent['status'] ?? '' ) : '';
		if ( 'succeeded' === $status || 0 === strpos( (string) $intent_id, 'sim_' ) ) {
			return self::finalize_payment( $payment_id, $intent_id, array( 'source' => 'client_confirm' ) );
		}
		return new WP_Error( 'payment_incomplete', __( 'Payment not completed.', 'lnkup-marketplace' ) );
	}

	/**
	 * Process refund through provider.
	 *
	 * @param int   $payment_id Payment ID.
	 * @param float $amount     Amount.
	 */
	public static function refund( $payment_id, $amount ) {
		return self::provider()->refund( $payment_id, $amount );
	}

	/**
	 * Handle Stripe webhook request.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public static function handle_webhook( $request ) {
		$settings = lnkup_get_settings();
		$payload  = $request->get_body();
		$sig      = $request->get_header( 'stripe-signature' );
		$client   = new LNKup_Stripe_Client();
		$event    = $client->verify_webhook( $payload, $sig, $settings['stripe_webhook_secret'] ?? '' );

		if ( is_wp_error( $event ) ) {
			if ( empty( $settings['test_mode'] ) ) {
				return new WP_REST_Response( array( 'error' => $event->get_error_message() ), 400 );
			}
			$event = json_decode( $payload, true );
		}

		if ( empty( $event['type'] ) ) {
			return new WP_REST_Response( array( 'received' => true ), 200 );
		}

		$log_id = LNKup_Stripe_Webhooks::log_event( $event );
		if ( LNKup_Stripe_Webhooks::is_event_processed( $log_id ) ) {
			return new WP_REST_Response( array( 'received' => true, 'duplicate' => true ), 200 );
		}
		$result = LNKup_Stripe_Webhooks::process_event( $event, $log_id );
		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'error' => $result->get_error_message() ), 500 );
		}
		return new WP_REST_Response( array( 'received' => true ), 200 );
	}

	/**
	 * Vendor dashboard summary (delegates to LNKup_Financial).
	 *
	 * @param int $user_id User ID.
	 */
	public static function vendor_dashboard( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		$base    = LNKup_Financial::vendor_dashboard( $user_id );
		$report  = LNKup_Financial_Reports::vendor_report( $user_id );
		return array_merge( $base, $report, array(
			'charts' => array(
				'monthly_spending' => $report['by_month'] ?? array(),
			),
		) );
	}

	/**
	 * Organizer dashboard summary.
	 *
	 * @param int $user_id User ID.
	 */
	public static function organizer_dashboard( $user_id = 0 ) {
		$uid = $user_id ?: get_current_user_id();
		try {
			$data    = LNKup_Financial::organizer_dashboard( $uid );
			$reports = LNKup_Financial_Reports::organizer_report( $uid );
		} catch ( Throwable $e ) {
			return self::organizer_dashboard_zero( $uid );
		}
		$wallet = array();
		if ( class_exists( 'LNKup_Organizer_Wallet' ) ) {
			try {
				$wallet = LNKup_Organizer_Wallet::get_balances( $uid );
			} catch ( Throwable $e ) {
				$wallet = array();
			}
		}
		$health = array();
		if ( class_exists( 'LNKup_Financial_Health_Score' ) ) {
			try {
				$health = LNKup_Financial_Health_Score::get_latest( $uid, 'organizer' );
			} catch ( Throwable $e ) {
				$health = array();
			}
		}
		$connect = array();
		if ( class_exists( 'LNKup_Stripe_Connect' ) ) {
			try {
				$connect = LNKup_Stripe_Connect::onboarding_status( $uid );
			} catch ( Throwable $e ) {
				$connect = array();
			}
		}
		$sponsor_revenue = 0;
		if ( class_exists( 'LNKup_Sponsor_Payments' ) ) {
			try {
				$sponsor_revenue = LNKup_Sponsor_Payments::total_revenue( $uid );
			} catch ( Throwable $e ) {
				$sponsor_revenue = 0;
			}
		}
		$payouts_paid = 0;
		if ( class_exists( 'LNKup_Organizer_Payouts' ) ) {
			try {
				$payouts = LNKup_Organizer_Payouts::list_for_user( $uid, 100 );
				foreach ( (array) $payouts as $p ) {
					if ( in_array( $p['status'] ?? '', array( 'completed', 'paid' ), true ) ) {
						$payouts_paid += (float) ( $p['net_amount'] ?? $p['amount'] ?? 0 );
					}
				}
				$payouts_paid = round( $payouts_paid, 2 );
			} catch ( Throwable $e ) {
				$payouts_paid = 0;
			}
		}
		$stripe_balance = self::organizer_stripe_balance( $uid );
		if ( ! empty( $stripe_balance['synced'] ) && is_array( $wallet ) ) {
			$wallet['stripe_balance'] = $stripe_balance;
		}
		return array_merge( $data, array(
			'gross_revenue'       => $reports['gross_revenue'] ?? $data['vendor_revenue'],
			'platform_fees'       => $reports['platform_fees'] ?? 0,
			'collected'           => $data['vendor_revenue'],
			'refunds'             => $reports['refunds'] ?? 0,
			'outstanding'         => $reports['outstanding'] ?? 0,
			'pending_balance'     => (float) ( $wallet['pending'] ?? $data['wallet_pending'] ?? 0 ),
			'processing_balance'  => (float) ( $wallet['processing'] ?? 0 ),
			'reserve_balance'     => (float) ( $wallet['reserve_hold'] ?? $data['reserve_hold'] ?? 0 ),
			'payouts_paid'        => $payouts_paid,
			'open_invoices'       => (int) ( $reports['outstanding'] ?? 0 ) > 0 ? 1 : 0,
			'overdue_invoices'    => 0,
			'chargebacks'           => (int) ( $reports['open_disputes'] ?? $data['open_disputes'] ?? 0 ),
			'wallet'                => $wallet,
			'health_score'          => $health,
			'sponsor_revenue'       => $sponsor_revenue,
			'connect'               => $connect,
			'stripe_balance'        => $stripe_balance,
			'connect_status'        => array(
				'enabled'    => ( 'active' === ( $connect['status'] ?? '' ) ),
				'status'     => $connect['status'] ?? 'not_started',
				'settlement' => $connect['settlement_mode'] ?? 'destination',
			),
			'charts'                => array(
				'revenue_by_event'  => $reports['by_event'] ?? array(),
				'revenue_by_month'  => $reports['by_month'] ?? array(),
				'vendor_categories' => $reports['by_category'] ?? array(),
				'completion_rate'   => $reports['completion_rate'] ?? 0,
			),
		) );
	}

	/**
	 * Admin dashboard summary.
	 */
	public static function admin_dashboard() {
		return LNKup_Financial::admin_dashboard();
	}

	/**
	 * Calculate payout split for organizer.
	 *
	 * @param float $gross      Gross amount.
	 * @param int   $organizer_id Organizer ID.
	 */
	public static function calculate_payout_split( $gross, $organizer_id ) {
		return LNKup_Stripe_Connect::calculate_payout_split( $gross, $organizer_id );
	}

	/**
	 * Payment timeline for payment.
	 *
	 * @param int $payment_id Payment ID.
	 */
	public static function get_timeline( $payment_id ) {
		return LNKup_Payment_Timeline::list_for_payment( $payment_id );
	}

	/**
	 * Activity feed for user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $role    Role.
	 * @param int    $limit   Limit.
	 */
	public static function get_activity( $user_id, $role = 'vendor', $limit = 25 ) {
		return LNKup_Financial_Activity::list_for_user( $user_id, $role, $limit );
	}

	/**
	 * Zero-state organizer dashboard when data layer fails.
	 *
	 * @param int $user_id User ID.
	 */
	public static function organizer_dashboard_zero( $user_id = 0 ) {
		$uid     = $user_id ?: get_current_user_id();
		$connect = array( 'status' => 'not_started', 'settlement_mode' => 'destination', 'available' => false );
		if ( class_exists( 'LNKup_Stripe_Connect' ) ) {
			try {
				$connect = LNKup_Stripe_Connect::onboarding_status( $uid );
			} catch ( Throwable $e ) {
				// Keep stub.
			}
		}
		return array(
			'vendor_revenue'     => 0,
			'gross_revenue'      => 0,
			'available_balance'  => 0,
			'pending_balance'    => 0,
			'wallet_pending'     => 0,
			'processing_balance' => 0,
			'reserve_balance'    => 0,
			'reserve_hold'       => 0,
			'platform_fees'      => 0,
			'stripe_fees'        => 0,
			'payouts_paid'       => 0,
			'refunds'            => 0,
			'chargebacks'        => 0,
			'collected'          => 0,
			'outstanding'        => 0,
			'pending_revenue'    => 0,
			'open_invoices'      => 0,
			'overdue_invoices'   => 0,
			'sponsor_revenue'    => 0,
			'payout_count'       => 0,
			'wallet'             => array(
				'available'    => 0,
				'pending'      => 0,
				'processing'   => 0,
				'reserve_hold' => 0,
			),
			'connect'            => $connect,
			'connect_status'     => array(
				'enabled'    => ( 'active' === ( $connect['status'] ?? '' ) ),
				'status'     => $connect['status'] ?? 'not_started',
				'settlement' => $connect['settlement_mode'] ?? 'destination',
			),
			'health_score'       => array(),
			'charts'             => array(
				'revenue_by_event' => array(),
				'revenue_by_month' => array(),
			),
		);
	}
}
