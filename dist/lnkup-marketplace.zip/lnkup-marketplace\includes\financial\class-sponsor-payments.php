<?php
/**
 * Sponsor invoice and payment management.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Sponsor_Payments {

	/**
	 * Create sponsor invoice.
	 *
	 * @param array $data Invoice data.
	 */
	public static function create_invoice( $data ) {
		global $wpdb;
		$table = LNKup_Treasury_Tables::sponsor_invoices_table();
		if ( ! LNKup_Financial_Tables::table_exists( $table ) ) {
			return 0;
		}
		$now = current_time( 'mysql' );
		$wpdb->insert(
			$table,
			array(
				'organizer_user_id' => absint( $data['organizer_user_id'] ?? 0 ),
				'event_id'          => absint( $data['event_id'] ?? 0 ),
				'sponsor_name'      => sanitize_text_field( $data['sponsor_name'] ?? '' ),
				'sponsor_email'     => sanitize_email( $data['sponsor_email'] ?? '' ),
				'amount'            => round( (float) ( $data['amount'] ?? 0 ), 2 ),
				'status'            => 'draft',
				'due_date'          => sanitize_text_field( $data['due_date'] ?? '' ),
				'notes'             => sanitize_textarea_field( $data['notes'] ?? '' ),
				'created_at'        => $now,
				'updated_at'        => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * List sponsor invoices for organizer.
	 *
	 * @param int $user_id Organizer user ID.
	 */
	public static function list_invoices( $user_id ) {
		global $wpdb;
		$table = LNKup_Treasury_Tables::sponsor_invoices_table();
		if ( ! LNKup_Financial_Tables::table_exists( $table ) ) {
			return array();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE organizer_user_id = %d ORDER BY created_at DESC LIMIT 50", absint( $user_id ) ),
			ARRAY_A
		);
	}

	/**
	 * Record sponsor payment.
	 *
	 * @param int   $invoice_id Invoice ID.
	 * @param float $amount     Amount paid.
	 * @param array $meta       Metadata.
	 */
	public static function record_payment( $invoice_id, $amount, $meta = array() ) {
		global $wpdb;
		$inv_table = LNKup_Treasury_Tables::sponsor_invoices_table();
		$pay_table = LNKup_Treasury_Tables::sponsor_payments_table();
		$invoice   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$inv_table} WHERE id = %d", absint( $invoice_id ) ), ARRAY_A );
		if ( ! $invoice ) {
			return new WP_Error( 'not_found', __( 'Sponsor invoice not found.', 'lnkup-marketplace' ) );
		}
		$now = current_time( 'mysql' );
		$wpdb->insert(
			$pay_table,
			array(
				'invoice_id'        => absint( $invoice_id ),
				'organizer_user_id' => (int) $invoice['organizer_user_id'],
				'amount'            => round( (float) $amount, 2 ),
				'payment_method'    => sanitize_key( $meta['payment_method'] ?? 'manual' ),
				'provider_ref'      => sanitize_text_field( $meta['provider_ref'] ?? '' ),
				'status'            => 'completed',
				'created_at'        => $now,
			)
		);
		$wpdb->update( $inv_table, array( 'status' => 'paid', 'updated_at' => $now ), array( 'id' => $invoice_id ) );
		if ( class_exists( 'LNKup_Organizer_Wallet' ) ) {
			LNKup_Organizer_Wallet::add_entry(
				(int) $invoice['organizer_user_id'],
				(float) $amount,
				'available',
				array(
					'source_type' => 'sponsor_payment',
					'source_id'   => $invoice_id,
					'note'        => __( 'Sponsor payment received', 'lnkup-marketplace' ),
				)
			);
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Sum sponsor revenue for organizer.
	 *
	 * @param int $user_id Organizer user ID.
	 */
	public static function total_revenue( $user_id ) {
		global $wpdb;
		$table = LNKup_Treasury_Tables::sponsor_payments_table();
		if ( ! LNKup_Financial_Tables::table_exists( $table ) ) {
			return 0.0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (float) $wpdb->get_var(
			$wpdb->prepare( "SELECT COALESCE(SUM(amount), 0) FROM {$table} WHERE organizer_user_id = %d AND status = 'completed'", absint( $user_id ) )
		);
	}
}
