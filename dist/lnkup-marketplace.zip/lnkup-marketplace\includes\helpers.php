<?php
/**
 * Helper functions.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

/**
 * Format currency.
 *
 * @param float $amount Amount.
 */
function lnkup_currency( $amount ) {
	return '$' . number_format( (float) $amount, 2 );
}

/**
 * Get vendor profile for user.
 *
 * @param int $user_id User ID.
 */
function lnkup_get_vendor_profile_id( $user_id = 0 ) {
	$user_id = $user_id ?: get_current_user_id();
	$posts = get_posts(
		array(
			'post_type'      => 'lnkup_vendor_profile',
			'posts_per_page' => 1,
			'meta_key'       => '_lnkup_owner_user_id',
			'meta_value'     => $user_id,
			'fields'         => 'ids',
		)
	);
	return $posts[0] ?? 0;
}

/**
 * Get featured opportunities.
 *
 * @param int $limit Limit.
 */
function lnkup_get_featured_opportunities( $limit = 6 ) {
	if ( lnkup_marketplace_phase_at_least( '1b' ) && class_exists( 'LNKup_Trending' ) ) {
		$items = LNKup_Trending::get_section( 'trending', $limit );
		if ( $items ) {
			return $items;
		}
	}
	$posts = get_posts(
		array(
			'post_type'      => 'lnkup_opportunity',
			'posts_per_page' => $limit,
			'post_status'    => 'publish',
			'meta_query'     => array(
				array(
					'key'   => '_lnkup_opportunity_status',
					'value' => 'open',
				),
			),
		)
	);
	$result = array();
	foreach ( $posts as $post ) {
		$result[] = lnkup_format_opportunity( $post );
	}
	return $result;
}

/**
 * Format opportunity for display.
 *
 * @param WP_Post $opp Opportunity post.
 */
function lnkup_format_opportunity( $opp ) {
	$event_id = (int) get_post_meta( $opp->ID, '_lnkup_event_id', true );
	$event    = $event_id ? get_post( $event_id ) : null;
	$terms    = wp_get_post_terms( $opp->ID, 'lnkup_vendor_category', array( 'fields' => 'names' ) );

	return array(
		'id'           => $opp->ID,
		'name'         => $event ? $event->post_title : $opp->post_title,
		'city'         => $event ? get_post_meta( $event_id, '_lnkup_city', true ) : '',
		'state'        => $event ? get_post_meta( $event_id, '_lnkup_state', true ) : '',
		'date'         => $event ? get_post_meta( $event_id, '_lnkup_event_date', true ) : '',
		'attendance'   => $event ? (int) get_post_meta( $event_id, '_lnkup_expected_attendance', true ) : 0,
		'vendor_fee'   => (float) get_post_meta( $opp->ID, '_lnkup_vendor_fee', true ),
		'spots_remaining' => (int) get_post_meta( $opp->ID, '_lnkup_spots_remaining', true ),
		'total_spots'  => (int) get_post_meta( $opp->ID, '_lnkup_spots_total', true ),
		'categories'   => is_array( $terms ) ? $terms : array(),
		'deadline'     => get_post_meta( $opp->ID, '_lnkup_application_deadline', true ),
		'opportunity_id' => $opp->ID,
		'event_id'     => $event_id,
	);
}

/**
 * Page URL helper (works without theme).
 *
 * @param string $slug Page slug.
 */
function lnkup_page_url_helper( $slug ) {
	$pages = get_option( 'lnkup_pages_created', array() );
	if ( ! empty( $pages[ $slug ] ) ) {
		return get_permalink( $pages[ $slug ] );
	}
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Dashboard breadcrumb trail.
 *
 * @param array $items Each item: label (required), href (optional for current page).
 */
function lnkup_dash_breadcrumb( array $items ) {
	if ( ! $items ) {
		return '';
	}
	ob_start();
	?>
	<nav class="lnkup-dash-breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'lnkup-marketplace' ); ?>">
		<ol class="lnkup-dash-breadcrumb__list">
			<?php foreach ( $items as $index => $item ) : ?>
				<?php
				$is_last = ( $index === count( $items ) - 1 );
				$label   = $item['label'] ?? '';
				$href    = $item['href'] ?? '';
				?>
				<li class="lnkup-dash-breadcrumb__item">
					<?php if ( ! $is_last && $href ) : ?>
						<a href="<?php echo esc_url( $href ); ?>"><?php echo esc_html( $label ); ?></a>
					<?php else : ?>
						<span aria-current="page"><?php echo esc_html( $label ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</nav>
	<?php
	return ob_get_clean();
}

/**
 * Dashboard sub-navigation tabs.
 *
 * @param array  $tabs    Tab definitions: id, label, href (optional).
 * @param string $current Active tab id.
 */
function lnkup_dash_subnav( array $tabs, $current = '' ) {
	if ( ! $tabs ) {
		return '';
	}
	ob_start();
	?>
	<nav class="lnkup-dash-subnav" role="tablist" aria-label="<?php esc_attr_e( 'Sections', 'lnkup-marketplace' ); ?>">
		<?php foreach ( $tabs as $tab ) : ?>
			<?php
			$id    = $tab['id'] ?? '';
			$label = $tab['label'] ?? '';
			$href  = $tab['href'] ?? '#' . $id;
			$active = $id === $current;
			?>
			<a href="<?php echo esc_url( $href ); ?>" class="lnkup-dash-subnav__link<?php echo $active ? ' is-active' : ''; ?>" role="tab"<?php echo $active ? ' aria-current="page"' : ''; ?> data-subnav="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</nav>
	<?php
	return ob_get_clean();
}

/**
 * Reusable empty state block.
 *
 * @param string $title       Heading.
 * @param string $description Body copy.
 * @param string $cta_label   Primary button label.
 * @param string $cta_href    Primary button URL.
 */
function lnkup_empty_state( $title, $description, $cta_label = '', $cta_href = '' ) {
	ob_start();
	?>
	<div class="lnkup-empty-state">
		<h3 class="lnkup-empty-state__title"><?php echo esc_html( $title ); ?></h3>
		<?php if ( $description ) : ?>
			<p class="lnkup-empty-state__desc"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php if ( $cta_label && $cta_href ) : ?>
			<a href="<?php echo esc_url( $cta_href ); ?>" class="lnkup-btn lnkup-btn--primary"><?php echo esc_html( $cta_label ); ?></a>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Query applications for user.
 *
 * @param int    $user_id User ID.
 * @param string $role    vendor|organizer.
 */
function lnkup_get_applications_for_user( $user_id, $role = 'vendor' ) {
	$key = 'vendor' === $role ? '_lnkup_vendor_user_id' : '_lnkup_organizer_user_id';
	return get_posts(
		array(
			'post_type'      => 'lnkup_application',
			'posts_per_page' => -1,
			'meta_key'       => $key,
			'meta_value'     => $user_id,
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);
}

/**
 * Get payments for user.
 *
 * @param int    $user_id User ID.
 * @param string $role    vendor|organizer.
 */
function lnkup_get_payments_for_user( $user_id, $role = 'vendor' ) {
	$key = 'vendor' === $role ? '_lnkup_vendor_user_id' : '_lnkup_organizer_user_id';
	return get_posts(
		array(
			'post_type'      => 'lnkup_payment',
			'posts_per_page' => -1,
			'meta_key'       => $key,
			'meta_value'     => $user_id,
		)
	);
}

/**
 * Parse marketplace filter args from request array.
 *
 * @param array $source Request source ($_GET or POST).
 */
function lnkup_parse_marketplace_filters( $source = null ) {
	$source = is_array( $source ) ? $source : $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	$array_keys = array( 'categories', 'event_types', 'markets', 'doc_required' );
	$args       = array();
	$string_keys = array(
		'q', 'city', 'state', 'date_preset', 'date_from', 'date_to',
		'attendance_bucket', 'fee_bucket', 'environment', 'sort',
	);
	foreach ( $string_keys as $key ) {
		if ( isset( $source[ $key ] ) && '' !== $source[ $key ] ) {
			$args[ $key ] = sanitize_text_field( wp_unslash( $source[ $key ] ) );
		}
	}
	if ( isset( $source['s'] ) && ! isset( $args['q'] ) ) {
		$args['q'] = sanitize_text_field( wp_unslash( $source['s'] ) );
	}
	foreach ( $array_keys as $key ) {
		if ( ! empty( $source[ $key ] ) ) {
			$args[ $key ] = array_filter( array_map( 'sanitize_text_field', explode( ',', wp_unslash( $source[ $key ] ) ) ) );
		}
	}
	$num_keys = array( 'attendance_min', 'attendance_max', 'fee_min', 'fee_max', 'page', 'per_page', 'radius' );
	foreach ( $num_keys as $key ) {
		if ( isset( $source[ $key ] ) && '' !== $source[ $key ] ) {
			$args[ $key ] = 'page' === $key || 'per_page' === $key || 'attendance_min' === $key || 'attendance_max' === $key || 'radius' === $key
				? absint( $source[ $key ] )
				: (float) $source[ $key ];
		}
	}
	$bool_keys = array(
		'fee_free', 'indoor', 'outdoor', 'power_available', 'water_available',
		'food_truck_allowed', 'verified_organizer', 'featured_organizer',
		'instant_approval', 'has_spots', 'show_closed', 'newly_added',
		'closing_soon', 'almost_full', 'applications_open', 'doc_none',
	);
	foreach ( $bool_keys as $key ) {
		if ( isset( $source[ $key ] ) && '' !== $source[ $key ] ) {
			$args[ $key ] = rest_sanitize_boolean( $source[ $key ] );
		}
	}
	if ( ! isset( $args['has_spots'] ) && ! isset( $source['show_closed'] ) ) {
		$args['has_spots'] = true;
	}
	if ( ! empty( $args['q'] ) && empty( $args['sort'] ) ) {
		$args['sort'] = 'relevance';
	}
	return $args;
}

/**
 * Build active filter chip labels.
 *
 * @param array $args Filter args.
 */
function lnkup_build_active_filters( $args ) {
	$labels = array();
	$map    = array(
		'q'                 => __( 'Search', 'lnkup-marketplace' ),
		'city'              => __( 'City', 'lnkup-marketplace' ),
		'state'             => __( 'State', 'lnkup-marketplace' ),
		'date_preset'       => __( 'Date', 'lnkup-marketplace' ),
		'attendance_bucket' => __( 'Attendance', 'lnkup-marketplace' ),
		'fee_bucket'        => __( 'Fee', 'lnkup-marketplace' ),
		'environment'       => __( 'Environment', 'lnkup-marketplace' ),
		'sort'              => __( 'Sort', 'lnkup-marketplace' ),
	);
	foreach ( $map as $key => $label ) {
		if ( ! empty( $args[ $key ] ) ) {
			$display = 'q' === $key
				? sprintf( __( 'Search: %s', 'lnkup-marketplace' ), $args[ $key ] )
				: $label . ': ' . $args[ $key ];
			$labels[] = array( 'key' => $key, 'value' => $args[ $key ], 'label' => $display );
		}
	}
	foreach ( array( 'categories', 'event_types', 'markets' ) as $tax_key ) {
		foreach ( array_filter( (array) ( $args[ $tax_key ] ?? array() ) ) as $term ) {
			$labels[] = array( 'key' => $tax_key, 'value' => $term, 'label' => $term );
		}
	}
	$bool_labels = array(
		'fee_free'           => __( 'Free', 'lnkup-marketplace' ),
		'has_spots'          => __( 'Has spots', 'lnkup-marketplace' ),
		'verified_organizer' => __( 'Verified organizer', 'lnkup-marketplace' ),
		'closing_soon'       => __( 'Closing soon', 'lnkup-marketplace' ),
		'newly_added'        => __( 'Newly added', 'lnkup-marketplace' ),
		'show_closed'        => __( 'Show closed', 'lnkup-marketplace' ),
	);
	foreach ( $bool_labels as $key => $label ) {
		if ( ! empty( $args[ $key ] ) ) {
			$labels[] = array( 'key' => $key, 'label' => $label );
		}
	}
	return $labels;
}

/**
 * Render pagination links for marketplace results.
 *
 * @param array $result Search result.
 * @param array $args   Current filters.
 */
function lnkup_render_marketplace_pagination( $result, $args = array() ) {
	$page  = max( 1, (int) ( $result['page'] ?? 1 ) );
	$pages = max( 1, (int) ( $result['pages'] ?? 1 ) );
	if ( $pages <= 1 ) {
		return '';
	}
	$base_args = array_filter( $args );
	unset( $base_args['page'] );
	$base_url = add_query_arg( $base_args, lnkup_page_url_helper( 'opportunities' ) );
	$html     = '<nav class="lnkup-mp-v2__pagination" aria-label="' . esc_attr__( 'Opportunities pagination', 'lnkup-marketplace' ) . '">';
	if ( $page > 1 ) {
		$html .= '<a class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" href="' . esc_url( add_query_arg( 'page', $page - 1, $base_url ) ) . '">' . esc_html__( 'Previous', 'lnkup-marketplace' ) . '</a>';
	}
	$html .= '<span class="lnkup-muted">' . esc_html( sprintf( __( 'Page %1$d of %2$d', 'lnkup-marketplace' ), $page, $pages ) ) . '</span>';
	if ( $page < $pages ) {
		$html .= '<a class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" href="' . esc_url( add_query_arg( 'page', $page + 1, $base_url ) ) . '">' . esc_html__( 'Next', 'lnkup-marketplace' ) . '</a>';
	}
	$html .= '</nav>';
	return $html;
}

/**
 * Default application deadline from event date.
 *
 * @param int $event_id Event post ID.
 */
function lnkup_default_application_deadline( $event_id ) {
	$event_date = get_post_meta( $event_id, '_lnkup_event_date', true );
	if ( $event_date && strtotime( $event_date ) ) {
		return gmdate( 'Y-m-d', strtotime( $event_date . ' -21 days' ) );
	}
	return gmdate( 'Y-m-d', strtotime( '+90 days' ) );
}

/**
 * Render apply-to-opportunity form HTML for modal or REST.
 *
 * @param int $opportunity_id Opportunity ID.
 */
function lnkup_render_apply_form_html( $opportunity_id ) {
	$opportunity_id = absint( $opportunity_id );
	$opp            = get_post( $opportunity_id );
	if ( ! $opp || 'lnkup_opportunity' !== $opp->post_type ) {
		return '';
	}

	$event_id   = (int) get_post_meta( $opportunity_id, '_lnkup_event_id', true );
	$event_name = $event_id ? get_the_title( $event_id ) : $opp->post_title;
	$card       = lnkup_get_opportunity_card_data( $opportunity_id );

	ob_start();
	?>
	<div class="lnkup-apply-modal__summary">
		<h2 class="lnkup-apply-modal__title" id="lnkup-apply-modal-title"><?php echo esc_html( $event_name ); ?></h2>
		<?php if ( ! empty( $card['location_label'] ) ) : ?>
			<p class="lnkup-muted"><?php echo esc_html( $card['location_label'] ); ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $card['event_date'] ) ) : ?>
			<p class="lnkup-muted"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $card['event_date'] ) ) ); ?></p>
		<?php endif; ?>
		<?php if ( isset( $card['vendor_fee'] ) ) : ?>
			<p><strong><?php echo esc_html( $card['fee_label'] ?? lnkup_currency( $card['vendor_fee'] ) ); ?></strong></p>
		<?php endif; ?>
	</div>
	<?php if ( is_user_logged_in() && LNKup_Roles::is_vendor() ) : ?>
		<form class="lnkup-form lnkup-apply-form" data-opportunity-id="<?php echo esc_attr( (string) $opportunity_id ); ?>">
			<?php wp_nonce_field( 'lnkup_apply', 'lnkup_nonce' ); ?>
			<input type="hidden" name="action" value="lnkup_apply" />
			<input type="hidden" name="opportunity_id" value="<?php echo esc_attr( (string) $opportunity_id ); ?>" />
			<div class="lnkup-form-row">
				<label for="lnkup-apply-message"><?php esc_html_e( 'Message to organizer', 'lnkup-marketplace' ); ?></label>
				<textarea id="lnkup-apply-message" name="message" rows="4"></textarea>
			</div>
			<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Submit Application (Free)', 'lnkup-marketplace' ); ?></button>
		</form>
	<?php else : ?>
		<p>
			<?php esc_html_e( 'Please log in as a vendor to apply.', 'lnkup-marketplace' ); ?>
			<a href="<?php echo esc_url( wp_login_url( lnkup_page_url_helper( 'opportunities' ) ) ); ?>"><?php esc_html_e( 'Log in', 'lnkup-marketplace' ); ?></a>
		</p>
	<?php endif; ?>
	<?php
	return ob_get_clean();
}

/**
 * Filtered opportunities query wrapper.
 *
 * @param array $args Filter args.
 */
function lnkup_get_filtered_opportunities( $args = array() ) {
	$result = LNKup_Discovery::search( $args );
	$result['html']           = lnkup_render_opportunity_cards_batch( $result['items'] );
	$result['active_filters'] = lnkup_build_active_filters( $args );
	$result['empty_state']    = 0 === (int) $result['total'];
	$result['pagination']     = lnkup_render_marketplace_pagination( $result, $args );
	return $result;
}

/**
 * Normalized opportunity card DTO with fallbacks.
 *
 * @param int        $opportunity_id Opportunity ID.
 * @param array|null $row            Optional index row.
 */
function lnkup_get_opportunity_card_data( $opportunity_id, $row = null ) {
	$opportunity_id = absint( $opportunity_id );
	if ( ! $row ) {
		$row = LNKup_Marketplace_Index::get_row( $opportunity_id );
		if ( ! $row ) {
			LNKup_Marketplace_Index::sync_opportunity( $opportunity_id );
			$row = LNKup_Marketplace_Index::get_row( $opportunity_id );
		}
	}
	if ( ! $row ) {
		return array();
	}

	$item = lnkup_format_index_row( $row, true );
	$opp_post = get_post( $opportunity_id );
	$item['opportunity_title'] = $opp_post ? $opp_post->post_title : '';
	$item['event_name']        = $row['title'] ?? $item['name'];
	$item['event_type']        = ! empty( $item['event_types'][0] ) ? $item['event_types'][0] : __( 'Event Opportunity', 'lnkup-marketplace' );
	$item['event_type_label']  = $item['event_type'];

	if ( empty( $item['city'] ) && empty( $item['state'] ) ) {
		$item['location_label'] = __( 'Location TBA', 'lnkup-marketplace' );
	} else {
		$item['location_label'] = trim( ( $item['city'] ?? '' ) . ( $item['state'] ? ', ' . $item['state'] : '' ) );
	}

	$item['attendance_label'] = ! empty( $item['attendance'] )
		? number_format_i18n( (int) $item['attendance'] )
		: __( 'Attendance TBA', 'lnkup-marketplace' );

	$item['fee_label'] = isset( $item['vendor_fee'] ) && $item['vendor_fee'] > 0
		? lnkup_currency( $item['vendor_fee'] )
		: __( 'Fee TBA', 'lnkup-marketplace' );

	$item['deadline_label'] = ! empty( $item['deadline'] )
		? date_i18n( 'M j, Y', strtotime( $item['deadline'] ) )
		: __( 'Rolling applications', 'lnkup-marketplace' );

	$item['venue_label'] = ! empty( $item['venue_name'] ) ? $item['venue_name'] : '';

	$env = array();
	if ( ! empty( $item['indoor'] ) ) {
		$env[] = __( 'Indoor', 'lnkup-marketplace' );
	}
	if ( ! empty( $item['outdoor'] ) ) {
		$env[] = __( 'Outdoor', 'lnkup-marketplace' );
	}
	if ( ! empty( $item['tent_allowed'] ) ) {
		$env[] = __( 'Tented', 'lnkup-marketplace' );
	}
	$item['environment_labels'] = $env;

	$doc_map = array(
		'certificate_of_insurance' => __( 'COI', 'lnkup-marketplace' ),
		'health_permit'            => __( 'Health Permit', 'lnkup-marketplace' ),
		'business_license'         => __( 'Business License', 'lnkup-marketplace' ),
		'w9'                       => __( 'W9', 'lnkup-marketplace' ),
	);
	$item['document_badges'] = array();
	if ( ! empty( $item['required_documents'] ) ) {
		foreach ( explode( ',', $item['required_documents'] ) as $slug ) {
			$slug = trim( $slug );
			if ( $slug ) {
				$item['document_badges'][] = $doc_map[ $slug ] ?? ucwords( str_replace( '_', ' ', $slug ) );
			}
		}
	}

	$deadline_passed = ! empty( $item['deadline'] ) && strtotime( $item['deadline'] ) < strtotime( 'today' );
	$no_spots        = (int) ( $item['spots_remaining'] ?? 0 ) <= 0;
	$item['is_open'] = ! $deadline_passed && ! $no_spots;

	$item['apply_url']    = add_query_arg( array( 'apply' => $opportunity_id ), lnkup_page_url_helper( 'opportunities' ) );
	$item['details_url']  = $item['apply_url'];
	$item['application_status'] = '';
	$user_id = get_current_user_id();
	if ( $user_id && LNKup_Roles::is_vendor( $user_id ) ) {
		$apps = get_posts(
			array(
				'post_type'      => 'lnkup_application',
				'posts_per_page' => 1,
				'meta_query'     => array(
					array( 'key' => '_lnkup_vendor_user_id', 'value' => $user_id ),
					array( 'key' => '_lnkup_event_id', 'value' => (int) $item['event_id'] ),
				),
			)
		);
		if ( $apps ) {
			$item['application_status'] = get_post_meta( $apps[0]->ID, '_lnkup_application_status', true );
		}
	}

	return $item;
}

/**
 * Format index table row for API/cards.
 *
 * @param array $row     Index row.
 * @param bool  $compare Include comparison fields.
 */
function lnkup_format_index_row( $row, $compare = false ) {
	$categories  = json_decode( $row['categories'] ?? '[]', true ) ?: array();
	$event_types = json_decode( $row['event_types'] ?? '[]', true ) ?: array();
	$organizer   = ! empty( $row['organizer_user_id'] ) ? get_userdata( (int) $row['organizer_user_id'] ) : null;

	$item = array(
		'opportunity_id'    => (int) $row['opportunity_id'],
		'event_id'          => (int) $row['event_id'],
		'id'                => (int) $row['opportunity_id'],
		'name'              => $row['title'],
		'city'              => $row['city'],
		'state'             => $row['state'],
		'venue_name'        => $row['venue_name'],
		'date'              => $row['event_date'],
		'attendance'        => (int) $row['attendance'],
		'vendor_fee'        => (float) $row['vendor_fee'],
		'spots_remaining'   => (int) $row['spots_remaining'],
		'total_spots'       => (int) $row['spots_total'],
		'categories'        => $categories,
		'event_types'       => $event_types,
		'deadline'          => $row['deadline'],
		'lat'               => $row['lat'] ? (float) $row['lat'] : null,
		'lng'               => $row['lng'] ? (float) $row['lng'] : null,
		'featured_image_id' => (int) ( $row['featured_image_id'] ?? 0 ),
		'featured_image'    => ! empty( $row['featured_image_id'] ) ? wp_get_attachment_image_url( (int) $row['featured_image_id'], 'medium_large' ) : '',
		'organizer_id'      => (int) $row['organizer_user_id'],
		'organizer_name'    => $organizer ? $organizer->display_name : '',
		'organizer_verified'=> (bool) ( $row['organizer_verified'] ?? false ),
		'organizer_rating'  => $row['organizer_rating'] ? (float) $row['organizer_rating'] : null,
		'instant_approval'  => (bool) ( $row['instant_approval'] ?? false ),
		'application_count' => (int) ( $row['application_count'] ?? 0 ),
		'view_count'        => (int) ( $row['view_count'] ?? 0 ),
		'trending_score'    => (float) ( $row['trending_score'] ?? 0 ),
		'badges'            => lnkup_get_opportunity_badges( $row ),
	);

	if ( $compare ) {
		$item['power_available']     = (bool) ( $row['power_available'] ?? false );
		$item['water_available']     = (bool) ( $row['water_available'] ?? false );
		$item['food_truck_allowed']  = (bool) ( $row['food_truck_allowed'] ?? false );
		$item['tent_allowed']        = (bool) ( $row['tent_allowed'] ?? false );
		$item['generator_allowed']   = (bool) ( $row['generator_allowed'] ?? false );
		$item['indoor']              = (bool) ( $row['indoor'] ?? false );
		$item['outdoor']             = (bool) ( $row['outdoor'] ?? false );
		$item['free_parking']        = (bool) ( $row['free_parking'] ?? false );
		$item['load_in_time']        = $row['load_in_time'] ?? '';
		$item['required_documents']  = $row['required_documents'] ?? '';
	}

	return $item;
}

/**
 * Compute display badges for opportunity.
 *
 * @param array $row Index row or formatted item.
 */
function lnkup_get_opportunity_badges( $row ) {
	$badges = array();
	$created = isset( $row['created_at'] ) ? strtotime( $row['created_at'] ) : 0;
	if ( $created && $created > strtotime( '-7 days' ) ) {
		$badges[] = 'recently_added';
	}
	if ( ! empty( $row['deadline'] ) ) {
		$days = ( strtotime( $row['deadline'] ) - time() ) / DAY_IN_SECONDS;
		if ( $days >= 0 && $days <= 7 ) {
			$badges[] = 'closing_soon';
		}
	}
	$spots_r = (int) ( $row['spots_remaining'] ?? 0 );
	$spots_t = (int) ( $row['spots_total'] ?? 1 );
	if ( $spots_t > 0 && ( $spots_r / $spots_t ) <= 0.1 && $spots_r > 0 ) {
		$badges[] = 'almost_full';
	}
	if ( ! empty( $row['trending_score'] ) && (float) $row['trending_score'] > 30 ) {
		$badges[] = 'trending';
	}
	if ( ! empty( $row['organizer_verified'] ) ) {
		$badges[] = 'verified';
	}
	if ( ! empty( $row['application_count'] ) && (int) $row['application_count'] > 5 ) {
		$badges[] = 'popular';
	}
	return $badges;
}

/**
 * Render v2 opportunity card.
 *
 * @param array $opp Opportunity data.
 */
function lnkup_render_opportunity_card_v2( $opp ) {
	if ( empty( $opp['event_type_label'] ) && ! empty( $opp['opportunity_id'] ) ) {
		$opp = lnkup_get_opportunity_card_data( (int) $opp['opportunity_id'], null );
	}
	if ( ! $opp ) {
		return '';
	}

	$user_id   = get_current_user_id();
	$favorited = $user_id && LNKup_Vendor_Personalization::is_favorite( $user_id, 'opportunities', $opp['opportunity_id'] );
	$low_spots = ( $opp['spots_remaining'] ?? 0 ) <= 5 && ( $opp['spots_remaining'] ?? 0 ) > 0;
	$apply_url = $opp['apply_url'] ?? add_query_arg( array( 'apply' => $opp['opportunity_id'] ), lnkup_page_url_helper( 'opportunities' ) );
	$match_chip = '';
	if ( $user_id && class_exists( 'LNKup_Growth_Match' ) && LNKup_Capabilities::can_view_growth( $user_id ) ) {
		$match = LNKup_Growth_Match::for_opportunity( $user_id, $opp['opportunity_id'] );
		if ( ! empty( $match['match_score'] ) ) {
			$match_chip = '<span class="lnkup-growth-match-chip">' . esc_html( $match['match_score'] ) . '% ' . esc_html( $match['match_label'] ) . '</span>';
		}
	}
	$event_name = $opp['event_name'] ?? $opp['name'];
	$name       = $opp['name_html'] ?? $event_name;
	$subtitle   = '';
	if ( ! empty( $opp['opportunity_title'] ) && $opp['opportunity_title'] !== $event_name ) {
		$subtitle = $opp['opportunity_title'];
	}
	$location = $opp['location_label'] ?? trim( ( $opp['city'] ?? '' ) . ( ! empty( $opp['state'] ) ? ', ' . $opp['state'] : '' ) );
	$img       = $opp['featured_image'] ?? '';
	$badge_labels = array(
		'trending'       => __( 'Trending', 'lnkup-marketplace' ),
		'closing_soon'   => __( 'Closing Soon', 'lnkup-marketplace' ),
		'recently_added' => __( 'New', 'lnkup-marketplace' ),
		'verified'       => __( 'Verified', 'lnkup-marketplace' ),
		'popular'        => __( 'Popular', 'lnkup-marketplace' ),
		'almost_full'    => __( 'Almost Full', 'lnkup-marketplace' ),
	);
	$status = $opp['application_status'] ?? '';
	$status_labels = array(
		'submitted'        => __( 'Applied', 'lnkup-marketplace' ),
		'under_review'     => __( 'Under Review', 'lnkup-marketplace' ),
		'approved'         => __( 'Approved', 'lnkup-marketplace' ),
		'payment_required' => __( 'Payment Due', 'lnkup-marketplace' ),
		'paid'             => __( 'Paid', 'lnkup-marketplace' ),
		'completed'        => __( 'Completed', 'lnkup-marketplace' ),
		'waitlisted'       => __( 'Waitlisted', 'lnkup-marketplace' ),
	);
	$is_closed = empty( $opp['is_open'] );

	ob_start();
	?>
	<article class="lnkup-event-card lnkup-event-card--v2<?php echo $is_closed ? ' lnkup-event-card--closed' : ''; ?>" data-opportunity-id="<?php echo esc_attr( (string) $opp['opportunity_id'] ); ?>" data-lat="<?php echo esc_attr( (string) ( $opp['lat'] ?? '' ) ); ?>" data-lng="<?php echo esc_attr( (string) ( $opp['lng'] ?? '' ) ); ?>">
		<div class="lnkup-event-card__media">
			<?php if ( $img ) : ?>
				<img src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy" />
			<?php else : ?>
				<div class="lnkup-event-card__placeholder" aria-hidden="true"><span>LNKup</span></div>
			<?php endif; ?>
			<div class="lnkup-event-card__badges-top">
				<span class="lnkup-badge lnkup-badge--accent"><?php echo esc_html( $opp['event_type_label'] ?? __( 'Event Opportunity', 'lnkup-marketplace' ) ); ?></span>
				<span class="lnkup-badge"><?php echo esc_html( $opp['fee_label'] ?? lnkup_currency( $opp['vendor_fee'] ?? 0 ) ); ?></span>
				<?php if ( $low_spots ) : ?>
					<span class="lnkup-badge lnkup-badge--destructive"><?php echo esc_html( (string) $opp['spots_remaining'] ); ?> <?php esc_html_e( 'left', 'lnkup-marketplace' ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $opp['badges'] ) ) : ?>
				<div class="lnkup-event-card__badges-float">
					<?php foreach ( array_slice( $opp['badges'], 0, 2 ) as $b ) : ?>
						<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( $badge_labels[ $b ] ?? $b ); ?></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<button type="button" class="lnkup-event-card__favorite<?php echo $favorited ? ' is-active' : ''; ?>" data-favorite-type="opportunities" data-favorite-id="<?php echo esc_attr( (string) $opp['opportunity_id'] ); ?>" aria-label="<?php esc_attr_e( 'Favorite', 'lnkup-marketplace' ); ?>">♥</button>
		</div>
		<div class="lnkup-event-card__body">
			<?php if ( ! empty( $opp['organizer_name'] ) ) : ?>
				<div class="lnkup-event-card__organizer">
					<span class="lnkup-event-card__avatar"><?php echo esc_html( substr( $opp['organizer_name'], 0, 1 ) ); ?></span>
					<span><?php echo esc_html( $opp['organizer_name'] ); ?></span>
					<?php if ( ! empty( $opp['organizer_verified'] ) ) : ?>
						<span class="lnkup-badge lnkup-badge--verified"><?php esc_html_e( 'Verified', 'lnkup-marketplace' ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<h3><?php echo wp_kses_post( $name ); ?></h3>
			<?php if ( $subtitle ) : ?>
				<p class="lnkup-event-card__subtitle lnkup-muted"><?php echo esc_html( $subtitle ); ?></p>
			<?php endif; ?>
			<?php if ( $match_chip ) : ?>
				<div class="lnkup-event-card__match"><?php echo $match_chip; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<?php endif; ?>
			<div class="lnkup-event-card__meta lnkup-event-card__meta-grid">
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Location', 'lnkup-marketplace' ); ?></span>
					<span><?php echo esc_html( $location ?: __( 'TBA', 'lnkup-marketplace' ) ); ?></span>
				</div>
				<?php if ( ! empty( $opp['date'] ) ) : ?>
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Date', 'lnkup-marketplace' ); ?></span>
					<span><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $opp['date'] ) ) ); ?></span>
				</div>
				<?php endif; ?>
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Booth fee', 'lnkup-marketplace' ); ?></span>
					<span><?php echo esc_html( $opp['fee_label'] ?? lnkup_currency( $opp['vendor_fee'] ?? 0 ) ); ?></span>
				</div>
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Capacity', 'lnkup-marketplace' ); ?></span>
					<span><?php
					$filled = max( 0, (int) $opp['total_spots'] - (int) $opp['spots_remaining'] );
					printf(
						esc_html__( '%1$d / %2$d', 'lnkup-marketplace' ),
						$filled,
						(int) $opp['total_spots']
					);
					?></span>
				</div>
				<?php if ( ! empty( $opp['venue_label'] ) ) : ?>
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Venue', 'lnkup-marketplace' ); ?></span>
					<span><?php echo esc_html( $opp['venue_label'] ); ?></span>
				</div>
				<?php endif; ?>
				<div class="lnkup-event-card__meta-item">
					<span class="lnkup-event-card__meta-label"><?php esc_html_e( 'Deadline', 'lnkup-marketplace' ); ?></span>
					<span><?php echo esc_html( $opp['deadline_label'] ?? __( 'Rolling', 'lnkup-marketplace' ) ); ?></span>
				</div>
			</div>
			<?php if ( ! empty( $opp['categories'] ) ) : ?>
				<div class="lnkup-event-card__chips">
					<?php foreach ( array_slice( $opp['categories'], 0, 3 ) as $cat ) : ?>
						<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( $cat ); ?></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $opp['environment_labels'] ) || ! empty( $opp['document_badges'] ) ) : ?>
				<div class="lnkup-event-card__chips lnkup-event-card__chips--meta">
					<?php foreach ( (array) $opp['environment_labels'] as $env_label ) : ?>
						<span class="lnkup-badge lnkup-badge--outline"><?php echo esc_html( $env_label ); ?></span>
					<?php endforeach; ?>
					<?php foreach ( (array) $opp['document_badges'] as $doc_label ) : ?>
						<span class="lnkup-badge lnkup-badge--outline"><?php echo esc_html( $doc_label ); ?></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="lnkup-event-card__footer">
				<span class="lnkup-badge lnkup-badge--secondary"><?php
				$filled = max( 0, (int) $opp['total_spots'] - (int) $opp['spots_remaining'] );
				printf(
					/* translators: 1: filled spots, 2: total spots */
					esc_html__( '%1$d of %2$d spots filled', 'lnkup-marketplace' ),
					$filled,
					(int) $opp['total_spots']
				);
				?></span>
				<div class="lnkup-event-card__actions">
					<?php if ( lnkup_marketplace_phase_at_least( '1c' ) ) : ?>
					<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-compare-add" data-opportunity-id="<?php echo esc_attr( (string) $opp['opportunity_id'] ); ?>"><?php esc_html_e( 'Compare', 'lnkup-marketplace' ); ?></button>
					<?php endif; ?>
					<a href="<?php echo esc_url( $apply_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Details', 'lnkup-marketplace' ); ?></a>
					<?php if ( $status && isset( $status_labels[ $status ] ) ) : ?>
						<span class="lnkup-badge lnkup-badge--accent"><?php echo esc_html( $status_labels[ $status ] ); ?></span>
					<?php elseif ( $is_closed ) : ?>
						<span class="lnkup-badge"><?php esc_html_e( 'Closed', 'lnkup-marketplace' ); ?></span>
					<?php else : ?>
						<a href="<?php echo esc_url( $apply_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Apply', 'lnkup-marketplace' ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Render skeleton card placeholder.
 */
function lnkup_render_opportunity_card_skeleton() {
	return '<article class="lnkup-event-card lnkup-event-card--skeleton"><div class="lnkup-skeleton lnkup-skeleton--media"></div><div class="lnkup-skeleton lnkup-skeleton--title"></div><div class="lnkup-skeleton lnkup-skeleton--line"></div></article>';
}

/**
 * Batch render cards HTML.
 *
 * @param array $items Items.
 */
function lnkup_render_opportunity_cards_batch( $items ) {
	$html = '';
	foreach ( (array) $items as $item ) {
		$html .= lnkup_render_opportunity_card_v2( $item );
	}
	return $html;
}

/**
 * Legacy card wrapper — delegates to v2 when index data available.
 *
 * @param array $opp Opportunity data.
 */
function lnkup_render_event_card( $opp ) {
	if ( ! empty( $opp['opportunity_id'] ) || ! empty( $opp['id'] ) ) {
		$id = $opp['opportunity_id'] ?? $opp['id'];
		$row = LNKup_Marketplace_Index::get_row( (int) $id );
		if ( $row ) {
			return lnkup_render_opportunity_card_v2( lnkup_format_index_row( $row ) );
		}
	}
	return lnkup_render_opportunity_card_v2( $opp );
}

/**
 * Query discoverable vendor profiles for the organizer directory.
 *
 * @param array $args Query arguments.
 */
function lnkup_get_discoverable_vendors( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'page'        => 1,
			'per_page'    => 24,
			'q'           => '',
			'city'        => '',
			'state'       => '',
			'category'    => '',
			'verified'    => '',
			'post_status' => array( 'publish', 'private' ),
		)
	);

	$query_args = array(
		'post_type'              => 'lnkup_vendor_profile',
		'post_status'            => $args['post_status'],
		'posts_per_page'         => min( 48, max( 1, absint( $args['per_page'] ) ) ),
		'paged'                  => max( 1, absint( $args['page'] ) ),
		'orderby'                => 'date',
		'order'                  => 'DESC',
		'no_found_rows'          => false,
		'update_post_meta_cache' => true,
		'meta_query'             => array(
			array(
				'key'     => '_lnkup_owner_user_id',
				'compare' => 'EXISTS',
			),
		),
	);

	if ( '' !== $args['verified'] && $args['verified'] ) {
		$query_args['meta_query'][] = array(
			'key'   => '_lnkup_verification_status',
			'value' => 'approved',
		);
	}

	if ( ! empty( $args['city'] ) ) {
		$query_args['meta_query'][] = array(
			'key'     => '_lnkup_city',
			'value'   => sanitize_text_field( $args['city'] ),
			'compare' => 'LIKE',
		);
	}

	if ( ! empty( $args['state'] ) ) {
		$query_args['meta_query'][] = array(
			'key'   => '_lnkup_state',
			'value' => sanitize_text_field( $args['state'] ),
		);
	}

	if ( ! empty( $args['category'] ) ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => 'lnkup_vendor_category',
				'field'    => 'name',
				'terms'    => sanitize_text_field( $args['category'] ),
			),
		);
	}

	if ( ! empty( $args['q'] ) ) {
		$search = sanitize_text_field( $args['q'] );
		$query_args['s'] = $search;
		$query_args['meta_query'][] = array(
			'relation' => 'OR',
			array(
				'key'     => '_lnkup_business_name',
				'value'   => $search,
				'compare' => 'LIKE',
			),
			array(
				'key'     => '_lnkup_city',
				'value'   => $search,
				'compare' => 'LIKE',
			),
		);
	}

	if ( count( $query_args['meta_query'] ) > 1 ) {
		$query_args['meta_query']['relation'] = 'AND';
	}

	$query = new WP_Query( $query_args );

	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log(
			sprintf(
				'lnkup_get_discoverable_vendors: found %d (page %d)',
				(int) $query->found_posts,
				(int) $args['page']
			)
		);
	}

	return array(
		'posts' => $query->posts,
		'total' => (int) $query->found_posts,
		'pages' => (int) $query->max_num_pages,
		'page'  => max( 1, absint( $args['page'] ) ),
	);
}

/**
 * Normalize vendor card data with safe fallbacks.
 *
 * @param array $profile Vendor profile DTO.
 */
function lnkup_normalize_vendor_card( $profile ) {
	if ( ! is_array( $profile ) ) {
		return array();
	}
	$profile['business_name'] = $profile['business_name'] ?? __( 'Vendor', 'lnkup-marketplace' );
	$profile['category']      = is_array( $profile['category'] ?? null ) ? $profile['category'] : array();
	$profile['city']          = $profile['city'] ?? '';
	$profile['state']         = $profile['state'] ?? '';
	$profile['vendor_score']  = isset( $profile['vendor_score'] ) ? (int) $profile['vendor_score'] : 0;
	$profile['avg_rating']    = isset( $profile['avg_rating'] ) ? (float) $profile['avg_rating'] : 0;
	$profile['review_count']  = isset( $profile['review_count'] ) ? (int) $profile['review_count'] : 0;
	$profile['completed_events'] = isset( $profile['completed_events'] ) ? (int) $profile['completed_events'] : 0;
	$profile['logo']          = $profile['logo'] ?? '';
	$profile['documents']     = is_array( $profile['documents'] ?? null ) ? $profile['documents'] : array();
	$profile['badges']        = is_array( $profile['badges'] ?? null ) ? $profile['badges'] : array();
	$profile['verified']      = ! empty( $profile['verified'] );
	return $profile;
}

/**
 * Canonical parent => child event type map.
 */
function lnkup_get_event_type_tree_definition() {
	if ( class_exists( 'LNKup_Taxonomies' ) ) {
		return LNKup_Taxonomies::get_event_type_tree_definition();
	}
	return array();
}

/**
 * Top-level event type parents.
 */
function lnkup_get_event_type_parents() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'lnkup_event_type',
			'parent'     => 0,
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);
	return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Child event types for a parent term.
 *
 * @param int $parent_id Parent term ID.
 */
function lnkup_get_event_type_children( $parent_id ) {
	$terms = get_terms(
		array(
			'taxonomy'   => 'lnkup_event_type',
			'parent'     => absint( $parent_id ),
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);
	return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Nested event type tree for PHP templates and JS localization.
 */
function lnkup_get_event_type_tree() {
	$tree = array();
	foreach ( lnkup_get_event_type_parents() as $parent ) {
		$children = array();
		foreach ( lnkup_get_event_type_children( $parent->term_id ) as $child ) {
			$children[] = array(
				'id'   => (int) $child->term_id,
				'name' => $child->name,
				'slug' => $child->slug,
			);
		}
		$tree[] = array(
			'id'       => (int) $parent->term_id,
			'name'     => $parent->name,
			'slug'     => $parent->slug,
			'children' => $children,
		);
	}
	return $tree;
}

/**
 * Expand assigned event type terms to leaf + parent names for indexing/filtering.
 *
 * @param array $terms WP_Term objects.
 */
function lnkup_expand_event_type_names_for_index( $terms ) {
	$names = array();
	if ( ! is_array( $terms ) ) {
		return $names;
	}
	foreach ( $terms as $term ) {
		if ( ! $term instanceof WP_Term ) {
			continue;
		}
		$names[] = $term->name;
		if ( $term->parent ) {
			$parent = get_term( $term->parent, 'lnkup_event_type' );
			if ( $parent && ! is_wp_error( $parent ) ) {
				$names[] = $parent->name;
			}
		}
	}
	return array_values( array_unique( array_filter( $names ) ) );
}

/**
 * Organizer event intelligence summary for dashboard widgets.
 *
 * @param int|null $organizer_id Organizer user ID.
 */
function lnkup_get_event_intelligence_summary( $organizer_id = null ) {
	$organizer_id = $organizer_id ? absint( $organizer_id ) : get_current_user_id();
	if ( ! $organizer_id ) {
		return array(
			'kpis'      => array(),
			'insights'  => array(),
			'events'    => array(),
			'warnings'  => array(),
		);
	}

	if ( class_exists( 'LNKup_Organizer_Intelligence' ) ) {
		return LNKup_Organizer_Intelligence::event_intelligence_summary( $organizer_id );
	}

	return array(
		'kpis'     => array(),
		'insights' => array( __( 'More data needed.', 'lnkup-marketplace' ) ),
		'events'   => array(),
		'warnings' => array(),
	);
}

/**
 * Semantic status badge modifier map.
 *
 * @return array<string, string>
 */
function lnkup_status_badge_modifier( string $status ): string {
	$map = array(
		'paid'             => 'success',
		'completed'        => 'success',
		'approved'         => 'success',
		'ready'            => 'success',
		'verified'         => 'success',
		'submitted'        => 'warning',
		'under_review'     => 'warning',
		'payment_required' => 'warning',
		'pending'          => 'warning',
		'docs_pending'     => 'warning',
		'balance_due'      => 'warning',
		'rejected'         => 'danger',
		'cancelled'        => 'danger',
		'failed'           => 'danger',
		'overdue'          => 'danger',
		'missing_docs'     => 'danger',
		'invited'          => 'info',
		'recommended'      => 'info',
		'featured'         => 'info',
		'draft'            => 'muted',
		'open'             => 'muted',
		'archived'         => 'muted',
		'waitlisted'       => 'muted',
	);
	return $map[ $status ] ?? 'muted';
}

/**
 * Render a semantic status badge.
 *
 * @param string $status Workflow status slug.
 * @param string $label  Display label.
 */
function lnkup_status_badge( string $status, string $label = '' ): string {
	$modifier = lnkup_status_badge_modifier( $status );
	if ( ! $label ) {
		$label = $status;
	}
	return sprintf(
		'<span class="lnkup-badge lnkup-badge--%s">%s</span>',
		esc_attr( $modifier ),
		esc_html( $label )
	);
}

/**
 * Render standardized KPI card.
 *
 * @param array<string, mixed> $args Card arguments.
 */
function lnkup_kpi_card( array $args ): string {
	$label     = (string) ( $args['label'] ?? '' );
	$value     = (string) ( $args['value'] ?? '' );
	$trend     = (string) ( $args['trend'] ?? '' );
	$icon      = (string) ( $args['icon'] ?? 'apps' );
	$is_zero   = ! empty( $args['is_zero'] );
	$trend_dir = (string) ( $args['trend_dir'] ?? 'neutral' );
	$href      = (string) ( $args['href'] ?? '' );

	$icons = array(
		'apps'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
		'star'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
		'cash'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
		'docs'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/></svg>',
		'payment'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/></svg>',
		'calendar' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
		'inbox'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-6l-2 3H10l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
		'users'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
		'shield'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
		'folder'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/></svg>',
	);
	$trend_icons = array(
		'up'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/></svg>',
		'down'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m22 17-8.5-8.5-5 5L2 7"/><path d="M16 17h6v-6"/></svg>',
		'neutral' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/></svg>',
	);
	$trend_dir = in_array( $trend_dir, array( 'up', 'down', 'neutral' ), true ) ? $trend_dir : 'neutral';
	$icon_html = function_exists( 'lnkup_inline_icon' )
		? lnkup_inline_icon( $icons[ $icon ] ?? $icons['apps'], 18 )
		: ( $icons[ $icon ] ?? $icons['apps'] );
	$trend_icon = function_exists( 'lnkup_inline_icon' )
		? lnkup_inline_icon( $trend_icons[ $trend_dir ], 12 )
		: $trend_icons[ $trend_dir ];
	$value_class = 'lnkup-stat-card__value' . ( $is_zero ? ' lnkup-stat-card__value--muted' : '' );
	$card_class  = 'lnkup-stat-card' . ( $href ? ' lnkup-stat-card--link' : '' );
	ob_start();
	?>
	<<?php echo $href ? 'a' : 'div'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> class="<?php echo esc_attr( $card_class ); ?>"<?php echo $href ? ' href="' . esc_url( $href ) . '"' : ''; ?>>
		<div class="lnkup-stat-card__content">
			<p class="lnkup-stat-card__label"><?php echo esc_html( $label ); ?></p>
			<p class="<?php echo esc_attr( $value_class ); ?>"><?php echo esc_html( $value ); ?></p>
			<?php if ( $trend ) : ?>
				<p class="lnkup-stat-card__trend lnkup-stat-card__trend--<?php echo esc_attr( $trend_dir ); ?>">
					<span class="lnkup-stat-card__trend-icon" aria-hidden="true"><?php echo $trend_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<?php echo esc_html( $trend ); ?>
				</p>
			<?php endif; ?>
		</div>
		<span class="lnkup-stat-card__icon" aria-hidden="true"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
	</<?php echo $href ? 'a' : 'div'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php
	return ob_get_clean();
}

/**
 * Render panel hero header.
 *
 * @param string $title    Page title.
 * @param string $subtitle Subtitle.
 * @param string $actions  Optional HTML for action buttons.
 */
function lnkup_panel_hero( string $title, string $subtitle = '', string $actions = '' ): string {
	ob_start();
	?>
	<header class="lnkup-panel-hero lnkup-dash-header">
		<div class="lnkup-panel-hero__copy">
			<h1 class="lnkup-dash-header__title"><?php echo esc_html( $title ); ?></h1>
			<?php if ( $subtitle ) : ?>
				<p class="lnkup-dash-header__subtitle"><?php echo esc_html( $subtitle ); ?></p>
			<?php endif; ?>
		</div>
		<?php if ( $actions ) : ?>
			<div class="lnkup-panel-hero__actions"><?php echo $actions; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
		<?php endif; ?>
	</header>
	<?php
	return ob_get_clean();
}
