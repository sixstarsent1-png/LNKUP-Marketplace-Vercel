<?php
/**
 * Plugin Name: LNKup Marketplace
 * Plugin URI: https://lnkup.com
 * Description: Custom marketplace functionality for LNKup — vendor opportunities, applications, payments, and event management.
 * Version: 12.1.6
 * Author: LNKup
 * Author URI: https://lnkup.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: lnkup-marketplace
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

define( 'LNKUP_VERSION', '12.1.6' );
define( 'LNKUP_PLUGIN_FILE', __FILE__ );
define( 'LNKUP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LNKUP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'LNKUP_MIN_PHP', '7.4' );

function lnkup_php_version_notice() {
	?>
	<div class="notice notice-error">
		<p>
			<?php
			printf(
				esc_html__( 'LNKup Marketplace requires PHP %1$s or higher. You are running PHP %2$s.', 'lnkup-marketplace' ),
				esc_html( LNKUP_MIN_PHP ),
				esc_html( PHP_VERSION )
			);
			?>
		</p>
	</div>
	<?php
}

if ( version_compare( PHP_VERSION, LNKUP_MIN_PHP, '<' ) ) {
	add_action( 'admin_notices', 'lnkup_php_version_notice' );
	return;
}

function lnkup_require( $relative_path ) {
	$path = LNKUP_PLUGIN_DIR . $relative_path;
	if ( ! file_exists( $path ) ) {
		add_action(
			'admin_notices',
			function () use ( $relative_path ) {
				printf(
					'<div class="notice notice-error"><p>%s</p></div>',
					esc_html( sprintf( __( 'LNKup Marketplace is missing a required file: %s', 'lnkup-marketplace' ), $relative_path ) )
				);
			}
		);
		return false;
	}
	require_once $path;
	return true;
}

$lnkup_core_files = array(
	'includes/class-security.php',
	'includes/class-roles.php',
	'includes/class-post-types.php',
	'includes/class-taxonomies.php',
	'includes/class-meta.php',
	'includes/class-capabilities.php',
	'includes/class-activator.php',
	'includes/class-applications.php',
	'includes/class-payments.php',
	'includes/class-packets.php',
	'includes/class-stripe.php',
	'includes/class-documents.php',
	'includes/class-notifications.php',
	'includes/class-ajax.php',
	'includes/class-geocoder.php',
	'includes/class-trending.php',
	'includes/class-marketplace-index.php',
	'includes/class-discovery.php',
	'includes/class-vendor-personalization.php',
	'includes/class-recommendations.php',
	'includes/class-collections.php',
	'includes/class-marketplace-analytics.php',
	'includes/class-marketplace-cron.php',
	'includes/class-marketplace-rest.php',
	'includes/class-organizer-crm-tables.php',
	'includes/class-organizer-crm.php',
	'includes/class-vendor-readiness.php',
	'includes/class-vendor-timeline.php',
	'includes/class-vendor-crm-profile.php',
	'includes/class-vendor-directory.php',
	'includes/class-vendor-notes.php',
	'includes/class-vendor-tags.php',
	'includes/class-vendor-lists.php',
	'includes/class-vendor-flags.php',
	'includes/class-vendor-invites.php',
	'includes/class-event-roster.php',
	'includes/class-organizer-crm-rest.php',
	'includes/class-reputation-tables.php',
	'includes/class-reliability-metrics.php',
	'includes/class-reputation-score.php',
	'includes/class-vendor-reputation.php',
	'includes/class-vendor-reviews.php',
	'includes/class-vendor-badges.php',
	'includes/class-completed-events.php',
	'includes/class-reputation-render.php',
	'includes/class-reputation-rest.php',
	'includes/helpers.php',
	'includes/class-ui-copy.php',
	'includes/class-vendor-dashboard-data.php',
	'public/class-vendor-dashboard-views.php',
	'public/class-shortcodes.php',
	'admin/class-admin.php',
	'admin/class-organizer-crm-admin.php',
	'admin/class-reputation-admin.php',
	'includes/class-operations-tables.php',
	'includes/class-operations-log.php',
	'includes/class-event-lifecycle.php',
	'includes/class-event-operations.php',
	'includes/class-booths.php',
	'includes/class-parking.php',
	'includes/class-loadin-schedule.php',
	'includes/class-checkins.php',
	'includes/class-support-requests.php',
	'includes/class-incidents.php',
	'includes/class-broadcasts.php',
	'includes/class-event-staff.php',
	'includes/class-ops-analytics.php',
	'includes/class-operations-render.php',
	'includes/class-operations-rest.php',
	'admin/class-operations-admin.php',
	'includes/class-intelligence-tables.php',
	'includes/class-intelligence-snapshots.php',
	'includes/class-intelligence-cron.php',
	'includes/class-event-score.php',
	'includes/class-opportunity-score.php',
	'includes/class-funnel-analytics.php',
	'includes/class-market-trends.php',
	'includes/class-revenue-intelligence.php',
	'includes/class-vendor-reliability-intel.php',
	'includes/class-risk-engine.php',
	'includes/class-recommended-actions.php',
	'includes/class-predictive-placeholders.php',
	'includes/class-post-event-report.php',
	'includes/class-organizer-intelligence.php',
	'includes/class-vendor-intelligence.php',
	'includes/class-intelligence-render.php',
	'includes/class-intelligence-rest.php',
	'admin/class-intelligence-admin.php',
	'includes/class-map-tables.php',
	'includes/class-map-provider.php',
	'includes/class-map-provider-leaflet.php',
	'includes/class-map-provider-static.php',
	'includes/class-maps.php',
	'includes/class-map-elements.php',
	'includes/class-parking-zones.php',
	'includes/class-map-routes.php',
	'includes/class-map-templates.php',
	'includes/class-map-sharing.php',
	'includes/class-map-insights.php',
	'includes/class-map-render.php',
	'includes/class-map-rest.php',
	'admin/class-map-admin.php',
	'includes/class-financial-tables.php',
	'includes/class-financial-audit.php',
	'includes/financial/interface-payment-provider.php',
	'includes/class-payment-provider.php',
	'includes/financial/bootstrap.php',
	'includes/class-stripe-provider.php',
	'includes/class-manual-provider.php',
	'includes/class-transactions.php',
	'includes/class-invoices.php',
	'includes/class-receipts.php',
	'includes/class-wallet.php',
	'includes/class-credits.php',
	'includes/class-refunds.php',
	'includes/class-payouts.php',
	'includes/class-financial-disputes.php',
	'includes/class-installments.php',
	'includes/class-deposits.php',
	'includes/class-promo-codes.php',
	'includes/class-financial-reports.php',
	'includes/class-fraud-flags.php',
	'includes/class-payment-methods.php',
	'includes/class-tax-profiles.php',
	'includes/class-financial.php',
	'includes/class-financial-render.php',
	'includes/class-financial-rest.php',
	'includes/class-financial-cron.php',
	'admin/class-financial-admin.php',
	'admin/class-financial-connect-admin.php',
	'includes/class-growth-tables.php',
	'includes/class-growth-kpis.php',
	'includes/class-growth-snapshots.php',
	'includes/class-growth-analytics.php',
	'includes/class-growth-match.php',
	'includes/class-growth-profile-strength.php',
	'includes/class-growth-goals.php',
	'includes/class-growth-recommendations.php',
	'includes/class-growth-benchmarks.php',
	'includes/class-growth-roi.php',
	'includes/class-growth-relationships.php',
	'includes/class-growth-journey.php',
	'includes/class-growth.php',
	'includes/class-growth-render.php',
	'includes/class-growth-rest.php',
	'includes/class-growth-cron.php',
	'admin/class-growth-admin.php',
);

foreach ( $lnkup_core_files as $file ) {
	if ( ! lnkup_require( $file ) ) {
		return;
	}
}

register_activation_hook( __FILE__, array( 'LNKup_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'LNKup_Activator', 'deactivate' ) );

function lnkup_marketplace_init() {
	LNKup_Roles::init();
	LNKup_Post_Types::init();
	LNKup_Taxonomies::init();
	LNKup_Meta::init();
	LNKup_Capabilities::init();
	LNKup_Marketplace_Index::init();
	LNKup_Marketplace_Analytics::init();
	LNKup_Marketplace_Cron::init();
	LNKup_Marketplace_REST::init();
	LNKup_Organizer_CRM::init();
	LNKup_Organizer_CRM_REST::init();
	LNKup_Organizer_CRM_Admin::init();
	LNKup_Vendor_Reputation::init();
	LNKup_Reputation_REST::init();
	LNKup_Reputation_Admin::init();
	LNKup_Event_Lifecycle::init();
	LNKup_Operations_REST::init();
	LNKup_Operations_Admin::init();
	LNKup_Intelligence_Cron::init();
	LNKup_Intelligence_REST::init();
	LNKup_Intelligence_Admin::init();
	LNKup_Map_REST::init();
	LNKup_Map_Admin::init();
	LNKup_Financial_REST::init();
	LNKup_Financial_Cron::init();
	LNKup_Financial_Admin::init();
	LNKup_Financial_Connect_Admin::init();
	LNKup_Financial_Service::init();
	LNKup_Invoices::init();
	LNKup_Growth_REST::init();
	LNKup_Growth_Cron::init();
	LNKup_Growth_Admin::init();
	LNKup_Shortcodes::init();
	LNKup_Admin::init();
	LNKup_Ajax::init();
	LNKup_Documents::init();
	LNKup_Stripe::init();
	LNKup_Activator::maybe_repair_dashboard_pages();
	add_action( 'admin_notices', array( 'LNKup_Activator', 'maybe_dashboard_template_notice' ) );
}
add_action( 'plugins_loaded', 'lnkup_marketplace_init' );

/**
 * Run DB migrations for v2.
 */
function lnkup_maybe_upgrade_db() {
	if ( get_option( 'lnkup_db_version' ) === LNKUP_VERSION ) {
		return;
	}

	$creators = array(
		array( 'LNKup_Marketplace_Index', 'create_tables' ),
		array( 'LNKup_Marketplace_Analytics', 'create_tables' ),
		array( 'LNKup_Organizer_CRM_Tables', 'create_tables' ),
		array( 'LNKup_Reputation_Tables', 'create_tables' ),
		array( 'LNKup_Operations_Tables', 'create_tables' ),
		array( 'LNKup_Intelligence_Tables', 'create_tables' ),
		array( 'LNKup_Map_Tables', 'create_tables' ),
		array( 'LNKup_Financial_Tables', 'create_tables' ),
		array( 'LNKup_Growth_Tables', 'create_tables' ),
	);

	foreach ( $creators as $creator ) {
		try {
			call_user_func( $creator );
		} catch ( Throwable $table_error ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'LNKup table migration failed (' . $creator[0] . '): ' . $table_error->getMessage() );
		}
	}

	try {
		LNKup_Activator::create_pages();
	} catch ( Throwable $page_error ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'LNKup page migration failed: ' . $page_error->getMessage() );
	}

	LNKup_Marketplace_Cron::schedule();
	LNKup_Intelligence_Cron::schedule();
	LNKup_Financial_Cron::schedule();
	LNKup_Growth_Cron::schedule();

	if ( get_option( 'lnkup_taxonomy_seed_version' ) !== LNKUP_VERSION ) {
		try {
			LNKup_Taxonomies::seed_terms();
			update_option( 'lnkup_taxonomy_seed_version', LNKUP_VERSION );
		} catch ( Throwable $taxonomy_error ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'LNKup taxonomy seed failed: ' . $taxonomy_error->getMessage() );
		}
	}

	if ( class_exists( 'LNKup_Taxonomies' ) ) {
		try {
			LNKup_Taxonomies::maybe_upgrade_event_type_hierarchy();
		} catch ( Throwable $event_type_error ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'LNKup event type hierarchy upgrade failed: ' . $event_type_error->getMessage() );
		}
	}

	try {
		LNKup_Roles::sync_role_capabilities();
	} catch ( Throwable $role_error ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'LNKup role capability sync failed: ' . $role_error->getMessage() );
	}

	update_option( 'lnkup_db_version', LNKUP_VERSION );
	update_option( 'lnkup_needs_deferred_upgrade', LNKUP_VERSION );
}
add_action( 'init', 'lnkup_maybe_upgrade_db', 4 );

/**
 * Heavy migrations (index rebuild, backfills) run once in wp-admin.
 */
function lnkup_maybe_deferred_upgrade() {
	LNKup_Activator::maybe_run_deferred_upgrade();
	if ( class_exists( 'LNKup_Payments' ) ) {
		LNKup_Payments::backfill_pending_payment_fees();
	}
}
add_action( 'admin_init', 'lnkup_maybe_deferred_upgrade', 5 );

/**
 * One-time cleanup for invalid DATE values in marketplace index.
 */
function lnkup_maybe_cleanup_marketplace_index_dates() {
	if ( get_option( 'lnkup_index_deadline_null_v1' ) ) {
		return;
	}
	if ( ! class_exists( 'LNKup_Marketplace_Index' ) ) {
		return;
	}
	try {
		LNKup_Marketplace_Index::cleanup_invalid_dates();
		update_option( 'lnkup_index_deadline_null_v1', 1 );
	} catch ( Throwable $cleanup_error ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'LNKup index date cleanup failed: ' . $cleanup_error->getMessage() );
	}
}
add_action( 'init', 'lnkup_maybe_cleanup_marketplace_index_dates', 5 );

function lnkup_get_settings() {
	$defaults = array(
		'default_fee'           => 5.99,
		'stripe_public_key'     => '',
		'stripe_secret_key'     => '',
		'test_mode'             => true,
		'default_packet_lock'   => true,
		'default_documents'     => array( 'certificate_of_insurance', 'business_license' ),
		'notify_vendor'         => true,
		'notify_organizer'      => true,
		'notify_admin'          => true,
		'support_email'         => get_option( 'admin_email' ),
		'marketplace_phase'     => '1a',
		'map_provider'          => 'leaflet',
		'mapbox_token'          => '',
		'google_maps_key'       => '',
		'payment_provider'      => 'stripe',
		'stripe_webhook_secret' => '',
		'stripe_connect_enabled'       => false,
		'connect_platform_country'     => 'US',
		'connect_platform_currency'    => 'usd',
		'application_fee_type'         => 'flat',
		'application_fee_percent'      => 0,
		'application_fee_flat'         => 5.99,
		'vendor_checkout_fee'          => 5.99,
		'organizer_commission_percent' => 6,
		'connect_express_enabled'      => true,
		'connect_instant_payouts_enabled' => false,
		'connect_manual_fallback'      => true,
		'connect_payout_schedule'      => 'daily',
		'connect_return_url'           => '',
		'connect_refresh_url'          => '',
		'fee_payer_mode'               => 'vendor',
		'stripe_billing_enabled'       => false,
		'escrow_enabled'        => true,
		'escrow_hold_percent'   => 100,
		'escrow_release_days'   => 7,
		'reserve_percent'       => 5,
		'reserve_hold_days'     => 30,
		'ach_enabled'           => false,
	);
	return wp_parse_args( get_option( 'lnkup_settings', array() ), $defaults );
}

/**
 * Current marketplace rollout phase: 1a, 1b, or 1c.
 */
function lnkup_get_marketplace_phase() {
	$settings = lnkup_get_settings();
	$phase    = isset( $settings['marketplace_phase'] ) ? strtolower( (string) $settings['marketplace_phase'] ) : '1a';
	if ( ! in_array( $phase, array( '1a', '1b', '1c' ), true ) ) {
		return '1a';
	}
	return $phase;
}

/**
 * Whether marketplace phase is at least the given level.
 *
 * @param string $min Minimum phase (1a|1b|1c).
 */
function lnkup_marketplace_phase_at_least( $min ) {
	$order  = array( '1a' => 1, '1b' => 2, '1c' => 3 );
	$current = lnkup_get_marketplace_phase();
	$min     = strtolower( (string) $min );
	return ( $order[ $current ] ?? 1 ) >= ( $order[ $min ] ?? 1 );
}
