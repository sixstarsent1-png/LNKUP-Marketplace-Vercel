<?php
/**
 * Frontend shortcodes.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Shortcodes {

	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$map = array(
			'lnkup_vendor_dashboard'     => 'render_vendor_dashboard',
			'lnkup_organizer_dashboard'    => 'render_organizer_dashboard',
			'lnkup_opportunities_feed'   => 'render_opportunities_feed',
			'lnkup_vendor_profile_form'  => 'render_vendor_profile_form',
			'lnkup_organizer_events'     => 'render_organizer_events',
			'lnkup_applications_manager' => 'render_applications_manager',
			'lnkup_documents_manager'    => 'render_documents_manager',
			'lnkup_payments_dashboard'   => 'render_payments_dashboard',
			'lnkup_favorites'            => 'render_favorites',
			'lnkup_vendor_public_profile'=> 'render_vendor_public_profile',
		);
		add_action( 'template_redirect', array( __CLASS__, 'handle_invoice_verify' ) );
		foreach ( $map as $code => $method ) {
			add_shortcode( $code, array( __CLASS__, $method ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_filter( 'redirect_canonical', array( __CLASS__, 'preserve_dashboard_view_param' ), 10, 2 );
	}

	/**
	 * Whether the current front-end page is a dashboard shell page.
	 */
	private static function is_dashboard_front_page() {
		if ( ! is_page() ) {
			return false;
		}
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		return in_array(
			$slug,
			array( 'vendor-dashboard', 'organizer-dashboard', 'opportunities', 'vendor-profile' ),
			true
		);
	}

	/**
	 * Prevent canonical redirects from stripping ?view= on vendor dashboard.
	 *
	 * @param string $redirect_url  Redirect URL.
	 * @param string $requested_url Requested URL.
	 */
	public static function preserve_dashboard_view_param( $redirect_url, $requested_url ) {
		unset( $requested_url );
		if ( is_page( 'vendor-dashboard' ) && isset( $_GET['view'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		return $redirect_url;
	}

	/**
	 * Public invoice verification via QR token.
	 */
	public static function handle_invoice_verify() {
		if ( empty( $_GET['lnkup_verify_invoice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$token   = sanitize_text_field( wp_unslash( $_GET['lnkup_verify_invoice'] ) );
		$invoice = LNKup_Invoices::verify_by_token( $token );
		if ( ! $invoice ) {
			wp_die( esc_html__( 'Invalid or expired invoice verification link.', 'lnkup-marketplace' ), 404 );
		}
		wp_die( LNKup_Invoices::render_html( $invoice ), esc_html( $invoice['invoice_number'] ), array( 'response' => 200 ) );
	}

	/**
	 * Enqueue plugin frontend assets.
	 */
	public static function enqueue_assets() {
		$is_dashboard = self::is_dashboard_front_page()
			|| ( function_exists( 'lnkup_theme_is_dashboard_page' ) && lnkup_theme_is_dashboard_page() );

		$component_deps = array();
		if ( wp_style_is( 'lnkup-components', 'registered' ) || wp_style_is( 'lnkup-components', 'enqueued' ) ) {
			$component_deps[] = 'lnkup-components';
		}

		wp_enqueue_script(
			'lnkup-ui',
			LNKUP_PLUGIN_URL . 'public/js/lnkup-ui.js',
			array(),
			LNKUP_VERSION,
			true
		);
		if ( class_exists( 'LNKup_UI_Copy' ) ) {
			wp_localize_script( 'lnkup-ui', 'lnkupUiCopy', LNKup_UI_Copy::for_js() );
		}

		if ( $is_dashboard ) {
			wp_enqueue_style(
				'lnkup-vendor-dashboard',
				LNKUP_PLUGIN_URL . 'public/css/vendor-dashboard.css',
				$component_deps,
				LNKUP_VERSION
			);
		}
		wp_enqueue_style(
			'lnkup-marketplace-v2',
			LNKUP_PLUGIN_URL . 'public/css/marketplace-v2.css',
			$component_deps,
			LNKUP_VERSION
		);
		wp_enqueue_script(
			'lnkup-marketplace',
			LNKUP_PLUGIN_URL . 'public/js/marketplace.js',
			array(),
			LNKUP_VERSION,
			true
		);
		wp_enqueue_script(
			'lnkup-marketplace-v2',
			LNKUP_PLUGIN_URL . 'public/js/marketplace-v2.js',
			array( 'lnkup-marketplace' ),
			LNKUP_VERSION,
			true
		);
		if ( lnkup_marketplace_phase_at_least( '1b' ) ) {
			wp_enqueue_script(
				'lnkup-marketplace-map',
				LNKUP_PLUGIN_URL . 'public/js/marketplace-map.js',
				array( 'lnkup-marketplace-v2' ),
				LNKUP_VERSION,
				true
			);
		}
		if ( lnkup_marketplace_phase_at_least( '1c' ) ) {
			wp_enqueue_script(
				'lnkup-marketplace-compare',
				LNKUP_PLUGIN_URL . 'public/js/marketplace-compare.js',
				array( 'lnkup-marketplace-v2' ),
				LNKUP_VERSION,
				true
			);
		}
		wp_localize_script(
			'lnkup-marketplace',
			'lnkupAjax',
			array(
				'url'              => admin_url( 'admin-ajax.php' ),
				'nonce'            => wp_create_nonce( 'lnkup_action' ),
				'reviewNonce'      => wp_create_nonce( 'lnkup_review' ),
				'restUrl'          => esc_url_raw( rest_url( 'lnkup/v1/marketplace' ) ),
				'crmRestUrl'       => esc_url_raw( rest_url( 'lnkup/v1/crm' ) ),
				'reputationRestUrl'=> esc_url_raw( rest_url( 'lnkup/v1/reputation' ) ),
				'operationsRestUrl'=> esc_url_raw( rest_url( 'lnkup/v1/operations' ) ),
				'intelligenceRestUrl'=> esc_url_raw( rest_url( 'lnkup/v1/intelligence' ) ),
				'financialRestUrl'   => esc_url_raw( rest_url( 'lnkup/v1/financial' ) ),
				'growthRestUrl'      => esc_url_raw( rest_url( 'lnkup/v1/growth' ) ),
				'mapsRestUrl'      => esc_url_raw( rest_url( 'lnkup/v1/maps' ) ),
				'mapProvider'      => LNKup_Map_Provider::frontend_config(),
				'vendorsUrl'       => lnkup_page_url_helper( 'vendors' ),
				'restNonce'        => wp_create_nonce( 'wp_rest' ),
				'isLoggedIn'       => is_user_logged_in(),
				'marketplacePhase' => lnkup_get_marketplace_phase(),
				'opportunitiesUrl' => lnkup_page_url_helper( 'opportunities' ),
				'organizerDashboardUrl' => lnkup_page_url_helper( 'organizer-dashboard' ),
				'stripePublicKey'    => lnkup_get_settings()['stripe_public_key'] ?? '',
				'eventTypeTree'      => lnkup_get_event_type_tree(),
			)
		);
		wp_enqueue_style(
			'lnkup-reputation',
			LNKUP_PLUGIN_URL . 'public/css/reputation.css',
			array( 'lnkup-marketplace-v2' ),
			LNKUP_VERSION
		);
		wp_enqueue_script(
			'lnkup-reputation',
			LNKUP_PLUGIN_URL . 'public/js/reputation.js',
			array( 'lnkup-marketplace', 'lnkup-ui' ),
			LNKUP_VERSION,
			true
		);
		wp_enqueue_style(
			'lnkup-operations',
			LNKUP_PLUGIN_URL . 'public/css/operations.css',
			array( 'lnkup-marketplace-v2' ),
			LNKUP_VERSION
		);
		wp_enqueue_script(
			'lnkup-operations',
			LNKUP_PLUGIN_URL . 'public/js/operations.js',
			array( 'lnkup-marketplace', 'lnkup-ui' ),
			LNKUP_VERSION,
			true
		);
		wp_enqueue_script(
			'lnkup-vendor-ops',
			LNKUP_PLUGIN_URL . 'public/js/vendor-ops.js',
			array( 'lnkup-operations' ),
			LNKUP_VERSION,
			true
		);
		wp_enqueue_style(
			'lnkup-intelligence',
			LNKUP_PLUGIN_URL . 'public/css/intelligence.css',
			array( 'lnkup-marketplace-v2' ),
			LNKUP_VERSION
		);
		wp_enqueue_script(
			'lnkup-intelligence',
			LNKUP_PLUGIN_URL . 'public/js/intelligence.js',
			array( 'lnkup-marketplace', 'lnkup-ui' ),
			LNKUP_VERSION,
			true
		);
		wp_enqueue_style(
			'lnkup-maps',
			LNKUP_PLUGIN_URL . 'public/css/maps.css',
			array( 'lnkup-marketplace-v2' ),
			LNKUP_VERSION
		);
		wp_enqueue_script(
			'lnkup-maps',
			LNKUP_PLUGIN_URL . 'public/js/maps.js',
			array( 'lnkup-marketplace', 'lnkup-operations' ),
			LNKUP_VERSION,
			true
		);
		$load_organizer_crm = is_user_logged_in() && (
			LNKup_Roles::is_organizer()
			|| LNKup_Capabilities::user_has_manage_all()
			|| ! empty( $_GET['invite'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			|| ( $is_dashboard && is_page( 'organizer-dashboard' ) )
		);
		if ( $load_organizer_crm ) {
			$crm_deps = array( 'lnkup-marketplace-v2' );
			if ( wp_style_is( 'lnkup-components', 'registered' ) || wp_style_is( 'lnkup-components', 'enqueued' ) ) {
				$crm_deps[] = 'lnkup-components';
			}
			wp_enqueue_style(
				'lnkup-organizer-crm',
				LNKUP_PLUGIN_URL . 'public/css/organizer-crm.css',
				$crm_deps,
				LNKUP_VERSION
			);
			wp_enqueue_script(
				'lnkup-organizer-crm',
				LNKUP_PLUGIN_URL . 'public/js/organizer-crm.js',
				array( 'lnkup-marketplace', 'lnkup-reputation', 'lnkup-ui' ),
				LNKUP_VERSION,
				true
			);
			wp_enqueue_script(
				'lnkup-organizer-command',
				LNKUP_PLUGIN_URL . 'public/js/organizer-command.js',
				array( 'lnkup-organizer-crm', 'lnkup-ui', 'lnkup-intelligence' ),
				LNKUP_VERSION,
				true
			);
			wp_enqueue_script(
				'lnkup-organizer-create',
				LNKUP_PLUGIN_URL . 'public/js/organizer-create.js',
				array( 'lnkup-organizer-command' ),
				LNKUP_VERSION,
				true
			);
			wp_localize_script(
				'lnkup-organizer-create',
				'lnkupEventTypeTree',
				array(
					'tree' => lnkup_get_event_type_tree(),
				)
			);
		}
		if ( is_user_logged_in() && ( LNKup_Roles::is_vendor() || LNKup_Roles::is_organizer() || LNKup_Capabilities::user_has_manage_all() ) ) {
			$settings = lnkup_get_settings();
			wp_enqueue_style(
				'lnkup-financial',
				LNKUP_PLUGIN_URL . 'public/css/financial.css',
				array( 'lnkup-marketplace-v2' ),
				LNKUP_VERSION
			);
			wp_enqueue_style(
				'lnkup-checkout',
				LNKUP_PLUGIN_URL . 'public/css/checkout.css',
				array( 'lnkup-financial' ),
				LNKUP_VERSION
			);
			wp_enqueue_script(
				'lnkup-financial',
				LNKUP_PLUGIN_URL . 'public/js/financial.js',
				array( 'lnkup-marketplace', 'lnkup-ui' ),
				LNKUP_VERSION,
				true
			);
			wp_enqueue_script(
				'lnkup-checkout',
				LNKUP_PLUGIN_URL . 'public/js/checkout.js',
				array( 'lnkup-financial' ),
				LNKUP_VERSION,
				true
			);
			wp_localize_script(
				'lnkup-checkout',
				'lnkupCheckoutConfig',
				array(
					'stripePublicKey' => $settings['stripe_public_key'] ?? '',
				)
			);
		}
		if ( is_user_logged_in() && LNKup_Capabilities::can_view_growth() ) {
			wp_enqueue_style(
				'lnkup-growth',
				LNKUP_PLUGIN_URL . 'public/css/growth.css',
				array( 'lnkup-marketplace-v2' ),
				LNKUP_VERSION
			);
			wp_enqueue_script(
				'lnkup-growth',
				LNKUP_PLUGIN_URL . 'public/js/growth.js',
				array( 'lnkup-marketplace', 'lnkup-ui' ),
				LNKUP_VERSION,
				true
			);
		}
	}

	/**
	 * Vendor dashboard shortcode.
	 */
	public static function render_vendor_dashboard() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_vendor() && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Vendor access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'home'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$map  = array(
			'home'         => 'render_home',
			'applications' => 'render_applications',
			'documents'    => 'render_documents',
			'payments'     => 'render_payments',
			'financial'    => 'render_payments',
			'growth'       => 'render_growth',
			'reviews'      => 'render_reviews',
			'operations'   => 'render_operations',
		);

		if ( ! isset( $map[ $view ] ) ) {
			$view = 'home';
		}

		$method = $map[ $view ];
		return LNKup_Vendor_Dashboard_Views::$method();
	}

	/**
	 * Organizer dashboard shortcode.
	 */
	public static function render_organizer_dashboard() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_organizer() && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Organizer access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$vendor_profile = isset( $_GET['vendor'] ) ? absint( $_GET['vendor'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $vendor_profile ) {
			return self::render_vendor_crm_profile( $vendor_profile );
		}

		$roster_event = isset( $_GET['event'] ) && ! empty( $_GET['roster'] ) ? absint( $_GET['event'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $roster_event ) {
			return self::render_event_roster_view( $roster_event );
		}

		$ops_event = isset( $_GET['event'] ) && ! empty( $_GET['ops'] ) ? absint( $_GET['event'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $ops_event ) {
			return self::render_event_operations_view( $ops_event );
		}

		$scan_event = isset( $_GET['event'] ) && ! empty( $_GET['scan'] ) ? absint( $_GET['event'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $scan_event ) {
			return self::render_qr_scan_view( $scan_event );
		}

		$user_id = get_current_user_id();
		$events  = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);
		$opps = get_posts(
			array(
				'post_type'      => 'lnkup_opportunity',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'     => '_lnkup_event_id',
						'value'   => wp_list_pluck( $events, 'ID' ),
						'compare' => 'IN',
					),
				),
			)
		);
		$apps     = lnkup_get_applications_for_user( $user_id, 'organizer' );
		$new_apps = array_filter(
			$apps,
			function ( $a ) {
				return 'submitted' === get_post_meta( $a->ID, '_lnkup_application_status', true );
			}
		);
		$payments = lnkup_get_payments_for_user( $user_id, 'organizer' );
		$collected = array_reduce(
			$payments,
			function ( $sum, $p ) {
				if ( 'paid' === get_post_meta( $p->ID, '_lnkup_payment_status', true ) ) {
					return $sum + (float) get_post_meta( $p->ID, '_lnkup_vendor_spot_fee', true );
				}
				return $sum;
			},
			0
		);
		$pending_apps = array_filter(
			$apps,
			function ( $a ) {
				$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
				return in_array( $s, array( 'submitted', 'under_review' ), true );
			}
		);
		$approved_vendors = array_filter(
			$apps,
			function ( $a ) {
				$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
				return in_array( $s, array( 'approved', 'payment_required', 'paid', 'completed' ), true );
			}
		);
		$missing_docs = array_filter(
			$apps,
			function ( $a ) {
				return 'ready' !== LNKup_Vendor_Readiness::refresh( $a->ID );
			}
		);
		$upcoming_loadins = array_filter(
			$events,
			function ( $e ) {
				$date = get_post_meta( $e->ID, '_lnkup_event_date', true );
				return $date && strtotime( $date ) >= strtotime( 'today' );
			}
		);
		$user        = wp_get_current_user();
		$display     = $user->display_name;
		$event_count = count( $events );
		$opp_count   = count( $opps );
		$new_count   = count( $new_apps );
		$dash_url    = lnkup_page_url_helper( 'organizer-dashboard' );
		$pending_payout   = class_exists( 'LNKup_Payouts' ) ? LNKup_Payouts::pending_balance( $user_id ) : 0;
		$available_payout = class_exists( 'LNKup_Payouts' ) ? LNKup_Payouts::available_balance( $user_id ) : 0;
		$payout_count     = class_exists( 'LNKup_Payouts' ) ? LNKup_Payouts::count_for_organizer( $user_id ) : 0;
		$next_loadin      = '';
		if ( $upcoming_loadins ) {
			$loadin_sorted = array_values( $upcoming_loadins );
			usort(
				$loadin_sorted,
				function ( $a, $b ) {
					$da = get_post_meta( $a->ID, '_lnkup_event_date', true );
					$db = get_post_meta( $b->ID, '_lnkup_event_date', true );
					return strtotime( $da ) <=> strtotime( $db );
				}
			);
			$first_date = get_post_meta( $loadin_sorted[0]->ID, '_lnkup_event_date', true );
			if ( $first_date ) {
				$next_loadin = date_i18n( 'M j', strtotime( $first_date ) );
			}
		}
		$primary_cta_href  = $dash_url . '#create';
		$primary_cta_label = function_exists( 'lnkup_copy' ) ? lnkup_copy( 'launch_event' ) : __( 'Launch event', 'lnkup-marketplace' );
		$vendors_booked    = 0;
		foreach ( $events as $ev ) {
			$spots = self::organizer_event_spots( $ev->ID );
			$vendors_booked += (int) $spots['filled'];
		}
		$unpaid_apps = array_filter(
			$apps,
			function ( $a ) {
				$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
				return in_array( $s, array( 'approved', 'payment_required' ), true );
			}
		);
		$loadin_7d = array_filter(
			$upcoming_loadins,
			function ( $e ) {
				$date = get_post_meta( $e->ID, '_lnkup_event_date', true );
				return $date && strtotime( $date ) <= strtotime( '+7 days' );
			}
		);
		$live_events_count          = count( $upcoming_loadins );
		$confirmed_vendors_count    = count( $approved_vendors );
		$readiness_issues_count     = count( $missing_docs );
		$readiness_percent_sum      = 0;
		$readiness_percent_count    = 0;
		$at_risk_readiness_count    = 0;
		foreach ( $approved_vendors as $a ) {
			$cl = LNKup_Vendor_Readiness::checklist( $a->ID );
			$readiness_percent_sum += $cl['percent'];
			$readiness_percent_count++;
			if ( ( $cl['tier'] ?? '' ) === LNKup_Vendor_Readiness::TIER_AT_RISK ) {
				$at_risk_readiness_count++;
			}
		}
		$readiness_kpi_value        = $readiness_percent_count > 0
			? ( (int) round( $readiness_percent_sum / $readiness_percent_count ) ) . '%'
			: '—';
		$readiness_kpi_trend        = $at_risk_readiness_count > 0
			? sprintf( _n( '%d at risk', '%d at risk', $at_risk_readiness_count, 'lnkup-marketplace' ), $at_risk_readiness_count )
			: __( 'On track', 'lnkup-marketplace' );
		$command_summary_line       = sprintf(
			/* translators: 1: live events 2: confirmed vendors 3: readiness issues */
			__( '%1$s · %2$s · %3$s', 'lnkup-marketplace' ),
			sprintf( _n( '%d live event', '%d live events', $live_events_count, 'lnkup-marketplace' ), $live_events_count ),
			sprintf( _n( '%d confirmed vendor', '%d confirmed vendors', $confirmed_vendors_count, 'lnkup-marketplace' ), $confirmed_vendors_count ),
			sprintf( _n( '%d event readiness issue', '%d event readiness issues', $readiness_issues_count, 'lnkup-marketplace' ), $readiness_issues_count )
		);
		$attention_items = array();
		if ( count( $pending_apps ) > 0 ) {
			$attention_items[] = array(
				'label' => function_exists( 'lnkup_copy' ) ? lnkup_copy( 'vendor_requests' ) : __( 'Pending vendor requests', 'lnkup-marketplace' ),
				'count' => count( $pending_apps ),
				'href'  => $dash_url . '#applications',
				'level' => 'warning',
			);
		}
		if ( count( $unpaid_apps ) > 0 ) {
			$attention_items[] = array(
				'label' => __( 'Awaiting vendor payment', 'lnkup-marketplace' ),
				'count' => count( $unpaid_apps ),
				'href'  => $dash_url . '#applications',
				'level' => 'warning',
			);
		}
		if ( count( $missing_docs ) > 0 ) {
			$attention_items[] = array(
				'label' => function_exists( 'lnkup_copy' ) ? lnkup_copy( 'vendors_not_event_ready' ) : __( 'Vendors not event-ready', 'lnkup-marketplace' ),
				'count' => count( $missing_docs ),
				'href'  => $dash_url . '#applications',
				'level' => 'info',
			);
		}
		if ( count( $loadin_7d ) > 0 ) {
			$attention_items[] = array(
				'label' => __( 'Load-ins this week', 'lnkup-marketplace' ),
				'count' => count( $loadin_7d ),
				'href'  => $dash_url . '#operations',
				'level' => 'info',
			);
		}

		$has_priority_module = (bool) array_filter(
			$missing_docs,
			function ( $a ) {
				$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
				return in_array( $s, array( 'approved', 'payment_required', 'paid' ), true );
			}
		);
		$priority_module_html = self::render_organizer_priority_module( $missing_docs, $dash_url );

		ob_start();
		?>
		<div class="lnkup-mp lnkup-organizer-dash" id="lnkup-organizer-crm" data-rest="<?php echo esc_url( rest_url( 'lnkup/v1/crm' ) ); ?>">
			<section class="lnkup-organizer-overview" id="overview">
				<header class="lnkup-organizer-hero lnkup-organizer-hero--command lnkup-dash-header">
					<div class="lnkup-organizer-hero__copy">
						<h1 class="lnkup-dash-header__title"><?php echo esc_html( lnkup_copy( 'organizer_command_center' ) ); ?></h1>
						<p class="lnkup-dash-header__subtitle"><?php echo esc_html( lnkup_copy( 'command_center' ) ); ?> — <?php esc_html_e( 'Run events, vendors, and vendor revenue from one place.', 'lnkup-marketplace' ); ?></p>
						<p class="lnkup-organizer-hero__summary"><?php echo esc_html( $command_summary_line ); ?></p>
					</div>
					<div class="lnkup-organizer-hero__ctas">
						<a href="<?php echo esc_url( $dash_url . '#create' ); ?>" class="lnkup-btn lnkup-btn--primary" data-open-create><?php echo esc_html( lnkup_copy( 'launch_event' ) ); ?></a>
						<a href="<?php echo esc_url( $dash_url . '#invites' ); ?>" class="lnkup-btn lnkup-btn--outline"><?php echo esc_html( lnkup_copy( 'invite_vendors' ) ); ?></a>
						<a href="<?php echo esc_url( $dash_url . '#financial' ); ?>" class="lnkup-btn lnkup-btn--ghost" data-expand="financial"><?php echo esc_html( lnkup_copy( 'open_financial_center' ) ); ?></a>
					</div>
				</header>

				<?php echo self::render_organizer_section_nav( $dash_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<div class="lnkup-grid lnkup-grid--5 lnkup-organizer-dash__stats lnkup-organizer-kpis lnkup-organizer-kpis--command" id="lnkup-crm-stats">
					<?php
					$pending_trend = count( $pending_apps ) > 0
						? __( 'Needs review', 'lnkup-marketplace' )
						: __( 'All caught up', 'lnkup-marketplace' );
					$pending_dir   = count( $pending_apps ) > 0 ? 'up' : 'neutral';
					$events_trend  = $live_events_count > 0
						? sprintf( _n( '%d upcoming', '%d upcoming', $live_events_count, 'lnkup-marketplace' ), $live_events_count )
						: __( 'Create your first', 'lnkup-marketplace' );
					$booked_trend  = $vendors_booked > 0
						? sprintf( __( '%d approved', 'lnkup-marketplace' ), count( $approved_vendors ) )
						: __( 'No bookings yet', 'lnkup-marketplace' );
					echo LNKup_Vendor_Dashboard_Views::stat_card( lnkup_copy( 'live_events' ), (string) $live_events_count, $events_trend, 'calendar', 0 === $live_events_count, $live_events_count > 0 ? 'up' : 'neutral', $dash_url . '#events' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo LNKup_Vendor_Dashboard_Views::stat_card( lnkup_copy( 'new_vendor_requests' ), (string) count( $pending_apps ), $pending_trend, 'inbox', 0 === count( $pending_apps ), $pending_dir, $dash_url . '#applications' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo LNKup_Vendor_Dashboard_Views::stat_card( lnkup_copy( 'confirmed_vendors' ), (string) $vendors_booked, $booked_trend, 'users', 0 === $vendors_booked, $vendors_booked > 0 ? 'up' : 'neutral', $dash_url . '#events' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo LNKup_Vendor_Dashboard_Views::stat_card( lnkup_copy( 'vendor_revenue' ), lnkup_currency( $collected ), lnkup_copy( 'collected_to_date' ), 'payment', $collected <= 0, $collected > 0 ? 'up' : 'neutral', $dash_url . '#financial' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo LNKup_Vendor_Dashboard_Views::stat_card( lnkup_copy( 'event_readiness' ), $readiness_kpi_value, $readiness_kpi_trend, 'shield', $at_risk_readiness_count > 0, $at_risk_readiness_count > 0 ? 'down' : 'up', $dash_url . '#applications' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				</div>

				<div class="lnkup-grid lnkup-grid--3" id="lnkup-crm-widgets-grid"></div>

				<div class="lnkup-organizer-priority-fin-row">
					<div class="lnkup-organizer-priority-fin-row__main">
						<?php echo $priority_module_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php if ( $attention_items && ! $has_priority_module ) : ?>
							<div class="lnkup-panel lnkup-organizer-attention">
								<h2 class="lnkup-panel__title"><?php esc_html_e( 'Needs your attention', 'lnkup-marketplace' ); ?></h2>
								<ul class="lnkup-organizer-attention__list">
									<?php foreach ( $attention_items as $item ) : ?>
										<li class="lnkup-organizer-attention__item">
											<a href="<?php echo esc_url( $item['href'] ); ?>" class="lnkup-organizer-attention__link">
												<span class="lnkup-organizer-attention__dot lnkup-organizer-attention__dot--<?php echo esc_attr( $item['level'] ); ?>" aria-hidden="true"></span>
												<span class="lnkup-organizer-attention__label"><?php echo esc_html( $item['label'] ); ?></span>
												<span class="lnkup-organizer-attention__count"><?php echo esc_html( (string) $item['count'] ); ?></span>
											</a>
										</li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endif; ?>
						<?php if ( ! $has_priority_module && ! $attention_items && 0 === $event_count ) : ?>
							<?php
							echo lnkup_empty_state(
								__( 'Get started with your first event', 'lnkup-marketplace' ),
								__( 'Launch an event to publish vendor opportunities and start receiving vendor requests.', 'lnkup-marketplace' ),
								lnkup_copy( 'launch_event' ),
								$dash_url . '#create'
							); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						<?php endif; ?>
					</div>
					<div class="lnkup-organizer-priority-fin-row__side">
						<?php echo self::render_organizer_fin_snapshot( $available_payout, $collected, $dash_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				</div>
			</section>

			<?php
			$events_count_label = sprintf( _n( '%d event', '%d events', $event_count, 'lnkup-marketplace' ), $event_count );
			$events_actions     = '<span class="lnkup-organizer-section-card__count lnkup-muted">' . esc_html( $events_count_label ) . '</span>';
			$events_actions    .= '<a href="' . esc_url( $dash_url . '#create' ) . '" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" data-open-create>' . esc_html( lnkup_copy( 'launch_event' ) ) . '</a>';
			echo self::organizer_section_card_open( 'events', __( 'Your Events', 'lnkup-marketplace' ), __( 'Manage events, operations, and vendor recruitment', 'lnkup-marketplace' ), $events_actions ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
				<span id="operations" class="lnkup-panel__anchor" tabindex="-1"></span>
				<?php echo self::render_organizer_events(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo self::organizer_section_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<?php echo self::organizer_section_card_open( 'applications', lnkup_copy( 'vendor_requests' ), __( 'Approve, waitlist, or reject vendor requests', 'lnkup-marketplace' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php if ( count( $apps ) >= 10 ) : ?>
					<div class="lnkup-organizer-app-layout" role="group" aria-label="<?php esc_attr_e( 'Application layout', 'lnkup-marketplace' ); ?>">
						<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm is-active" data-org-app-layout="grid"><?php esc_html_e( 'Cards', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" data-org-app-layout="list"><?php esc_html_e( 'List', 'lnkup-marketplace' ); ?></button>
					</div>
				<?php endif; ?>
				<?php
				$app_count_waitlisted = count(
					array_filter(
						$apps,
						function ( $a ) {
							return 'waitlisted' === get_post_meta( $a->ID, '_lnkup_application_status', true );
						}
					)
				);
				$app_count_rejected = count(
					array_filter(
						$apps,
						function ( $a ) {
							return 'rejected' === get_post_meta( $a->ID, '_lnkup_application_status', true );
						}
					)
				);
				?>
				<div class="lnkup-dash-tabs lnkup-organizer-app-filters lnkup-organizer-app-filters--sticky" role="tablist" aria-label="<?php esc_attr_e( 'Application filters', 'lnkup-marketplace' ); ?>">
					<button type="button" class="lnkup-dash-tabs__btn is-active" data-org-app-filter="all"><?php esc_html_e( 'All', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) count( $apps ) ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="pending"><?php esc_html_e( 'Pending', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) count( $pending_apps ) ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="approved"><?php esc_html_e( 'Approved', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) count( $approved_vendors ) ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="unpaid"><?php esc_html_e( 'Unpaid', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) count( $unpaid_apps ) ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn lnkup-dash-tabs__btn--more" data-org-app-filter-toggle aria-expanded="false"><?php esc_html_e( 'More filters', 'lnkup-marketplace' ); ?></button>
				</div>
				<div class="lnkup-organizer-app-filters lnkup-organizer-app-filters--extra" id="lnkup-org-app-filters-extra" hidden>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="waitlisted"><?php esc_html_e( 'Waitlisted', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) $app_count_waitlisted ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="rejected"><?php esc_html_e( 'Rejected', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) $app_count_rejected ); ?></span></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-org-app-filter="missing_docs"><?php esc_html_e( 'Missing Docs', 'lnkup-marketplace' ); ?> <span class="lnkup-dash-tabs__badge"><?php echo esc_html( (string) count( $missing_docs ) ); ?></span></button>
				</div>
				<div id="lnkup-app-intel-grid">
					<?php echo self::render_applications_manager(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-crm-compare-bar" id="lnkup-crm-compare-bar" hidden>
					<span class="lnkup-crm-compare-bar__count" id="lnkup-crm-compare-count"><?php esc_html_e( '0 selected', 'lnkup-marketplace' ); ?></span>
					<div class="lnkup-crm-compare-bar__actions">
						<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" id="lnkup-crm-compare-clear"><?php esc_html_e( 'Clear', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-crm-compare-open"><?php esc_html_e( 'Compare', 'lnkup-marketplace' ); ?></button>
					</div>
				</div>
			<?php echo self::organizer_section_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<div class="lnkup-organizer-secondary-grid">
				<?php echo self::organizer_module_card_open( 'vendors', lnkup_copy( 'discover_vendors' ), __( 'Search and recruit vendors for your events', 'lnkup-marketplace' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<input type="search" id="lnkup-crm-vendor-search" class="lnkup-crm-search lnkup-organizer-module-card__search" placeholder="<?php esc_attr_e( 'Search vendors…', 'lnkup-marketplace' ); ?>" />
					<div id="lnkup-organizer-vendors-preview" class="lnkup-organizer-vendors-preview" data-loaded="1" data-ssr="1">
						<?php echo self::render_organizer_vendors_preview_ssr( $user_id, $dash_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand-panel="vendors"><?php echo esc_html( lnkup_copy( 'expand_vendors' ) ); ?></button>
					<?php echo self::organizer_expand_panel_open( 'vendors' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div class="lnkup-crm-toolbar">
							<div class="lnkup-crm-toolbar__tabs">
								<button type="button" class="lnkup-btn lnkup-btn--sm is-active" data-crm-scope="discover"><?php esc_html_e( 'Discover', 'lnkup-marketplace' ); ?></button>
								<button type="button" class="lnkup-btn lnkup-btn--sm" data-crm-scope="my"><?php esc_html_e( 'My Vendors', 'lnkup-marketplace' ); ?></button>
							</div>
							<div class="lnkup-crm-toolbar__views">
								<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm is-active" data-crm-view="card"><?php esc_html_e( 'Cards', 'lnkup-marketplace' ); ?></button>
								<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" data-crm-view="table"><?php esc_html_e( 'Table', 'lnkup-marketplace' ); ?></button>
								<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" data-crm-view="compact"><?php esc_html_e( 'List', 'lnkup-marketplace' ); ?></button>
							</div>
							<select id="lnkup-crm-vendor-sort" class="lnkup-crm-search">
								<option value="score"><?php esc_html_e( 'Highest score', 'lnkup-marketplace' ); ?></option>
								<option value="rating"><?php esc_html_e( 'Best rating', 'lnkup-marketplace' ); ?></option>
								<option value="completed"><?php esc_html_e( 'Most events', 'lnkup-marketplace' ); ?></option>
								<option value="reliable"><?php esc_html_e( 'Most reliable', 'lnkup-marketplace' ); ?></option>
								<option value="preferred"><?php esc_html_e( 'Preferred first', 'lnkup-marketplace' ); ?></option>
								<option value="new"><?php esc_html_e( 'New vendors', 'lnkup-marketplace' ); ?></option>
							</select>
						</div>
						<div id="lnkup-crm-directory" class="lnkup-crm-directory--limited"></div>
						<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" id="lnkup-crm-directory-more" hidden><?php esc_html_e( 'Show more', 'lnkup-marketplace' ); ?></button>
					<?php echo self::organizer_expand_panel_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo self::organizer_module_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<?php echo self::organizer_module_card_open( 'lists', __( 'Vendor Lists', 'lnkup-marketplace' ), __( 'Reusable lists for invites and outreach', 'lnkup-marketplace' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<p id="lnkup-organizer-lists-summary" class="lnkup-muted lnkup-organizer-module-summary"><?php esc_html_e( 'No lists yet. Create one to organize vendors.', 'lnkup-marketplace' ); ?></p>
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand-panel="lists" id="lnkup-crm-new-list-compact"><?php esc_html_e( 'Create list', 'lnkup-marketplace' ); ?></button>
					<?php echo self::organizer_expand_panel_open( 'lists' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div class="lnkup-organizer-smart-lists" role="group" aria-label="<?php esc_attr_e( 'Smart lists', 'lnkup-marketplace' ); ?>">
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-smart-list" data-crm-scope="my" data-crm-sort="preferred"><?php esc_html_e( 'Preferred Vendors', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-smart-list" data-org-app-filter="missing_docs"><?php esc_html_e( 'Missing Docs', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-smart-list" data-org-app-filter="unpaid"><?php esc_html_e( 'Unpaid Vendors', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-smart-list" data-crm-scope="discover" data-crm-sort="rating"><?php esc_html_e( 'High Rated', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-smart-list" data-crm-scope="my" data-crm-sort="completed"><?php esc_html_e( 'Recently Worked', 'lnkup-marketplace' ); ?></button>
						</div>
						<div id="lnkup-crm-lists"></div>
						<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-crm-new-list"><?php esc_html_e( 'New List', 'lnkup-marketplace' ); ?></button>
					<?php echo self::organizer_expand_panel_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo self::organizer_module_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<?php echo self::organizer_module_card_open( 'invites', __( 'Vendor Invites', 'lnkup-marketplace' ), __( 'Track sent invites and resend links', 'lnkup-marketplace' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<p id="lnkup-organizer-invites-summary" class="lnkup-muted lnkup-organizer-module-summary"><?php esc_html_e( 'No invites sent yet.', 'lnkup-marketplace' ); ?></p>
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand-panel="invites"><?php echo esc_html( lnkup_copy( 'invite_vendors' ) ); ?></button>
					<?php echo self::organizer_expand_panel_open( 'invites' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-crm-invites"></div>
					<?php echo self::organizer_expand_panel_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo self::organizer_module_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<?php echo self::organizer_module_card_open( 'intelligence', __( 'Event Intelligence', 'lnkup-marketplace' ), __( 'Benchmarks, funnel health, and insights', 'lnkup-marketplace' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<div id="lnkup-organizer-intel-summary" class="lnkup-organizer-intel-summary" data-loaded="1" data-ssr="1">
						<?php echo self::render_organizer_intel_summary_ssr( $user_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand-panel="intelligence"><?php echo esc_html( lnkup_copy( 'view_insights' ) ); ?></button>
					<?php echo self::organizer_expand_panel_open( 'intelligence' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-organizer-intelligence" class="lnkup-intel-shell" data-organizer-id="<?php echo esc_attr( (string) $user_id ); ?>">
							<div class="lnkup-crm-skeleton lnkup-crm-skeleton--tall" aria-hidden="true"></div>
						</div>
					<?php echo self::organizer_expand_panel_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo self::organizer_module_card_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<section id="create" class="lnkup-organizer-launch-card lnkup-panel" data-section="create">
				<h2 class="lnkup-panel__title"><?php echo esc_html( lnkup_copy( 'launch_opportunity_title' ) ); ?></h2>
				<div class="lnkup-organizer-create-launcher" id="lnkup-create-launcher">
					<p class="lnkup-muted"><?php echo esc_html( lnkup_copy( 'launch_opportunity_copy' ) ); ?></p>
					<button type="button" class="lnkup-btn lnkup-btn--primary" data-open-create><?php echo esc_html( lnkup_copy( 'start_event_setup' ) ); ?></button>
				</div>
				<div id="lnkup-create-panel-wrap" class="lnkup-organizer-expand-panel" hidden>
					<?php echo self::render_create_panel( $events ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</section>

			<section id="financial" class="lnkup-organizer-section-card lnkup-panel" data-section="financial">
				<div class="lnkup-organizer-section-card__header">
					<div class="lnkup-organizer-section-card__head">
						<h2 class="lnkup-panel__title"><?php echo esc_html( lnkup_copy( 'financial_center' ) ); ?></h2>
						<p class="lnkup-organizer-section-card__desc lnkup-muted"><?php esc_html_e( 'Wallet balance, payout schedule, and organizer revenue', 'lnkup-marketplace' ); ?></p>
					</div>
					<div class="lnkup-organizer-section-card__actions">
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand-panel="financial"><?php echo esc_html( lnkup_copy( 'open_financial_center' ) ); ?></button>
					</div>
				</div>
				<?php echo self::organizer_expand_panel_open( 'financial' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo LNKup_Financial_Render::organizer_shell(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo self::organizer_expand_panel_close(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</section>

			<div id="lnkup-intel-drawer" class="lnkup-intel-drawer" hidden aria-hidden="true">
				<div class="lnkup-intel-drawer__panel" role="dialog" aria-modal="true">
					<button type="button" class="lnkup-intel-drawer__close" id="lnkup-intel-drawer-close">&times;</button>
					<div id="lnkup-intel-drawer-content"></div>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Opportunities feed shortcode — Marketplace V2.
	 */
	public static function render_opportunities_feed() {
		$apply       = isset( $_GET['apply'] ) ? absint( $_GET['apply'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$phase       = lnkup_get_marketplace_phase();
		$phase_1b    = lnkup_marketplace_phase_at_least( '1b' );
		$phase_1c    = lnkup_marketplace_phase_at_least( '1c' );
		$categories  = get_terms( array( 'taxonomy' => 'lnkup_vendor_category', 'hide_empty' => false ) );
		$event_types = lnkup_get_event_type_parents();
		$event_type_tree = lnkup_get_event_type_tree();
		$markets     = get_terms( array( 'taxonomy' => 'lnkup_market', 'hide_empty' => false ) );
		$filter_args = lnkup_parse_marketplace_filters( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$initial     = lnkup_get_filtered_opportunities( $filter_args );
		$search_q    = $filter_args['q'] ?? '';
		$current_sort = $filter_args['sort'] ?? ( $search_q ? 'relevance' : 'newest' );
		$quick_chip_types = array( 'Festivals', 'Conferences', 'Markets & Pop-Ups', 'Campus Events', 'Corporate & Brand' );
		$featured_event_types = array();
		if ( $event_types ) {
			$type_names = wp_list_pluck( $event_types, 'name' );
			foreach ( $quick_chip_types as $chip_name ) {
				if ( in_array( $chip_name, $type_names, true ) ) {
					$featured_event_types[] = $chip_name;
				}
			}
		}
		$invite_token = isset( $_GET['invite'] ) ? sanitize_text_field( wp_unslash( $_GET['invite'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$explore_collections = array();
		if ( $phase_1b && class_exists( 'LNKup_Collections' ) ) {
			$coll_defs      = LNKup_Collections::get_definitions();
			$featured_slugs = array( 'food-festivals', 'college-events', 'top-rodeos', 'weekend', 'under-100', 'large-festivals', 'indoor-markets', 'family-events' );
			foreach ( $featured_slugs as $coll_slug ) {
				if ( empty( $coll_defs[ $coll_slug ] ) ) {
					continue;
				}
				$coll_def = $coll_defs[ $coll_slug ];
				$explore_collections[] = array(
					'slug'    => $coll_slug,
					'label'   => $coll_def['label'],
					'filters' => $coll_def['filters'] ?? array(),
					'section' => $coll_def['section'] ?? '',
				);
			}
		}
		$invite_banner = '';
		if ( $invite_token && class_exists( 'LNKup_Vendor_Invites' ) ) {
			LNKup_Vendor_Invites::mark_opened( $invite_token );
			$invite_post = LNKup_Vendor_Invites::get_by_token( $invite_token );
			if ( $invite_post ) {
				$invite_status = get_post_meta( $invite_post->ID, '_lnkup_status', true );
				$opp_id        = (int) get_post_meta( $invite_post->ID, '_lnkup_opportunity_id', true );
				$event_id      = (int) get_post_meta( $invite_post->ID, '_lnkup_event_id', true );
				$event_title   = $event_id ? get_the_title( $event_id ) : '';
				$message       = get_post_meta( $invite_post->ID, '_lnkup_invite_message', true );
				ob_start();
				?>
				<div class="lnkup-alert lnkup-alert--info lnkup-invite-banner" id="lnkup-invite-banner" data-token="<?php echo esc_attr( $invite_token ); ?>">
					<p><strong><?php esc_html_e( 'You have an event invite', 'lnkup-marketplace' ); ?></strong><?php if ( $event_title ) : ?> — <?php echo esc_html( $event_title ); ?><?php endif; ?></p>
					<?php if ( $message ) : ?><p><?php echo esc_html( $message ); ?></p><?php endif; ?>
					<?php if ( in_array( $invite_status, array( 'sent', 'opened' ), true ) ) : ?>
						<div class="lnkup-invite-banner__actions">
							<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-invite-accept"><?php esc_html_e( 'Accept Invite', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" id="lnkup-invite-decline"><?php esc_html_e( 'Decline', 'lnkup-marketplace' ); ?></button>
							<?php if ( $opp_id ) : ?>
								<a href="<?php echo esc_url( add_query_arg( 'apply', $opp_id, lnkup_page_url_helper( 'opportunities' ) ) ); ?>" class="lnkup-btn lnkup-btn--outline lnkup-btn--sm"><?php esc_html_e( 'Apply Now', 'lnkup-marketplace' ); ?></a>
							<?php endif; ?>
						</div>
					<?php else : ?>
						<p class="lnkup-muted"><?php echo esc_html( ucfirst( $invite_status ) ); ?></p>
					<?php endif; ?>
				</div>
				<?php
				$invite_banner = ob_get_clean();
			}
		}

		ob_start();
		?>
		<?php echo $invite_banner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<div class="lnkup-mp lnkup-mp-v2" id="lnkup-marketplace" data-rest="<?php echo esc_url( rest_url( 'lnkup/v1/marketplace' ) ); ?>" data-phase="<?php echo esc_attr( $phase ); ?>"<?php echo $apply ? ' data-initial-apply="' . esc_attr( (string) $apply ) . '"' : ''; ?>>
			<header class="lnkup-mp-v2__hero lnkup-dash-header">
				<?php if ( is_user_logged_in() && class_exists( 'LNKup_Roles' ) && LNKup_Roles::is_vendor() ) : ?>
					<?php
					echo lnkup_dash_breadcrumb(
						array(
							array(
								'label' => __( 'Home', 'lnkup-marketplace' ),
								'href'  => lnkup_page_url_helper( 'vendor-dashboard' ),
							),
							array(
								'label' => __( 'Find Events', 'lnkup-marketplace' ),
							),
						)
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				<?php endif; ?>
				<div class="lnkup-mp-v2__hero-text">
					<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Find Events', 'lnkup-marketplace' ); ?></h1>
					<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Discover festivals, conferences, pop-ups, markets, speaking events, brand activations, and live opportunities looking for vendors.', 'lnkup-marketplace' ); ?></p>
				</div>
				<p class="lnkup-muted lnkup-mp-v2__count" id="lnkup-result-count"><?php echo esc_html( sprintf( __( '%d opportunities', 'lnkup-marketplace' ), (int) $initial['total'] ) ); ?></p>
			</header>

			<div class="lnkup-mp-v2__filter-bar lnkup-mp-v2__filter-bar--sticky">
				<form class="lnkup-mp-v2__search-bar" id="lnkup-search-form" role="search">
					<div class="lnkup-mp-v2__search-wrap">
						<input type="search" id="lnkup-search-input" name="q" class="lnkup-mp-v2__search" placeholder="<?php esc_attr_e( 'Search events, organizers, cities, categories…', 'lnkup-marketplace' ); ?>" autocomplete="off" value="<?php echo esc_attr( $search_q ); ?>" />
						<?php if ( $phase_1b ) : ?>
						<div class="lnkup-mp-v2__suggestions" id="lnkup-suggestions" hidden></div>
						<?php endif; ?>
					</div>
					<button type="submit" class="lnkup-btn lnkup-btn--primary lnkup-mp-v2__search-btn" id="lnkup-search-submit"><?php esc_html_e( 'Search', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-mp-v2__filter-toggle" id="lnkup-filter-toggle" aria-expanded="false"><?php esc_html_e( 'Filters', 'lnkup-marketplace' ); ?></button>
				</form>

				<div class="lnkup-mp-v2__toolbar lnkup-mp-v2__toolbar--desktop">
					<?php if ( $event_type_tree ) : ?>
					<select id="lnkup-filter-event-type-parent" class="lnkup-mp-v2__sort" aria-label="<?php esc_attr_e( 'Event category', 'lnkup-marketplace' ); ?>">
						<option value=""><?php esc_html_e( 'All categories', 'lnkup-marketplace' ); ?></option>
						<?php foreach ( $event_type_tree as $parent_group ) : ?>
							<option value="<?php echo esc_attr( $parent_group['name'] ); ?>"><?php echo esc_html( $parent_group['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<select id="lnkup-filter-event-type" class="lnkup-mp-v2__sort" data-filter="event_types_select" aria-label="<?php esc_attr_e( 'Event subtype', 'lnkup-marketplace' ); ?>">
						<option value=""><?php esc_html_e( 'All subtypes', 'lnkup-marketplace' ); ?></option>
					</select>
					<p class="lnkup-muted lnkup-mp-v2__type-hint" id="lnkup-filter-event-type-hint" hidden><?php esc_html_e( 'Choose a category to filter by subtype.', 'lnkup-marketplace' ); ?></p>
					<?php endif; ?>
					<select id="lnkup-filter-attendance" class="lnkup-mp-v2__sort" data-filter="attendance_bucket" aria-label="<?php esc_attr_e( 'Expected attendance', 'lnkup-marketplace' ); ?>">
						<option value=""><?php esc_html_e( 'Any attendance', 'lnkup-marketplace' ); ?></option>
						<option value="0-500" <?php selected( $filter_args['attendance_bucket'] ?? '', '0-500' ); ?>>0–500</option>
						<option value="500-1000" <?php selected( $filter_args['attendance_bucket'] ?? '', '500-1000' ); ?>>500–1k</option>
						<option value="1000-5000" <?php selected( $filter_args['attendance_bucket'] ?? '', '1000-5000' ); ?>>1k–5k</option>
						<option value="5000-10000" <?php selected( $filter_args['attendance_bucket'] ?? '', '5000-10000' ); ?>>5k–10k</option>
						<option value="10000+" <?php selected( $filter_args['attendance_bucket'] ?? '', '10000+' ); ?>>10k+</option>
					</select>
					<select id="lnkup-sort" class="lnkup-mp-v2__sort">
						<option value="relevance" <?php selected( $current_sort, 'relevance' ); ?>><?php esc_html_e( 'Best Match', 'lnkup-marketplace' ); ?></option>
						<option value="recommended" <?php selected( $current_sort, 'recommended' ); ?>><?php esc_html_e( 'Recommended', 'lnkup-marketplace' ); ?></option>
						<option value="newest" <?php selected( $current_sort, 'newest' ); ?>><?php esc_html_e( 'Newest', 'lnkup-marketplace' ); ?></option>
						<option value="soonest" <?php selected( $current_sort, 'soonest' ); ?>><?php esc_html_e( 'Soonest', 'lnkup-marketplace' ); ?></option>
						<option value="deadline" <?php selected( $current_sort, 'deadline' ); ?>><?php esc_html_e( 'Closing Soon', 'lnkup-marketplace' ); ?></option>
						<option value="fee_low" <?php selected( $current_sort, 'fee_low' ); ?>><?php esc_html_e( 'Lowest Fee', 'lnkup-marketplace' ); ?></option>
						<option value="attendance" <?php selected( $current_sort, 'attendance' ); ?>><?php esc_html_e( 'Highest Attendance', 'lnkup-marketplace' ); ?></option>
						<option value="spots" <?php selected( $current_sort, 'spots' ); ?>><?php esc_html_e( 'Most Spots Remaining', 'lnkup-marketplace' ); ?></option>
						<option value="popular" <?php selected( $current_sort, 'popular' ); ?>><?php esc_html_e( 'Most Popular', 'lnkup-marketplace' ); ?></option>
						<option value="most_applied" <?php selected( $current_sort, 'most_applied' ); ?>><?php esc_html_e( 'Most Applied', 'lnkup-marketplace' ); ?></option>
						<option value="closest" <?php selected( $current_sort, 'closest' ); ?>><?php esc_html_e( 'Closest', 'lnkup-marketplace' ); ?></option>
					</select>
					<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" id="lnkup-save-search"><?php esc_html_e( 'Save Search', 'lnkup-marketplace' ); ?></button>
				</div>
			</div>

			<div class="lnkup-mp-v2__quick-chips" id="lnkup-quick-chips">
				<?php foreach ( $featured_event_types as $chip_type ) : ?>
					<button type="button" class="lnkup-badge lnkup-badge--secondary lnkup-quick-chip" data-quick-filter="<?php echo esc_attr( wp_json_encode( array( 'event_types' => $chip_type ) ) ); ?>"><?php echo esc_html( $chip_type ); ?></button>
				<?php endforeach; ?>
				<button type="button" class="lnkup-badge lnkup-badge--secondary lnkup-quick-chip" data-quick-filter='{"date_preset":"weekend"}'><?php esc_html_e( 'This Weekend', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-badge lnkup-badge--secondary lnkup-quick-chip" data-quick-filter='{"closing_soon":true}'><?php esc_html_e( 'Closing Soon', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-badge lnkup-badge--secondary lnkup-quick-chip" data-quick-filter='{"fee_bucket":"under_100"}'><?php esc_html_e( 'Low Fee', 'lnkup-marketplace' ); ?></button>
			</div>

			<div class="lnkup-mp-v2__active-filters" id="lnkup-active-filters"<?php echo empty( $initial['active_filters'] ) ? ' hidden' : ''; ?>>
				<?php foreach ( (array) $initial['active_filters'] as $chip ) : ?>
					<button type="button" class="lnkup-badge lnkup-badge--outline lnkup-active-filter-chip" data-filter-key="<?php echo esc_attr( $chip['key'] ); ?>" data-filter-value="<?php echo esc_attr( $chip['value'] ?? '' ); ?>"><?php echo esc_html( $chip['label'] ); ?> ×</button>
				<?php endforeach; ?>
				<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" id="lnkup-clear-filters-inline"><?php esc_html_e( 'Clear all', 'lnkup-marketplace' ); ?></button>
			</div>

			<aside class="lnkup-mp-v2__filter-drawer lnkup-mp-v2__filter-drawer--closed" id="lnkup-filter-drawer">
				<div class="lnkup-mp-v2__filter-inner">
					<h3><?php esc_html_e( 'Filters', 'lnkup-marketplace' ); ?></h3>
					<label><?php esc_html_e( 'City', 'lnkup-marketplace' ); ?><input type="text" name="city" data-filter="city" value="<?php echo esc_attr( $filter_args['city'] ?? '' ); ?>" /></label>
					<label><?php esc_html_e( 'State', 'lnkup-marketplace' ); ?><input type="text" name="state" data-filter="state" maxlength="2" value="<?php echo esc_attr( $filter_args['state'] ?? '' ); ?>" /></label>
					<?php if ( $markets && ! is_wp_error( $markets ) ) : ?>
					<label><?php esc_html_e( 'Market', 'lnkup-marketplace' ); ?>
						<select data-filter="market_select">
							<option value=""><?php esc_html_e( 'Any market', 'lnkup-marketplace' ); ?></option>
							<?php foreach ( $markets as $term ) : ?>
								<option value="<?php echo esc_attr( $term->name ); ?>"><?php echo esc_html( $term->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<?php endif; ?>
					<label><?php esc_html_e( 'Date', 'lnkup-marketplace' ); ?>
						<select data-filter="date_preset">
							<option value=""><?php esc_html_e( 'Any time', 'lnkup-marketplace' ); ?></option>
							<option value="today"><?php esc_html_e( 'Today', 'lnkup-marketplace' ); ?></option>
							<option value="tomorrow"><?php esc_html_e( 'Tomorrow', 'lnkup-marketplace' ); ?></option>
							<option value="weekend"><?php esc_html_e( 'This Weekend', 'lnkup-marketplace' ); ?></option>
							<option value="this_week"><?php esc_html_e( 'This Week', 'lnkup-marketplace' ); ?></option>
							<option value="this_month"><?php esc_html_e( 'This Month', 'lnkup-marketplace' ); ?></option>
							<option value="next_30"><?php esc_html_e( 'Next 30 Days', 'lnkup-marketplace' ); ?></option>
						</select>
					</label>
					<label><?php esc_html_e( 'Custom start', 'lnkup-marketplace' ); ?><input type="date" data-filter="date_from" value="<?php echo esc_attr( $filter_args['date_from'] ?? '' ); ?>" /></label>
					<label><?php esc_html_e( 'Custom end', 'lnkup-marketplace' ); ?><input type="date" data-filter="date_to" value="<?php echo esc_attr( $filter_args['date_to'] ?? '' ); ?>" /></label>
					<label><?php esc_html_e( 'Attendance', 'lnkup-marketplace' ); ?>
						<select data-filter="attendance_bucket">
							<option value=""><?php esc_html_e( 'Any', 'lnkup-marketplace' ); ?></option>
							<option value="0-500">0–500</option>
							<option value="500-1000">500–1k</option>
							<option value="1000-5000">1k–5k</option>
							<option value="5000-10000">5k–10k</option>
							<option value="10000+">10k+</option>
						</select>
					</label>
					<label><?php esc_html_e( 'Fee range', 'lnkup-marketplace' ); ?>
						<select data-filter="fee_bucket">
							<option value=""><?php esc_html_e( 'Any fee', 'lnkup-marketplace' ); ?></option>
							<option value="free"><?php esc_html_e( 'Free', 'lnkup-marketplace' ); ?></option>
							<option value="under_100"><?php esc_html_e( 'Under $100', 'lnkup-marketplace' ); ?></option>
							<option value="100_250">$100–$250</option>
							<option value="250_500">$250–$500</option>
							<option value="500_1000">$500–$1,000</option>
							<option value="1000_plus">$1,000+</option>
						</select>
					</label>
					<label><?php esc_html_e( 'Custom min fee ($)', 'lnkup-marketplace' ); ?><input type="number" data-filter="fee_min" min="0" value="<?php echo esc_attr( $filter_args['fee_min'] ?? '' ); ?>" /></label>
					<label><?php esc_html_e( 'Custom max fee ($)', 'lnkup-marketplace' ); ?><input type="number" data-filter="fee_max" min="0" value="<?php echo esc_attr( $filter_args['fee_max'] ?? '' ); ?>" /></label>
					<label><?php esc_html_e( 'Environment', 'lnkup-marketplace' ); ?>
						<select data-filter="environment">
							<option value=""><?php esc_html_e( 'Any', 'lnkup-marketplace' ); ?></option>
							<option value="indoor"><?php esc_html_e( 'Indoor', 'lnkup-marketplace' ); ?></option>
							<option value="outdoor"><?php esc_html_e( 'Outdoor', 'lnkup-marketplace' ); ?></option>
							<option value="both"><?php esc_html_e( 'Indoor/Outdoor', 'lnkup-marketplace' ); ?></option>
							<option value="tented"><?php esc_html_e( 'Tented', 'lnkup-marketplace' ); ?></option>
							<option value="rain_or_shine"><?php esc_html_e( 'Rain or Shine', 'lnkup-marketplace' ); ?></option>
						</select>
					</label>
					<fieldset>
						<legend><?php esc_html_e( 'Documents', 'lnkup-marketplace' ); ?></legend>
						<label><input type="checkbox" data-filter-doc="coi" /> <?php esc_html_e( 'COI Required', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" data-filter-doc="health_permit" /> <?php esc_html_e( 'Health Permit', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" data-filter-doc="business_license" /> <?php esc_html_e( 'Business License', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" data-filter-doc="w9" /> <?php esc_html_e( 'W9 Required', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" data-filter="doc_none" /> <?php esc_html_e( 'No Documents Required', 'lnkup-marketplace' ); ?></label>
					</fieldset>
					<label><input type="checkbox" data-filter="verified_organizer" /> <?php esc_html_e( 'Verified Organizer', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="featured_organizer" /> <?php esc_html_e( 'Featured Organizer', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="instant_approval" /> <?php esc_html_e( 'Instant Approval', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="has_spots" checked /> <?php esc_html_e( 'Has Spots', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="newly_added" /> <?php esc_html_e( 'Newly Added', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="closing_soon" /> <?php esc_html_e( 'Closing Soon', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="almost_full" /> <?php esc_html_e( 'Almost Full', 'lnkup-marketplace' ); ?></label>
					<label><input type="checkbox" data-filter="show_closed" /> <?php esc_html_e( 'Show closed opportunities', 'lnkup-marketplace' ); ?></label>
					<?php if ( $event_type_tree ) : ?>
						<fieldset>
							<legend><?php esc_html_e( 'Event Types', 'lnkup-marketplace' ); ?></legend>
							<?php foreach ( $event_type_tree as $parent_group ) : ?>
								<div class="lnkup-mp-v2__filter-group">
									<label class="lnkup-mp-v2__filter-parent">
										<input type="checkbox" data-filter-event-type="<?php echo esc_attr( $parent_group['name'] ); ?>" />
										<?php echo esc_html( $parent_group['name'] ); ?>
									</label>
									<?php foreach ( $parent_group['children'] as $child_group ) : ?>
										<label class="lnkup-mp-v2__filter-child">
											<input type="checkbox" data-filter-event-type="<?php echo esc_attr( $child_group['name'] ); ?>" />
											<?php echo esc_html( $child_group['name'] ); ?>
										</label>
									<?php endforeach; ?>
								</div>
							<?php endforeach; ?>
						</fieldset>
					<?php endif; ?>
					<?php if ( ! is_wp_error( $categories ) && $categories ) : ?>
						<fieldset>
							<legend><?php esc_html_e( 'Vendor Categories', 'lnkup-marketplace' ); ?></legend>
							<?php foreach ( $categories as $term ) : ?>
								<label><input type="checkbox" data-filter-cat="<?php echo esc_attr( $term->name ); ?>" /> <?php echo esc_html( $term->name ); ?></label>
							<?php endforeach; ?>
						</fieldset>
					<?php endif; ?>
					<div class="lnkup-mp-v2__filter-actions">
						<button type="button" class="lnkup-btn lnkup-btn--primary" id="lnkup-apply-filters"><?php esc_html_e( 'Apply Filters', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--ghost" id="lnkup-clear-filters"><?php esc_html_e( 'Clear All', 'lnkup-marketplace' ); ?></button>
					</div>
				</div>
			</aside>

			<button type="button" class="lnkup-mp-v2__fab" id="lnkup-filter-fab" aria-label="<?php esc_attr_e( 'Filters', 'lnkup-marketplace' ); ?>">☰</button>

			<div class="lnkup-mp-v2__view-row">
				<div class="lnkup-mp-v2__view-toggle">
					<button type="button" class="lnkup-btn lnkup-btn--sm is-active" data-view="grid"><?php esc_html_e( 'Grid', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-btn lnkup-btn--sm" data-view="list"><?php esc_html_e( 'List', 'lnkup-marketplace' ); ?></button>
					<?php if ( $phase_1b ) : ?>
					<button type="button" class="lnkup-btn lnkup-btn--sm" data-view="map" id="lnkup-map-toggle"><?php esc_html_e( 'Map', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-btn lnkup-btn--sm" data-view="split" id="lnkup-split-toggle"><?php esc_html_e( 'Split', 'lnkup-marketplace' ); ?></button>
					<?php endif; ?>
				</div>
			</div>

			<div class="lnkup-mp-v2__split-layout" id="lnkup-split-layout">
			<div class="lnkup-mp-v2__results-view" id="lnkup-grid-view">
				<div class="lnkup-event-grid" id="lnkup-results-grid"><?php echo $initial['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<div id="lnkup-pagination"><?php echo $initial['pagination']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<div class="lnkup-mp-v2__loader" id="lnkup-infinite-loader" hidden><?php echo lnkup_render_opportunity_card_skeleton(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<?php if ( $phase_1b ) : ?>
			<div class="lnkup-mp-v2__map-view" id="lnkup-map-view" hidden></div>
			<?php endif; ?>
			</div>

			<?php if ( $phase_1b ) : ?>
			<details class="lnkup-mp-v2__explore-more lnkup-discovery-rails" id="lnkup-explore-more" hidden>
				<summary class="lnkup-mp-v2__explore-more-toggle">
					<span class="lnkup-mp-v2__explore-more-heading">
						<span class="lnkup-mp-v2__explore-more-title"><?php esc_html_e( 'Explore more opportunities', 'lnkup-marketplace' ); ?></span>
						<span class="lnkup-mp-v2__explore-more-subtitle lnkup-muted"><?php esc_html_e( 'Trending, recommended, and closing soon', 'lnkup-marketplace' ); ?></span>
					</span>
					<span class="lnkup-mp-v2__explore-more-chevron" aria-hidden="true"></span>
				</summary>
				<div class="lnkup-mp-v2__explore-more-body">
					<?php if ( is_user_logged_in() ) : ?>
					<div class="lnkup-mp-v2__saved-searches" id="lnkup-saved-searches" hidden>
						<span class="lnkup-muted"><?php esc_html_e( 'Saved searches', 'lnkup-marketplace' ); ?></span>
						<div class="lnkup-mp-v2__saved-chips" id="lnkup-saved-search-chips"></div>
					</div>
					<?php endif; ?>
					<div class="lnkup-mp-v2__explore-loading" id="lnkup-explore-loading">
						<div class="lnkup-mp-v2__explore-skeleton"></div>
					</div>
					<div class="lnkup-mp-v2__explore-tabs" id="lnkup-explore-tabs" hidden>
						<div class="lnkup-mp-v2__explore-tablist" id="lnkup-explore-tablist" role="tablist"></div>
						<div class="lnkup-mp-v2__explore-panels" id="lnkup-explore-panels"></div>
					</div>
					<script type="application/json" id="lnkup-explore-collections-data"><?php echo wp_json_encode( $explore_collections ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
				</div>
			</details>
			<?php endif; ?>

			<div class="lnkup-mp-v2__empty" id="lnkup-empty-state"<?php echo $initial['empty_state'] ? '' : ' hidden'; ?>>
				<h3><?php esc_html_e( 'No matching opportunities found', 'lnkup-marketplace' ); ?></h3>
				<p><?php esc_html_e( 'Try removing filters or browse popular categories below.', 'lnkup-marketplace' ); ?></p>
				<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-empty-clear"><?php esc_html_e( 'Clear all filters', 'lnkup-marketplace' ); ?></button>
				<?php if ( $phase_1b ) : ?>
				<div id="lnkup-empty-suggestions" class="lnkup-event-grid"></div>
				<?php endif; ?>
			</div>

			<div class="lnkup-mp-v2__error" id="lnkup-error-state" hidden>
				<h3><?php esc_html_e( 'We couldn’t load opportunities', 'lnkup-marketplace' ); ?></h3>
				<p class="lnkup-muted"><?php esc_html_e( 'Check your connection and try again.', 'lnkup-marketplace' ); ?></p>
				<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-error-retry"><?php esc_html_e( 'Retry', 'lnkup-marketplace' ); ?></button>
				<a class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" href="<?php echo esc_url( lnkup_page_url_helper( 'opportunities' ) ); ?>"><?php esc_html_e( 'Reload page', 'lnkup-marketplace' ); ?></a>
			</div>

			<?php if ( $phase_1c ) : ?>
			<div class="lnkup-mp-v2__compare-tray" id="lnkup-compare-tray" hidden>
				<div class="lnkup-mp-v2__compare-inner" id="lnkup-compare-inner"></div>
				<button type="button" class="lnkup-btn lnkup-btn--primary" id="lnkup-compare-open"><?php esc_html_e( 'Compare', 'lnkup-marketplace' ); ?></button>
			</div>
			<?php endif; ?>

			<div class="lnkup-apply-modal" id="lnkup-apply-modal" role="dialog" aria-modal="true" aria-labelledby="lnkup-apply-modal-title" hidden>
				<div class="lnkup-apply-modal__backdrop" data-apply-close></div>
				<div class="lnkup-apply-modal__dialog">
					<button type="button" class="lnkup-apply-modal__close" data-apply-close aria-label="<?php esc_attr_e( 'Close', 'lnkup-marketplace' ); ?>">&times;</button>
					<div id="lnkup-apply-modal-body"></div>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Favorites page shortcode.
	 */
	public static function render_favorites() {
		LNKup_Capabilities::require_login();
		$user_id = get_current_user_id();
		$favs    = LNKup_Vendor_Personalization::get_favorite_opportunities( $user_id, 24 );
		$recent  = LNKup_Vendor_Personalization::get_recent_opportunities( $user_id, 8 );

		ob_start();
		?>
		<div class="lnkup-mp">
			<h1 class="lnkup-heading lnkup-heading--page"><?php esc_html_e( 'Favorites', 'lnkup-marketplace' ); ?></h1>
			<section class="lnkup-panel">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Recently Favorited', 'lnkup-marketplace' ); ?></h2>
				<div class="lnkup-event-grid">
					<?php if ( $favs ) : ?>
						<?php foreach ( $favs as $opp ) : ?>
							<?php echo lnkup_render_opportunity_card_v2( $opp ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endforeach; ?>
					<?php else : ?>
						<p class="lnkup-muted"><?php esc_html_e( 'No favorites yet. Browse the marketplace and tap the heart icon.', 'lnkup-marketplace' ); ?></p>
					<?php endif; ?>
				</div>
			</section>
			<?php if ( $recent ) : ?>
				<section class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Recently Viewed', 'lnkup-marketplace' ); ?></h2>
					<div class="lnkup-event-grid">
						<?php foreach ( $recent as $opp ) : ?>
							<?php echo lnkup_render_opportunity_card_v2( $opp ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endforeach; ?>
					</div>
				</section>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Vendor profile form shortcode.
	 */
	public static function render_vendor_profile_form() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_vendor() && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Vendor access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$profile_id = lnkup_get_vendor_profile_id( get_current_user_id() );
		$profile    = $profile_id ? get_post( $profile_id ) : null;
		$terms      = get_terms( array( 'taxonomy' => 'lnkup_vendor_category', 'hide_empty' => false ) );
		$business   = $profile ? get_post_meta( $profile_id, '_lnkup_business_name', true ) : '';
		$city       = $profile ? get_post_meta( $profile_id, '_lnkup_city', true ) : '';
		$state      = $profile ? get_post_meta( $profile_id, '_lnkup_state', true ) : '';
		$initials   = '';
		foreach ( preg_split( '/\s+/', trim( $business ) ) as $part ) {
			$initials .= strtoupper( substr( $part, 0, 1 ) );
			if ( strlen( $initials ) >= 2 ) {
				break;
			}
		}
		$rep = ( $profile_id && class_exists( 'LNKup_Vendor_Reputation' ) ) ? LNKup_Vendor_Reputation::get( $profile_id ) : null;

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Business Profile', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Keep your vendor details up to date for organizers', 'lnkup-marketplace' ); ?></p>
			</header>

			<div class="lnkup-profile-layout">
				<div class="lnkup-panel lnkup-profile-preview">
					<div class="lnkup-profile-preview__avatar"><?php echo esc_html( $initials ?: 'V' ); ?></div>
					<h2 class="lnkup-profile-preview__name"><?php echo esc_html( $business ?: __( 'Your business', 'lnkup-marketplace' ) ); ?></h2>
					<p class="lnkup-profile-preview__location"><?php echo esc_html( trim( $city . ( $state ? ', ' . $state : '' ) ) ); ?></p>
					<?php if ( $rep && ! empty( $rep['avg_rating'] ) ) : ?>
						<?php echo LNKup_Reputation_Render::star_rating( $rep['avg_rating'], $rep['review_count'] ?? 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endif; ?>
					<?php if ( $profile_id ) : ?>
						<span class="lnkup-badge lnkup-badge--accent"><?php esc_html_e( 'Verified vendor', 'lnkup-marketplace' ); ?></span>
					<?php endif; ?>
				</div>

				<div class="lnkup-panel lnkup-profile-form-card">
					<form class="lnkup-form lnkup-profile-form">
						<?php wp_nonce_field( 'lnkup_profile', 'lnkup_nonce' ); ?>
						<input type="hidden" name="action" value="lnkup_save_profile" />
						<div class="lnkup-grid lnkup-grid--2">
							<div class="lnkup-form-row">
								<label for="business_name"><?php esc_html_e( 'Business Name', 'lnkup-marketplace' ); ?> *</label>
								<input type="text" id="business_name" name="business_name" required value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_business_name', true ) : '' ); ?>" />
							</div>
							<div class="lnkup-form-row">
								<label for="owner_name"><?php esc_html_e( 'Owner / Contact Name', 'lnkup-marketplace' ); ?></label>
								<input type="text" id="owner_name" name="owner_name" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_owner_name', true ) : '' ); ?>" />
							</div>
							<div class="lnkup-form-row">
								<label for="contact_email"><?php esc_html_e( 'Contact Email', 'lnkup-marketplace' ); ?></label>
								<input type="email" id="contact_email" name="contact_email" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_contact_email', true ) : '' ); ?>" />
							</div>
							<div class="lnkup-form-row">
								<label for="contact_phone"><?php esc_html_e( 'Contact Phone', 'lnkup-marketplace' ); ?></label>
								<input type="text" id="contact_phone" name="contact_phone" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_contact_phone', true ) : '' ); ?>" />
							</div>
							<div class="lnkup-form-row">
								<label for="city"><?php esc_html_e( 'City', 'lnkup-marketplace' ); ?></label>
								<input type="text" id="city" name="city" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_city', true ) : '' ); ?>" />
							</div>
							<div class="lnkup-form-row">
								<label for="state"><?php esc_html_e( 'State', 'lnkup-marketplace' ); ?></label>
								<input type="text" id="state" name="state" maxlength="2" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_state', true ) : '' ); ?>" />
							</div>
						</div>
						<div class="lnkup-form-row">
							<label for="description"><?php esc_html_e( 'About your business', 'lnkup-marketplace' ); ?></label>
							<textarea id="description" name="description" rows="5"><?php echo esc_textarea( $profile ? $profile->post_content : '' ); ?></textarea>
						</div>
						<div class="lnkup-form-row">
							<label for="products_services"><?php esc_html_e( 'Products / Services Sold', 'lnkup-marketplace' ); ?></label>
							<textarea id="products_services" name="products_services" rows="3"><?php echo esc_textarea( $profile ? get_post_meta( $profile_id, '_lnkup_products_services', true ) : '' ); ?></textarea>
						</div>
						<div class="lnkup-form-row">
							<label><?php esc_html_e( 'Vendor Categories', 'lnkup-marketplace' ); ?></label>
							<div class="lnkup-chip-select">
								<?php
								$selected = $profile_id ? wp_get_post_terms( $profile_id, 'lnkup_vendor_category', array( 'fields' => 'names' ) ) : array();
								foreach ( $terms as $term ) :
									?>
									<label>
										<input type="checkbox" name="categories[]" value="<?php echo esc_attr( $term->name ); ?>" <?php checked( in_array( $term->name, $selected, true ) ); ?> />
										<span><?php echo esc_html( $term->name ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
						</div>

						<details class="lnkup-profile-details">
							<summary><?php esc_html_e( 'Additional vendor details', 'lnkup-marketplace' ); ?></summary>
							<div class="lnkup-grid lnkup-grid--2" style="margin-top:1rem;">
								<div class="lnkup-form-row">
									<label for="website"><?php esc_html_e( 'Website', 'lnkup-marketplace' ); ?></label>
									<input type="url" id="website" name="website" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_website', true ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="instagram"><?php esc_html_e( 'Instagram', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="instagram" name="instagram" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_instagram', true ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="setup_type"><?php esc_html_e( 'Setup Type', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="setup_type" name="setup_type" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_setup_type', true ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="power_needed"><?php esc_html_e( 'Power Needs', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="power_needed" name="power_needed" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_power_needed', true ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="tent_size"><?php esc_html_e( 'Tent Size', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="tent_size" name="tent_size" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_tent_size', true ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="trailer_size"><?php esc_html_e( 'Trailer / Food Truck Size', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="trailer_size" name="trailer_size" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_trailer_size', true ) : '' ); ?>" />
								</div>
								<?php
								$cities_served = $profile ? json_decode( get_post_meta( $profile_id, '_lnkup_cities_served', true ) ?: '[]', true ) : array();
								$states_served = $profile ? json_decode( get_post_meta( $profile_id, '_lnkup_states_served', true ) ?: '[]', true ) : array();
								?>
								<div class="lnkup-form-row">
									<label for="cities_served"><?php esc_html_e( 'Cities Served (comma-separated)', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="cities_served" name="cities_served" value="<?php echo esc_attr( is_array( $cities_served ) ? implode( ', ', $cities_served ) : '' ); ?>" />
								</div>
								<div class="lnkup-form-row">
									<label for="states_served"><?php esc_html_e( 'States Served (comma-separated)', 'lnkup-marketplace' ); ?></label>
									<input type="text" id="states_served" name="states_served" value="<?php echo esc_attr( is_array( $states_served ) ? implode( ', ', $states_served ) : '' ); ?>" />
								</div>
							</div>
						</details>

						<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Save changes', 'lnkup-marketplace' ); ?></button>
					</form>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Spots filled metrics for an organizer event.
	 *
	 * @param int $event_id Event post ID.
	 */
	private static function organizer_event_spots( $event_id ) {
		$opps = get_posts(
			array(
				'post_type'      => 'lnkup_opportunity',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_lnkup_event_id',
				'meta_value'     => $event_id,
			)
		);
		$total     = 0;
		$remaining = 0;
		foreach ( $opps as $opp_id ) {
			$total     += (int) get_post_meta( $opp_id, '_lnkup_spots_total', true );
			$remaining += (int) get_post_meta( $opp_id, '_lnkup_spots_remaining', true );
		}
		$filled = max( 0, $total - $remaining );
		$pct    = $total > 0 ? (int) round( ( $filled / $total ) * 100 ) : 0;
		return array(
			'total'     => $total,
			'filled'    => $filled,
			'remaining' => $remaining,
			'percent'   => $pct,
		);
	}

	/**
	 * Featured image URL for an organizer event card.
	 *
	 * @param int $event_id Event post ID.
	 */
	private static function organizer_event_image_url( $event_id ) {
		$img_id = (int) get_post_meta( $event_id, '_lnkup_featured_image_id', true );
		if ( ! $img_id ) {
			$img_id = (int) get_post_thumbnail_id( $event_id );
		}
		return $img_id ? wp_get_attachment_image_url( $img_id, 'medium_large' ) : '';
	}

	/**
	 * Sticky in-page section nav for organizer command center.
	 *
	 * @param string $dash_url Dashboard base URL.
	 */
	private static function render_organizer_section_nav( $dash_url ) {
		$sections = array(
			'overview'     => __( 'Overview', 'lnkup-marketplace' ),
			'events'       => __( 'Events', 'lnkup-marketplace' ),
			'vendors'      => __( 'Vendors', 'lnkup-marketplace' ),
			'intelligence' => __( 'Intelligence', 'lnkup-marketplace' ),
			'create'       => __( 'Launch', 'lnkup-marketplace' ),
			'financial'    => __( 'Financials', 'lnkup-marketplace' ),
		);
		ob_start();
		?>
		<nav class="lnkup-organizer-section-nav" aria-label="<?php esc_attr_e( 'Dashboard sections', 'lnkup-marketplace' ); ?>">
			<?php foreach ( $sections as $hash => $label ) : ?>
				<a href="<?php echo esc_url( $dash_url . '#' . $hash ); ?>" class="lnkup-organizer-section-nav__link" data-hash="<?php echo esc_attr( $hash ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php
		return ob_get_clean();
	}

	/**
	 * Priority module rows from missing-doc applications.
	 *
	 * @param array  $missing_docs Apps not event-ready.
	 * @param string $dash_url     Dashboard URL.
	 */
	private static function render_organizer_priority_module( $missing_docs, $dash_url ) {
		$priority_apps = array_values(
			array_filter(
				$missing_docs,
				function ( $a ) {
					$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
					return in_array( $s, array( 'approved', 'payment_required', 'paid' ), true );
				}
			)
		);
		$priority_apps = array_slice( $priority_apps, 0, 5 );
		if ( ! $priority_apps ) {
			return '';
		}
		ob_start();
		?>
		<div class="lnkup-panel lnkup-organizer-priority">
			<h2 class="lnkup-panel__title"><?php echo esc_html( lnkup_copy( 'todays_priority' ) ); ?></h2>
			<ul class="lnkup-organizer-priority__list">
				<?php foreach ( $priority_apps as $app ) : ?>
					<?php
					$profile_id = (int) get_post_meta( $app->ID, '_lnkup_vendor_profile_id', true );
					$profile    = $profile_id ? LNKup_Vendor_CRM_Profile::get( $profile_id, get_current_user_id() ) : null;
					$vendor_name = $profile ? $profile['business_name'] : __( 'Vendor', 'lnkup-marketplace' );
					$readiness   = LNKup_Vendor_Readiness::refresh( $app->ID );
					$vendor_url  = $profile_id ? add_query_arg( 'vendor', $profile_id, $dash_url ) : $dash_url . '#applications';
					?>
					<li class="lnkup-organizer-priority__item">
						<div class="lnkup-organizer-priority__row">
							<div>
								<p class="lnkup-organizer-priority__name"><?php echo esc_html( $vendor_name ); ?></p>
								<p class="lnkup-muted"><?php echo esc_html( LNKup_Vendor_Readiness::label( $readiness ) ); ?></p>
							</div>
							<?php echo lnkup_status_badge( $readiness, LNKup_Vendor_Readiness::label( $readiness ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
						<div class="lnkup-organizer-priority__actions">
							<a href="<?php echo esc_url( $dash_url . '#applications' ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-org-app-filter-trigger="missing_docs"><?php esc_html_e( 'Review docs', 'lnkup-marketplace' ); ?></a>
							<a href="<?php echo esc_url( $vendor_url ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost"><?php esc_html_e( 'View vendor', 'lnkup-marketplace' ); ?></a>
							<a href="<?php echo esc_url( $dash_url . '#applications' ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost"><?php esc_html_e( 'Send reminder', 'lnkup-marketplace' ); ?></a>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Compact vendor requests snapshot for overview.
	 *
	 * @param array  $pending_apps Pending applications.
	 * @param string $dash_url     Dashboard URL.
	 * @param int    $limit        Max cards.
	 */
	private static function render_organizer_apps_snapshot( $pending_apps, $dash_url, $limit = 3 ) {
		$snapshot = array_slice( array_values( $pending_apps ), 0, $limit );
		ob_start();
		?>
		<div class="lnkup-panel lnkup-organizer-snapshot">
			<div class="lnkup-panel__header-row">
				<h2 class="lnkup-panel__title"><?php echo esc_html( lnkup_copy( 'vendor_requests_snapshot' ) ); ?></h2>
			</div>
			<?php if ( $snapshot ) : ?>
				<?php echo self::render_applications_manager( $snapshot ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<div class="lnkup-organizer-snapshot__footer">
					<a href="<?php echo esc_url( $dash_url . '#applications' ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php echo esc_html( lnkup_copy( 'view_all_vendor_requests' ) ); ?></a>
				</div>
			<?php else : ?>
				<p class="lnkup-muted"><?php echo esc_html( lnkup_copy( 'empty_vendor_requests' ) ); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Financial snapshot card for command sidebar.
	 *
	 * @param float  $available_payout Available balance.
	 * @param float  $collected        Collected revenue.
	 * @param string $dash_url         Dashboard URL.
	 */
	private static function render_organizer_fin_snapshot( $available_payout, $collected, $dash_url ) {
		$payout_label = $available_payout > 0 ? lnkup_copy( 'payout_status_active' ) : lnkup_copy( 'payout_status_setup' );
		ob_start();
		?>
		<div class="lnkup-panel lnkup-organizer-fin-snapshot">
			<h2 class="lnkup-panel__title"><?php echo esc_html( lnkup_copy( 'financial_snapshot' ) ); ?></h2>
			<span class="lnkup-muted"><?php echo esc_html( lnkup_copy( 'available_balance' ) ); ?></span>
			<strong class="lnkup-organizer-fin-snapshot__value"><?php echo esc_html( lnkup_currency( $available_payout ) ); ?></strong>
			<p class="lnkup-organizer-fin-snapshot__meta lnkup-muted">
				<?php printf( esc_html__( '%1$s: %2$s · %3$s', 'lnkup-marketplace' ), esc_html( lnkup_copy( 'collected_to_date' ) ), esc_html( lnkup_currency( $collected ) ), esc_html( $payout_label ) ); ?>
			</p>
			<a href="<?php echo esc_url( $dash_url . '#financial' ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand="financial"><?php echo esc_html( lnkup_copy( 'expand_financials' ) ); ?></a>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Open always-visible organizer section card.
	 *
	 * @param string $id       Section anchor id.
	 * @param string $title    Section title.
	 * @param string $desc     Optional description.
	 * @param string $actions  Optional header actions HTML.
	 */
	private static function organizer_section_card_open( $id, $title, $desc = '', $actions = '' ) {
		ob_start();
		?>
		<section id="<?php echo esc_attr( $id ); ?>" class="lnkup-organizer-section-card lnkup-panel" data-section="<?php echo esc_attr( $id ); ?>">
			<div class="lnkup-organizer-section-card__header">
				<div class="lnkup-organizer-section-card__head">
					<h2 class="lnkup-panel__title"><?php echo esc_html( $title ); ?></h2>
					<?php if ( $desc ) : ?>
						<p class="lnkup-organizer-section-card__desc lnkup-muted"><?php echo esc_html( $desc ); ?></p>
					<?php endif; ?>
				</div>
				<?php if ( $actions ) : ?>
					<div class="lnkup-organizer-section-card__actions"><?php echo $actions; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<?php endif; ?>
			</div>
			<div class="lnkup-organizer-section-card__body">
		<?php
		return ob_get_clean();
	}

	/**
	 * Close organizer section card.
	 */
	private static function organizer_section_card_close() {
		return '</div></section>';
	}

	/**
	 * Open inline expand panel for secondary module details.
	 *
	 * @param string $panel_id Panel key (vendors, lists, etc.).
	 * @param bool   $hidden   Whether panel starts hidden.
	 */
	private static function organizer_expand_panel_open( $panel_id, $hidden = true ) {
		$hidden_attr = $hidden ? ' hidden' : '';
		ob_start();
		?>
		<div id="lnkup-organizer-expand-<?php echo esc_attr( $panel_id ); ?>" class="lnkup-organizer-expand-panel" data-expand-panel="<?php echo esc_attr( $panel_id ); ?>"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<?php
		return ob_get_clean();
	}

	/**
	 * Close inline expand panel.
	 */
	private static function organizer_expand_panel_close() {
		return '</div>';
	}

	/**
	 * Open compact secondary module card.
	 *
	 * @param string $id    Section anchor id.
	 * @param string $title Card title.
	 * @param string $desc  Optional description.
	 */
	private static function organizer_module_card_open( $id, $title, $desc = '' ) {
		ob_start();
		?>
		<article id="<?php echo esc_attr( $id ); ?>" class="lnkup-organizer-module-card lnkup-panel" data-section="<?php echo esc_attr( $id ); ?>">
			<h3 class="lnkup-organizer-module-card__title"><?php echo esc_html( $title ); ?></h3>
			<?php if ( $desc ) : ?>
				<p class="lnkup-organizer-module-card__desc lnkup-muted"><?php echo esc_html( $desc ); ?></p>
			<?php endif; ?>
			<div class="lnkup-organizer-module-card__compact">
		<?php
		return ob_get_clean();
	}

	/**
	 * Close compact secondary module card.
	 */
	private static function organizer_module_card_close() {
		return '</div></article>';
	}

	/**
	 * Server-rendered vendor preview cards for the organizer command center.
	 *
	 * @param int    $user_id  Organizer user ID.
	 * @param string $dash_url Dashboard base URL.
	 */
	private static function render_organizer_vendors_preview_ssr( $user_id, $dash_url ) {
		if ( ! class_exists( 'LNKup_Vendor_Directory' ) ) {
			return '<p class="lnkup-muted lnkup-organizer-preview-empty">' . esc_html__( 'Vendor directory unavailable.', 'lnkup-marketplace' ) . '</p>';
		}

		$result = LNKup_Vendor_Directory::search(
			$user_id,
			array(
				'scope'    => 'discover',
				'per_page' => 3,
				'sort'     => 'score',
				'view'     => 'card',
			)
		);
		$items  = $result['items'] ?? array();

		if ( empty( $items ) ) {
			return '<p class="lnkup-muted lnkup-organizer-preview-empty">' . esc_html__( 'No vendor profiles in the marketplace yet.', 'lnkup-marketplace' ) . '</p>';
		}

		ob_start();
		echo '<div class="lnkup-organizer-vendors-preview-grid">';
		foreach ( array_slice( $items, 0, 3 ) as $vendor ) {
			$profile_id = (int) ( $vendor['profile_id'] ?? 0 );
			$name       = $vendor['business_name'] ?? __( 'Vendor', 'lnkup-marketplace' );
			$url        = $profile_id ? add_query_arg( array( 'vendor' => $profile_id ), $dash_url ) : $dash_url . '#vendors';
			$categories = is_array( $vendor['category'] ?? null ) ? array_slice( $vendor['category'], 0, 2 ) : array();
			$category   = implode( ', ', $categories );
			$rating     = ! empty( $vendor['avg_rating'] ) ? '★ ' . $vendor['avg_rating'] : '';
			$score      = ! empty( $vendor['vendor_score'] ) ? ( (int) $vendor['vendor_score'] . ' score' ) : '';
			$meta       = $rating ?: $score;
			?>
			<a href="<?php echo esc_url( $url ); ?>" class="lnkup-organizer-vendor-preview-card">
				<?php if ( ! empty( $vendor['logo'] ) ) : ?>
					<img src="<?php echo esc_url( $vendor['logo'] ); ?>" alt="" class="lnkup-organizer-vendor-preview-card__logo" loading="lazy" />
				<?php endif; ?>
				<span class="lnkup-organizer-vendor-preview-card__main">
					<strong><?php echo esc_html( $name ); ?></strong>
					<?php if ( $category ) : ?>
						<span class="lnkup-muted lnkup-organizer-vendor-preview-card__cat"><?php echo esc_html( $category ); ?></span>
					<?php endif; ?>
					<?php if ( $meta ) : ?>
						<span class="lnkup-muted lnkup-organizer-vendor-preview-card__meta"><?php echo esc_html( $meta ); ?></span>
					<?php endif; ?>
				</span>
			</a>
			<?php
		}
		echo '</div>';
		return ob_get_clean();
	}

	/**
	 * Server-rendered intelligence summary chips for the organizer command center.
	 *
	 * @param int $user_id Organizer user ID.
	 */
	private static function render_organizer_intel_summary_ssr( $user_id ) {
		if ( ! class_exists( 'LNKup_Organizer_Intelligence' ) ) {
			return '<p class="lnkup-muted">' . esc_html__( 'Insights will appear as your events gain traction.', 'lnkup-marketplace' ) . '</p>';
		}

		$health  = LNKup_Organizer_Intelligence::health( $user_id );
		$summary = LNKup_Organizer_Intelligence::summary( $user_id );
		$score   = isset( $health['score'] ) ? (int) $health['score'] : null;
		$label   = $health['label'] ?? '';
		$actions = $summary['recommended_actions'] ?? array();
		$top     = ! empty( $actions[0] ) ? $actions[0] : null;

		ob_start();
		?>
		<div class="lnkup-organizer-intel-summary__chips">
			<?php if ( null !== $score ) : ?>
				<span class="lnkup-organizer-intel-summary__chip"><?php echo esc_html( sprintf( /* translators: %d: health score */ __( 'Score %d', 'lnkup-marketplace' ), $score ) ); ?></span>
			<?php endif; ?>
			<?php if ( $label ) : ?>
				<span class="lnkup-organizer-intel-summary__chip"><?php echo esc_html( $label ); ?></span>
			<?php endif; ?>
		</div>
		<?php if ( $top && ! empty( $top['title'] ) ) : ?>
			<p class="lnkup-muted">
				<strong><?php echo esc_html( $top['title'] ); ?></strong>
				<?php if ( ! empty( $top['reason'] ) ) : ?>
					&mdash; <?php echo esc_html( $top['reason'] ); ?>
				<?php endif; ?>
			</p>
		<?php elseif ( null !== $score || $label ) : ?>
			<p class="lnkup-muted"><?php esc_html_e( 'Portfolio snapshot ready — expand for full insights.', 'lnkup-marketplace' ); ?></p>
		<?php else : ?>
			<p class="lnkup-muted"><?php esc_html_e( 'Insights will appear as your events gain traction.', 'lnkup-marketplace' ); ?></p>
		<?php endif; ?>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render a single organizer event card.
	 *
	 * @param WP_Post $event     Event post.
	 * @param array   $apps      Organizer applications.
	 * @param array   $payments  Organizer payments.
	 * @param string  $dash_url  Dashboard base URL.
	 */
	private static function render_organizer_event_card( $event, $apps, $payments, $dash_url ) {
		$event_date = get_post_meta( $event->ID, '_lnkup_event_date', true );
		$city       = get_post_meta( $event->ID, '_lnkup_city', true );
		$state      = get_post_meta( $event->ID, '_lnkup_state', true );
		$status     = get_post_meta( $event->ID, '_lnkup_event_status', true ) ?: 'draft';
		$spots      = self::organizer_event_spots( $event->ID );
		$image_url  = self::organizer_event_image_url( $event->ID );
		$vendor_count = count(
			array_filter(
				$apps,
				function ( $a ) use ( $event ) {
					return (int) get_post_meta( $a->ID, '_lnkup_event_id', true ) === (int) $event->ID
						&& in_array( get_post_meta( $a->ID, '_lnkup_application_status', true ), array( 'approved', 'payment_required', 'paid', 'completed' ), true );
				}
			)
		);
		$new_apps = count(
			array_filter(
				$apps,
				function ( $a ) use ( $event ) {
					return (int) get_post_meta( $a->ID, '_lnkup_event_id', true ) === (int) $event->ID
						&& in_array( get_post_meta( $a->ID, '_lnkup_application_status', true ), array( 'submitted', 'under_review' ), true );
				}
			)
		);
		$revenue = array_reduce(
			$payments,
			function ( $sum, $p ) use ( $event ) {
				if ( (int) get_post_meta( $p->ID, '_lnkup_event_id', true ) !== (int) $event->ID ) {
					return $sum;
				}
				if ( 'paid' === get_post_meta( $p->ID, '_lnkup_payment_status', true ) ) {
					return $sum + (float) get_post_meta( $p->ID, '_lnkup_vendor_spot_fee', true );
				}
				return $sum;
			},
			0
		);
		$lifecycle = __( 'Open', 'lnkup-marketplace' );
		if ( $event_date && strtotime( $event_date ) < strtotime( 'today' ) ) {
			$lifecycle = __( 'Past', 'lnkup-marketplace' );
		} elseif ( $spots['total'] > 0 && $spots['filled'] >= $spots['total'] ) {
			$lifecycle = __( 'Full', 'lnkup-marketplace' );
		} elseif ( $spots['filled'] > 0 ) {
			$lifecycle = __( 'Filling', 'lnkup-marketplace' );
		}
		$lifecycle_class = sanitize_html_class( strtolower( $lifecycle ) );
		$roster_url = add_query_arg( array( 'event' => $event->ID, 'roster' => 1 ), $dash_url );
		$ops_url    = add_query_arg( array( 'event' => $event->ID, 'ops' => 1 ), $dash_url );
		$export_url = add_query_arg(
			array(
				'action'      => 'lnkup_export_vendors',
				'event_id'    => $event->ID,
				'lnkup_nonce' => wp_create_nonce( 'lnkup_export' ),
			),
			admin_url( 'admin-ajax.php' )
		);
		$location   = trim( $city . ( $state ? ', ' . $state : '' ) );
		$date_label = $event_date ? date_i18n( 'M j, Y', strtotime( $event_date ) ) : '—';
		$apps_url   = $dash_url . '#applications';
		$fin_url    = $dash_url . '#financial';
		$initial    = strtoupper( substr( trim( $event->post_title ), 0, 1 ) );
		$event_terms = get_the_terms( $event->ID, 'lnkup_event_type' );
		$type_label  = '';
		if ( $event_terms && ! is_wp_error( $event_terms ) && ! empty( $event_terms ) ) {
			$type_term  = $event_terms[0];
			$type_label = $type_term->name;
			if ( $type_term->parent ) {
				$parent_term = get_term( $type_term->parent, 'lnkup_event_type' );
				if ( $parent_term && ! is_wp_error( $parent_term ) ) {
					$type_label = $parent_term->name . ' · ' . $type_label;
				}
			}
		}
		$status_label = ucfirst( str_replace( '_', ' ', $status ) );
		$readiness_issues = count(
			array_filter(
				$apps,
				function ( $a ) use ( $event ) {
					if ( (int) get_post_meta( $a->ID, '_lnkup_event_id', true ) !== (int) $event->ID ) {
						return false;
					}
					$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
					if ( ! in_array( $s, array( 'approved', 'payment_required', 'paid', 'completed' ), true ) ) {
						return false;
					}
					return 'ready' !== LNKup_Vendor_Readiness::refresh( $a->ID );
				}
			)
		);
		?>
		<article class="lnkup-organizer-event-card lnkup-organizer-event-card--v3 lnkup-organizer-event-card--v4">
			<div class="lnkup-organizer-event-card__media">
				<?php if ( $image_url ) : ?>
					<img src="<?php echo esc_url( $image_url ); ?>" alt="" class="lnkup-organizer-event-card__image" loading="lazy" />
				<?php else : ?>
					<div class="lnkup-organizer-event-card__placeholder" aria-hidden="true"><span><?php echo esc_html( $initial ?: 'E' ); ?></span></div>
				<?php endif; ?>
				<?php if ( $type_label ) : ?>
					<span class="lnkup-organizer-event-card__type-badge"><?php echo esc_html( $type_label ); ?></span>
				<?php endif; ?>
				<span class="lnkup-organizer-event-card__status lnkup-organizer-event-card__status--<?php echo esc_attr( $lifecycle_class ); ?>"><?php echo esc_html( $lifecycle ); ?></span>
			</div>
			<div class="lnkup-organizer-event-card__body">
				<div class="lnkup-organizer-event-card__head">
					<h3 class="lnkup-organizer-event-card__title"><?php echo esc_html( $event->post_title ); ?></h3>
					<span class="lnkup-status-pill lnkup-status-pill--muted"><?php echo esc_html( $status_label ); ?></span>
				</div>
				<p class="lnkup-organizer-event-card__meta-strip lnkup-muted">
					<span><?php echo esc_html( $date_label ); ?></span>
					<?php if ( $location ) : ?>
						<span aria-hidden="true">·</span>
						<span><?php echo esc_html( $location ); ?></span>
					<?php endif; ?>
					<?php if ( $type_label ) : ?>
						<span aria-hidden="true">·</span>
						<span><?php echo esc_html( $type_label ); ?></span>
					<?php endif; ?>
				</p>
				<div class="lnkup-organizer-event-card__stats">
					<div class="lnkup-organizer-event-card__stat">
						<span class="lnkup-organizer-event-card__stat-label"><?php echo esc_html( lnkup_copy( 'vendor_revenue' ) ); ?></span>
						<strong class="lnkup-organizer-event-card__stat-value"><?php echo esc_html( $revenue > 0 ? lnkup_currency( $revenue ) : '—' ); ?></strong>
					</div>
					<div class="lnkup-organizer-event-card__stat">
						<span class="lnkup-organizer-event-card__stat-label"><?php esc_html_e( 'Vendor requests', 'lnkup-marketplace' ); ?></span>
						<strong class="lnkup-organizer-event-card__stat-value"><?php echo esc_html( (string) $new_apps ); ?></strong>
					</div>
					<?php if ( $readiness_issues > 0 ) : ?>
						<div class="lnkup-organizer-event-card__stat lnkup-organizer-event-card__stat--warning">
							<span class="lnkup-organizer-event-card__stat-label"><?php esc_html_e( 'Document issues', 'lnkup-marketplace' ); ?></span>
							<strong class="lnkup-organizer-event-card__stat-value"><?php echo esc_html( (string) $readiness_issues ); ?></strong>
						</div>
					<?php else : ?>
						<div class="lnkup-organizer-event-card__stat">
							<span class="lnkup-organizer-event-card__stat-label"><?php esc_html_e( 'Confirmed', 'lnkup-marketplace' ); ?></span>
							<strong class="lnkup-organizer-event-card__stat-value"><?php echo esc_html( (string) $vendor_count ); ?></strong>
						</div>
					<?php endif; ?>
				</div>
				<?php if ( $spots['total'] > 0 ) : ?>
					<div class="lnkup-organizer-event-card__progress">
						<div class="lnkup-organizer-event-card__progress-header">
							<span><?php esc_html_e( 'Vendor capacity', 'lnkup-marketplace' ); ?></span>
							<span><?php printf( esc_html__( '%1$d/%2$d · %3$s%%', 'lnkup-marketplace' ), (int) $spots['filled'], (int) $spots['total'], (string) $spots['percent'] ); ?></span>
						</div>
						<div class="lnkup-progress" role="progressbar" aria-valuenow="<?php echo esc_attr( (string) $spots['percent'] ); ?>" aria-valuemin="0" aria-valuemax="100">
							<div class="lnkup-progress__fill" style="width:<?php echo esc_attr( (string) $spots['percent'] ); ?>%"></div>
						</div>
					</div>
				<?php endif; ?>
				<div class="lnkup-organizer-event-card__primary-actions">
					<a href="<?php echo esc_url( $roster_url ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary"><?php esc_html_e( 'Manage', 'lnkup-marketplace' ); ?></a>
					<a href="<?php echo esc_url( $apps_url ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline"><?php esc_html_e( 'Vendors', 'lnkup-marketplace' ); ?></a>
					<a href="<?php echo esc_url( $fin_url ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" data-expand="financial"><?php esc_html_e( 'Financials', 'lnkup-marketplace' ); ?></a>
					<a href="<?php echo esc_url( $ops_url ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost"><?php esc_html_e( 'Operations', 'lnkup-marketplace' ); ?></a>
				</div>
			</div>
		</article>
		<?php
	}

	/**
	 * Organizer events shortcode.
	 *
	 * @param int $limit Optional max event cards (0 = all, skips create-opportunity block when set).
	 */
	public static function render_organizer_events( $limit = 0 ) {
		if ( is_array( $limit ) ) {
			$limit = 0;
		}
		$limit = absint( $limit );
		$user_id = get_current_user_id();
		$events  = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);
		$dash_url = lnkup_page_url_helper( 'organizer-dashboard' );
		$apps     = lnkup_get_applications_for_user( $user_id, 'organizer' );
		$payments = lnkup_get_payments_for_user( $user_id, 'organizer' );

		ob_start();
		if ( $events ) {
			$display_events = $limit > 0 ? array_slice( $events, 0, $limit ) : $events;
			$grid_class     = 'lnkup-organizer-event-grid';
			if ( 1 === count( $display_events ) ) {
				$grid_class .= ' lnkup-organizer-event-grid--single';
			}
			echo '<div class="' . esc_attr( $grid_class ) . '">';
			foreach ( $display_events as $event ) {
				self::render_organizer_event_card( $event, $apps, $payments, $dash_url );
			}
			echo '</div>';
		} else {
			echo '<div class="lnkup-empty-state lnkup-empty-state--compact">';
			echo '<p class="lnkup-empty-state__title">' . esc_html__( 'No events yet', 'lnkup-marketplace' ) . '</p>';
			echo '<p class="lnkup-empty-state__desc">' . esc_html__( 'Create your first event to start recruiting vendors.', 'lnkup-marketplace' ) . '</p>';
			echo '<div class="lnkup-empty-state__actions"><a href="' . esc_url( $dash_url . '#create' ) . '" class="lnkup-btn lnkup-btn--primary">' . esc_html__( 'Create event', 'lnkup-marketplace' ) . '</a></div>';
			echo '</div>';
		}

		if ( $limit > 0 ) {
			return ob_get_clean();
		}

		return ob_get_clean();
	}

	/**
	 * Shared settings for organizer create forms.
	 */
	private static function organizer_create_form_context() {
		$settings = lnkup_get_settings();
		return array(
			'settings'    => $settings,
			'doc_types'   => class_exists( 'LNKup_Documents' ) ? LNKup_Documents::document_types() : array(),
			'categories'  => get_terms( array( 'taxonomy' => 'lnkup_vendor_category', 'hide_empty' => false ) ),
			'default_fee' => $settings['default_fee'] ?? 5.99,
			'commission'  => $settings['organizer_commission_percent'] ?? 5,
			'dash_url'    => lnkup_page_url_helper( 'organizer-dashboard' ),
		);
	}

	/**
	 * Import-only panel (ticketing URL preview).
	 */
	private static function render_import_event_panel() {
		$ctx = self::organizer_create_form_context();
		ob_start();
		?>
		<div class="lnkup-organizer-import-panel" id="lnkup-import-panel">
			<div class="lnkup-import-sources" aria-hidden="true">
				<span class="lnkup-badge lnkup-badge--secondary">Eventbrite</span>
				<span class="lnkup-badge lnkup-badge--secondary">Posh</span>
				<span class="lnkup-badge lnkup-badge--secondary">Universe</span>
			</div>
			<div class="lnkup-form-row lnkup-import-url-row">
				<label for="ticketing_url_import"><?php esc_html_e( 'Event URL', 'lnkup-marketplace' ); ?></label>
				<div class="lnkup-import-url-field">
					<input type="url" id="ticketing_url_import" placeholder="https://eventbrite.com/e/..." />
					<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" id="lnkup-import-preview-btn"><?php esc_html_e( 'Import', 'lnkup-marketplace' ); ?></button>
				</div>
			</div>
			<div id="lnkup-import-loading" class="lnkup-import-loading" hidden>
				<span class="lnkup-spinner" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Fetching event details…', 'lnkup-marketplace' ); ?></span>
			</div>
			<div id="lnkup-import-preview" class="lnkup-import-preview" hidden></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Unified create panel: optional import, new event, or add opportunity to existing event.
	 *
	 * @param array $events Organizer events.
	 */
	private static function render_create_panel( $events ) {
		$has_events = ! empty( $events );
		ob_start();
		?>
		<div class="lnkup-organizer-create-page" id="lnkup-create-panel">
			<details class="lnkup-organizer-import-collapse">
				<summary class="lnkup-organizer-import-collapse__summary"><?php esc_html_e( 'Import from ticketing URL (optional)', 'lnkup-marketplace' ); ?></summary>
				<?php echo self::render_import_event_panel(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</details>

			<?php if ( $has_events ) : ?>
				<div class="lnkup-dash-tabs lnkup-organizer-create-modes" role="tablist" aria-label="<?php esc_attr_e( 'Create mode', 'lnkup-marketplace' ); ?>">
					<button type="button" class="lnkup-dash-tabs__btn is-active" data-create-mode="new"><?php esc_html_e( 'New event', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-dash-tabs__btn" data-create-mode="existing"><?php esc_html_e( 'Add to existing event', 'lnkup-marketplace' ); ?></button>
				</div>
			<?php endif; ?>

			<div id="lnkup-create-mode-new" class="lnkup-organizer-create-mode is-active">
				<?php echo self::render_create_event_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<?php if ( $has_events ) : ?>
				<div id="lnkup-create-mode-existing" class="lnkup-organizer-create-mode" hidden>
					<?php echo self::render_create_opportunity_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo self::render_opportunities_table(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Create event form with optional first opportunity.
	 */
	private static function render_create_event_form() {
		$ctx        = self::organizer_create_form_context();
		$settings   = $ctx['settings'];
		$doc_types  = $ctx['doc_types'];
		$categories = $ctx['categories'];
		$default_fee = $ctx['default_fee'];
		$commission  = $ctx['commission'];
		ob_start();
		?>
		<div class="lnkup-organizer-create-wizard">
			<nav class="lnkup-organizer-wizard-steps" aria-label="<?php esc_attr_e( 'Event setup steps', 'lnkup-marketplace' ); ?>">
				<button type="button" class="is-active" data-wizard-step="lnkup-create-step-1"><?php esc_html_e( '1. Event basics', 'lnkup-marketplace' ); ?></button>
				<button type="button" data-wizard-step="lnkup-create-step-2"><?php esc_html_e( '2. Date & location', 'lnkup-marketplace' ); ?></button>
				<button type="button" data-wizard-step="lnkup-create-step-3"><?php esc_html_e( '3. Vendor opportunity', 'lnkup-marketplace' ); ?></button>
				<button type="button" data-wizard-step="lnkup-create-step-4"><?php esc_html_e( '4. Requirements', 'lnkup-marketplace' ); ?></button>
				<button type="button" data-wizard-step="lnkup-create-step-5"><?php esc_html_e( '5. Payment rules', 'lnkup-marketplace' ); ?></button>
				<button type="button" data-wizard-step="lnkup-create-step-6"><?php esc_html_e( '6. Review', 'lnkup-marketplace' ); ?></button>
			</nav>
			<div class="lnkup-organizer-create-layout">
				<div class="lnkup-organizer-create-main">
					<form class="lnkup-form lnkup-event-form lnkup-organizer-create-form" id="lnkup-create-event-form">
						<?php wp_nonce_field( 'lnkup_event', 'lnkup_nonce' ); ?>
						<input type="hidden" name="action" value="lnkup_create_event" />
						<input type="hidden" name="create_opportunity" id="lnkup_create_opportunity_field" value="1" />
						<input type="hidden" name="ticketing_url" id="lnkup_create_event_ticketing_url" value="" />

						<section class="lnkup-panel lnkup-organizer-create-section" id="lnkup-create-step-1">
							<h3 class="lnkup-panel__title"><?php esc_html_e( 'Event basics', 'lnkup-marketplace' ); ?></h3>
					<div class="lnkup-grid lnkup-grid--2">
						<div class="lnkup-form-row">
							<label for="event_name"><?php esc_html_e( 'Event title', 'lnkup-marketplace' ); ?> *</label>
							<input type="text" id="event_name" name="event_name" required />
						</div>
						<div class="lnkup-form-row" id="lnkup-create-step-2">
							<label for="event_date"><?php esc_html_e( 'Event date', 'lnkup-marketplace' ); ?></label>
							<input type="date" id="event_date" name="event_date" />
						</div>
						<div class="lnkup-form-row">
							<label for="start_time"><?php esc_html_e( 'Start time', 'lnkup-marketplace' ); ?></label>
							<input type="time" id="start_time" name="start_time" />
						</div>
						<div class="lnkup-form-row">
							<label for="end_time"><?php esc_html_e( 'End time', 'lnkup-marketplace' ); ?></label>
							<input type="time" id="end_time" name="end_time" />
						</div>
						<div class="lnkup-form-row">
							<label for="event_city"><?php esc_html_e( 'City', 'lnkup-marketplace' ); ?></label>
							<input type="text" id="event_city" name="city" />
						</div>
						<div class="lnkup-form-row">
							<label for="event_state"><?php esc_html_e( 'State', 'lnkup-marketplace' ); ?></label>
							<input type="text" id="event_state" name="state" maxlength="2" />
						</div>
						<div class="lnkup-form-row">
							<label for="venue_name"><?php esc_html_e( 'Venue', 'lnkup-marketplace' ); ?></label>
							<input type="text" id="venue_name" name="venue_name" />
						</div>
						<div class="lnkup-form-row">
							<label for="expected_attendance"><?php esc_html_e( 'Expected attendance', 'lnkup-marketplace' ); ?></label>
							<input type="number" id="expected_attendance" name="expected_attendance" min="0" />
						</div>
						<div class="lnkup-form-row">
							<label for="event_type_parent"><?php esc_html_e( 'Event category', 'lnkup-marketplace' ); ?></label>
							<select id="event_type_parent" name="event_type_parent" required>
								<option value=""><?php esc_html_e( 'Select category…', 'lnkup-marketplace' ); ?></option>
								<?php foreach ( lnkup_get_event_type_parents() as $parent_type ) : ?>
									<option value="<?php echo esc_attr( (string) $parent_type->term_id ); ?>"><?php echo esc_html( $parent_type->name ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="lnkup-form-row">
							<label for="event_type"><?php esc_html_e( 'Event type', 'lnkup-marketplace' ); ?></label>
							<select id="event_type" name="event_type" disabled required>
								<option value=""><?php esc_html_e( 'Select type…', 'lnkup-marketplace' ); ?></option>
							</select>
						</div>
						<div class="lnkup-form-row">
							<label for="ticketing_platform"><?php esc_html_e( 'Ticketing platform', 'lnkup-marketplace' ); ?></label>
							<select id="ticketing_platform" name="ticketing_platform">
								<option value="Manual"><?php esc_html_e( 'Manual', 'lnkup-marketplace' ); ?></option>
								<option value="Posh">Posh</option>
								<option value="Eventbrite">Eventbrite</option>
								<option value="Universe">Universe</option>
							</select>
						</div>
					</div>
					<div class="lnkup-form-row">
						<label for="venue_address"><?php esc_html_e( 'Venue address', 'lnkup-marketplace' ); ?></label>
						<textarea id="venue_address" name="venue_address" rows="2"></textarea>
					</div>
					<div class="lnkup-form-row">
						<label><input type="checkbox" name="venue_hidden" value="1" checked /> <?php esc_html_e( 'Hide venue address until vendor payment', 'lnkup-marketplace' ); ?></label>
					</div>
					<div class="lnkup-form-row">
						<label for="description"><?php esc_html_e( 'Description', 'lnkup-marketplace' ); ?></label>
						<textarea id="description" name="description" rows="3"></textarea>
					</div>
				</section>

				<div class="lnkup-form-row lnkup-organizer-create-toggle">
					<label><input type="checkbox" id="lnkup_publish_opportunity_toggle" checked /> <?php esc_html_e( 'Also publish first vendor opportunity', 'lnkup-marketplace' ); ?></label>
					<p class="lnkup-muted"><?php esc_html_e( 'Creates a booth listing in Find Events with this event.', 'lnkup-marketplace' ); ?></p>
				</div>

				<div id="lnkup-create-event-opportunity-fields">
				<section class="lnkup-panel lnkup-organizer-create-section" id="lnkup-create-step-3">
					<h3 class="lnkup-panel__title"><?php esc_html_e( 'Vendor opportunity', 'lnkup-marketplace' ); ?></h3>
					<p class="lnkup-muted"><?php esc_html_e( 'Your first booth listing is created with the event so vendors can apply in Find Events.', 'lnkup-marketplace' ); ?></p>
					<div class="lnkup-grid lnkup-grid--2">
						<div class="lnkup-form-row">
							<label for="vendor_category"><?php esc_html_e( 'Vendor category', 'lnkup-marketplace' ); ?></label>
							<select id="vendor_category" name="vendor_category">
								<option value=""><?php esc_html_e( 'Any category', 'lnkup-marketplace' ); ?></option>
								<?php if ( $categories && ! is_wp_error( $categories ) ) : ?>
									<?php foreach ( $categories as $cat ) : ?>
										<option value="<?php echo esc_attr( $cat->name ); ?>"><?php echo esc_html( $cat->name ); ?></option>
									<?php endforeach; ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="lnkup-form-row">
							<label for="event_vendor_fee"><?php esc_html_e( 'Booth / vendor fee ($)', 'lnkup-marketplace' ); ?></label>
							<input type="number" id="event_vendor_fee" name="vendor_fee" min="0" step="0.01" value="250" />
						</div>
						<div class="lnkup-form-row">
							<label for="event_spots_total"><?php esc_html_e( 'Spots available', 'lnkup-marketplace' ); ?></label>
							<input type="number" id="event_spots_total" name="spots_total" min="1" value="10" />
						</div>
						<div class="lnkup-form-row">
							<label for="application_deadline"><?php esc_html_e( 'Application deadline', 'lnkup-marketplace' ); ?></label>
							<input type="date" id="application_deadline" name="application_deadline" />
						</div>
					</div>
					<?php if ( $doc_types ) : ?>
						<div class="lnkup-form-row" id="lnkup-create-step-4">
							<span class="lnkup-form-label"><?php esc_html_e( 'Required documents', 'lnkup-marketplace' ); ?></span>
							<div class="lnkup-checkbox-grid">
								<?php foreach ( $doc_types as $slug => $label ) : ?>
									<label><input type="checkbox" name="required_documents[]" value="<?php echo esc_attr( $slug ); ?>" /> <?php echo esc_html( $label ); ?></label>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
					<div class="lnkup-form-row lnkup-checkbox-inline">
						<label><input type="checkbox" name="indoor" value="1" /> <?php esc_html_e( 'Indoor', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" name="outdoor" value="1" checked /> <?php esc_html_e( 'Outdoor', 'lnkup-marketplace' ); ?></label>
					</div>
				</section>
				</div>

				<section class="lnkup-panel lnkup-organizer-create-section" id="lnkup-create-step-5">
					<h3 class="lnkup-panel__title"><?php esc_html_e( 'Payment rules', 'lnkup-marketplace' ); ?></h3>
					<ul class="lnkup-muted lnkup-organizer-create-rules">
						<li><?php printf( esc_html__( 'Vendor marketplace fee: $%s per application (default)', 'lnkup-marketplace' ), esc_html( number_format( (float) $default_fee, 2 ) ) ); ?></li>
						<li><?php printf( esc_html__( 'Organizer platform fee: %s%% of booth revenue (default)', 'lnkup-marketplace' ), esc_html( (string) $commission ) ); ?></li>
					</ul>
					<div class="lnkup-form-row lnkup-checkbox-inline">
						<label><input type="checkbox" name="deposit_required" value="1" /> <?php esc_html_e( 'Require deposit at checkout (optional)', 'lnkup-marketplace' ); ?></label>
						<label><input type="checkbox" name="packet_lock" value="1" <?php checked( ! empty( $settings['default_packet_lock'] ) ); ?> /> <?php esc_html_e( 'Lock event packet until payment', 'lnkup-marketplace' ); ?></label>
					</div>
				</section>
						<div class="lnkup-organizer-wizard-footer">
							<button type="submit" form="lnkup-create-event-form" class="lnkup-btn lnkup-btn--primary" id="lnkup-create-event-submit-footer"><?php esc_html_e( 'Publish event', 'lnkup-marketplace' ); ?></button>
						</div>
					</form>
				</div>
				<aside class="lnkup-organizer-create-sidebar" id="lnkup-create-step-6">
					<div class="lnkup-panel lnkup-organizer-create-section lnkup-organizer-create-section--publish">
						<h3 class="lnkup-panel__title"><?php esc_html_e( 'Publish', 'lnkup-marketplace' ); ?></h3>
						<p class="lnkup-muted"><?php esc_html_e( 'Review before going live to vendors.', 'lnkup-marketplace' ); ?></p>
						<dl class="lnkup-organizer-publish-summary">
							<div class="lnkup-organizer-publish-summary__row">
								<dt><?php esc_html_e( 'Category', 'lnkup-marketplace' ); ?></dt>
								<dd id="lnkup-publish-category-count"><?php esc_html_e( 'Any', 'lnkup-marketplace' ); ?></dd>
							</div>
							<div class="lnkup-organizer-publish-summary__row">
								<dt><?php esc_html_e( 'Spots', 'lnkup-marketplace' ); ?></dt>
								<dd id="lnkup-publish-spots-count">10</dd>
							</div>
							<div class="lnkup-organizer-publish-summary__row">
								<dt><?php esc_html_e( 'Booth fee', 'lnkup-marketplace' ); ?></dt>
								<dd id="lnkup-publish-fee-summary">$250.00</dd>
							</div>
							<div class="lnkup-organizer-publish-summary__row">
								<dt><?php esc_html_e( 'Required docs', 'lnkup-marketplace' ); ?></dt>
								<dd id="lnkup-publish-docs-count">0</dd>
							</div>
							<div class="lnkup-organizer-publish-summary__row">
								<dt><?php esc_html_e( 'Platform fee', 'lnkup-marketplace' ); ?></dt>
								<dd><?php printf( esc_html__( '%s%% per booking', 'lnkup-marketplace' ), esc_html( (string) $commission ) ); ?></dd>
							</div>
						</dl>
						<div id="lnkup-create-event-success" class="lnkup-create-event-success" hidden></div>
						<button type="submit" form="lnkup-create-event-form" class="lnkup-btn lnkup-btn--primary lnkup-btn--block" id="lnkup-create-event-submit"><?php esc_html_e( 'Publish event', 'lnkup-marketplace' ); ?></button>
					</div>
				</aside>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Opportunity form for an existing event.
	 */
	private static function render_create_opportunity_form() {
		$user_id = get_current_user_id();
		$events  = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);
		if ( ! $events ) {
			return '';
		}
		ob_start();
		?>
		<div class="lnkup-panel lnkup-organizer-section">
			<h3 class="lnkup-panel__title"><?php esc_html_e( 'Vendor opportunity', 'lnkup-marketplace' ); ?></h3>
			<p class="lnkup-muted"><?php esc_html_e( 'Add a booth listing so vendors can apply in Find Events.', 'lnkup-marketplace' ); ?></p>
			<form class="lnkup-form lnkup-opportunity-form" id="lnkup-create-opportunity-form">
				<?php wp_nonce_field( 'lnkup_opportunity', 'lnkup_nonce' ); ?>
				<input type="hidden" name="action" value="lnkup_create_opportunity" />
				<div class="lnkup-form-row">
					<label for="opp_event_id"><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></label>
					<select id="opp_event_id" name="event_id" required>
						<?php foreach ( $events as $event ) : ?>
							<option value="<?php echo esc_attr( (string) $event->ID ); ?>"><?php echo esc_html( $event->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="lnkup-grid lnkup-grid--2">
					<div class="lnkup-form-row">
						<label for="opp_spots_total"><?php esc_html_e( 'Number of spots', 'lnkup-marketplace' ); ?></label>
						<input type="number" id="opp_spots_total" name="spots_total" min="1" value="10" required />
					</div>
					<div class="lnkup-form-row">
						<label for="opp_vendor_fee"><?php esc_html_e( 'Vendor fee ($)', 'lnkup-marketplace' ); ?></label>
						<input type="number" id="opp_vendor_fee" name="vendor_fee" min="0" step="0.01" value="250" required />
					</div>
					<div class="lnkup-form-row">
						<label for="opp_deadline"><?php esc_html_e( 'Application deadline', 'lnkup-marketplace' ); ?></label>
						<input type="date" id="opp_deadline" name="deadline" />
					</div>
				</div>
				<div class="lnkup-form-row">
					<label for="opp_notes"><?php esc_html_e( 'Organizer notes', 'lnkup-marketplace' ); ?></label>
					<textarea id="opp_notes" name="notes" rows="3"></textarea>
				</div>
				<div id="lnkup-create-opportunity-success" class="lnkup-create-event-success" hidden></div>
				<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Create opportunity', 'lnkup-marketplace' ); ?></button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Table of organizer opportunities.
	 */
	private static function render_opportunities_table() {
		$user_id = get_current_user_id();
		$opps    = get_posts(
			array(
				'post_type'      => 'lnkup_opportunity',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
			)
		);
		if ( ! $opps ) {
			return '';
		}
		ob_start();
		echo '<div class="lnkup-panel lnkup-organizer-opportunities-table">';
		echo '<h3 class="lnkup-panel__title">' . esc_html__( 'Your opportunities', 'lnkup-marketplace' ) . '</h3>';
		echo '<table class="lnkup-table"><thead><tr><th>' . esc_html__( 'Opportunity', 'lnkup-marketplace' ) . '</th><th>' . esc_html__( 'Quality', 'lnkup-marketplace' ) . '</th><th>' . esc_html__( 'Spots', 'lnkup-marketplace' ) . '</th><th>' . esc_html__( 'Deadline', 'lnkup-marketplace' ) . '</th></tr></thead><tbody>';
		foreach ( $opps as $opp ) {
			$quality_html = '—';
			if ( class_exists( 'LNKup_Opportunity_Score' ) ) {
				$quality      = LNKup_Opportunity_Score::compute( $opp->ID );
				$quality_html = '<span class="lnkup-intel-score-inline" title="' . esc_attr( $quality['label'] ?? '' ) . '">' . esc_html( (string) ( $quality['quality_score'] ?? 0 ) ) . '</span>';
			}
			echo '<tr>';
			echo '<td>' . esc_html( $opp->post_title ) . '</td>';
			echo '<td>' . $quality_html . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<td>' . esc_html( (string) get_post_meta( $opp->ID, '_lnkup_spots_total', true ) ) . '</td>';
			echo '<td>' . esc_html( get_post_meta( $opp->ID, '_lnkup_application_deadline', true ) ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table></div>';
		return ob_get_clean();
	}

	/**
	 * Create opportunity for an existing event (legacy standalone panel).
	 */
	private static function render_create_opportunity_panel() {
		$user_id  = get_current_user_id();
		$events   = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);
		$dash_url = lnkup_page_url_helper( 'organizer-dashboard' );
		ob_start();
		if ( ! $events ) {
			echo '<div class="lnkup-empty-state lnkup-empty-state--compact">';
			echo '<p class="lnkup-empty-state__title">' . esc_html__( 'Create an event first', 'lnkup-marketplace' ) . '</p>';
			echo '<p class="lnkup-empty-state__desc">' . esc_html__( 'You need at least one event before adding a vendor opportunity.', 'lnkup-marketplace' ) . '</p>';
			echo '<div class="lnkup-empty-state__actions"><a href="' . esc_url( $dash_url . '#create' ) . '" class="lnkup-btn lnkup-btn--primary">' . esc_html__( 'Create event', 'lnkup-marketplace' ) . '</a></div>';
			echo '</div>';
			return ob_get_clean();
		}
		echo self::render_create_opportunity_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::render_opportunities_table(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return ob_get_clean();
	}

	/**
	 * Vendor CRM profile view.
	 *
	 * @param int $profile_id Profile post ID.
	 */
	public static function render_vendor_crm_profile( $profile_id ) {
		$profile = LNKup_Vendor_CRM_Profile::get( $profile_id, get_current_user_id() );
		if ( ! $profile ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Vendor not found.', 'lnkup-marketplace' ) . '</p>';
		}
		$back = lnkup_page_url_helper( 'organizer-dashboard' ) . '#vendors';
		$timeline = LNKup_Vendor_Timeline::get_for_vendor( get_current_user_id(), $profile['vendor_user_id'] );
		ob_start();
		?>
		<div class="lnkup-mp lnkup-crm lnkup-crm-profile" id="lnkup-crm-profile" data-profile-id="<?php echo esc_attr( (string) $profile_id ); ?>" data-rest="<?php echo esc_url( rest_url( 'lnkup/v1/crm' ) ); ?>">
			<p><a href="<?php echo esc_url( $back ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm">&larr; <?php esc_html_e( 'Back to directory', 'lnkup-marketplace' ); ?></a></p>
			<div class="lnkup-crm-profile__header">
				<?php if ( $profile['logo'] ) : ?><img src="<?php echo esc_url( $profile['logo'] ); ?>" alt="" class="lnkup-crm-profile__logo" /><?php endif; ?>
				<div>
					<h1 class="lnkup-heading lnkup-heading--page"><?php echo esc_html( $profile['business_name'] ); ?></h1>
					<p class="lnkup-muted"><?php echo esc_html( $profile['owner_name'] ); ?> · <?php echo esc_html( implode( ', ', $profile['category'] ) ); ?></p>
					<div class="lnkup-crm-profile__badges">
						<?php echo LNKup_Reputation_Render::score_badge( $profile['vendor_score'], $profile['reputation_label'] ?? '', ! empty( $profile['reputation']['is_new'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php if ( ! empty( $profile['avg_rating'] ) ) : ?>
							<?php echo LNKup_Reputation_Render::star_rating( $profile['avg_rating'], $profile['review_count'] ?? 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endif; ?>
						<?php echo LNKup_Reputation_Render::badge_grid( $profile['badges'] ?? array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php foreach ( $profile['tags'] as $tag ) : ?><span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( $tag['label'] ); ?></span><?php endforeach; ?>
						<?php foreach ( $profile['flags'] as $flag ) : ?><span class="lnkup-badge lnkup-badge--destructive"><?php echo esc_html( $flag['label'] ); ?></span><?php endforeach; ?>
					</div>
				</div>
				<div class="lnkup-crm-profile__actions">
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-crm-fav" data-profile-id="<?php echo esc_attr( (string) $profile_id ); ?>"><?php echo $profile['is_favorite'] ? '★' : '☆'; ?> <?php esc_html_e( 'Favorite', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-crm-pref" data-profile-id="<?php echo esc_attr( (string) $profile_id ); ?>"><?php esc_html_e( 'Preferred', 'lnkup-marketplace' ); ?></button>
					<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm lnkup-crm-invite" data-vendor-id="<?php echo esc_attr( (string) $profile['vendor_user_id'] ); ?>"><?php esc_html_e( 'Invite', 'lnkup-marketplace' ); ?></button>
				</div>
			</div>
			<?php if ( class_exists( 'LNKup_Vendor_Reliability_Intel' ) ) : ?>
				<?php $reliability = LNKup_Vendor_Reliability_Intel::for_profile( $profile_id, get_current_user_id() ); ?>
				<?php if ( $reliability && ! empty( $reliability['flags'] ) ) : ?>
					<section class="lnkup-panel lnkup-intel-profile-flags">
						<h2 class="lnkup-panel__title"><?php esc_html_e( 'Reliability Intelligence', 'lnkup-marketplace' ); ?></h2>
						<div class="lnkup-intel-flags">
							<?php foreach ( $reliability['flags'] as $flag ) : ?>
								<span class="lnkup-intel-flag lnkup-intel-flag--<?php echo esc_attr( $flag['type'] ); ?>"><?php echo esc_html( $flag['label'] ); ?> — <?php echo esc_html( $flag['message'] ); ?></span>
							<?php endforeach; ?>
						</div>
						<p class="lnkup-muted"><?php esc_html_e( 'Payment likelihood:', 'lnkup-marketplace' ); ?> <?php echo esc_html( $reliability['payment_likelihood'] ); ?> · <?php esc_html_e( 'No-show risk:', 'lnkup-marketplace' ); ?> <?php echo esc_html( $reliability['no_show_likelihood'] ); ?></p>
					</section>
				<?php endif; ?>
			<?php endif; ?>
			<div class="lnkup-crm-profile__grid">
				<section class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Contact & Setup', 'lnkup-marketplace' ); ?></h2>
					<ul class="lnkup-crm-facts">
						<li><?php echo esc_html( $profile['email'] ); ?></li>
						<li><?php echo esc_html( $profile['phone'] ); ?></li>
						<li><?php echo esc_html( $profile['instagram'] ); ?></li>
						<li><a href="<?php echo esc_url( $profile['website'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $profile['website'] ); ?></a></li>
						<li><?php esc_html_e( 'Setup:', 'lnkup-marketplace' ); ?> <?php echo esc_html( $profile['setup_type'] ); ?></li>
						<li><?php esc_html_e( 'Power:', 'lnkup-marketplace' ); ?> <?php echo esc_html( $profile['power_needs'] ); ?></li>
						<li><?php esc_html_e( 'Tent:', 'lnkup-marketplace' ); ?> <?php echo esc_html( $profile['tent_size'] ); ?></li>
					</ul>
					<p><?php echo esc_html( $profile['products_services'] ); ?></p>
				</section>
				<section class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Timeline', 'lnkup-marketplace' ); ?></h2>
					<ul class="lnkup-crm-timeline">
						<?php foreach ( $timeline as $item ) : ?>
							<li><strong><?php echo esc_html( $item['label'] ); ?></strong> <?php if ( $item['event_title'] ) : ?>— <?php echo esc_html( $item['event_title'] ); ?><?php endif; ?><br><span class="lnkup-muted"><?php echo esc_html( $item['created_at'] ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				</section>
				<section class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Reputation', 'lnkup-marketplace' ); ?></h2>
					<?php echo LNKup_Reputation_Render::reliability_meter( $profile['reliability'] ?? array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo LNKup_Reputation_Render::risk_indicator( $profile['reliability'] ?? array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<h3><?php esc_html_e( 'Completed events', 'lnkup-marketplace' ); ?></h3>
					<?php echo LNKup_Reputation_Render::completed_events_timeline( LNKup_Completed_Events::get_for_vendor( $profile_id, 'crm' ), 6 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<h3><?php esc_html_e( 'Public reviews', 'lnkup-marketplace' ); ?></h3>
					<?php foreach ( LNKup_Vendor_Reviews::get_for_vendor( $profile_id, 5 ) as $review ) : ?>
						<?php echo LNKup_Reputation_Render::review_card( $review ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endforeach; ?>
				</section>
				<section class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Private Notes', 'lnkup-marketplace' ); ?></h2>
					<form id="lnkup-crm-note-form" class="lnkup-form">
						<textarea id="lnkup-crm-note-input" rows="3" placeholder="<?php esc_attr_e( 'Add a private note…', 'lnkup-marketplace' ); ?>"></textarea>
						<button type="submit" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Save Note', 'lnkup-marketplace' ); ?></button>
					</form>
					<ul id="lnkup-crm-notes-list" class="lnkup-crm-notes">
						<?php foreach ( LNKup_Vendor_Notes::get_for_vendor( get_current_user_id(), $profile['vendor_user_id'] ) as $note ) : ?>
							<li><?php echo esc_html( $note['content'] ); ?> <span class="lnkup-muted"><?php echo esc_html( $note['created_at'] ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				</section>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Event roster view.
	 *
	 * @param int $event_id Event ID.
	 */
	public static function render_event_roster_view( $event_id ) {
		$roster = LNKup_Event_Roster::get( $event_id, get_current_user_id() );
		if ( is_wp_error( $roster ) ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html( $roster->get_error_message() ) . '</p>';
		}
		$event = get_post( $event_id );
		$back = lnkup_page_url_helper( 'organizer-dashboard' ) . '#events';
		ob_start();
		?>
		<div class="lnkup-mp lnkup-crm" id="lnkup-event-roster" data-event-id="<?php echo esc_attr( (string) $event_id ); ?>" data-rest="<?php echo esc_url( rest_url( 'lnkup/v1/crm' ) ); ?>">
			<p><a href="<?php echo esc_url( $back ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm">&larr; <?php esc_html_e( 'Back to events', 'lnkup-marketplace' ); ?></a></p>
			<h1 class="lnkup-heading lnkup-heading--page"><?php echo esc_html( $event ? $event->post_title : '' ); ?> — <?php esc_html_e( 'Vendor Roster', 'lnkup-marketplace' ); ?></h1>
			<div class="lnkup-roster-bulk">
				<label><input type="checkbox" id="lnkup-roster-select-all" /> <?php esc_html_e( 'Select all visible', 'lnkup-marketplace' ); ?></label>
				<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" data-roster-bulk="approve"><?php esc_html_e( 'Bulk Approve', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm" data-roster-bulk="waitlist"><?php esc_html_e( 'Waitlist', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm" data-roster-bulk="check_in"><?php esc_html_e( 'Check In', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost" data-roster-bulk="no_show"><?php esc_html_e( 'No-show', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm" data-roster-bulk="mark_complete"><?php esc_html_e( 'Mark complete', 'lnkup-marketplace' ); ?></button>
			</div>
			<div id="lnkup-roster-content"><?php echo $roster['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Event operations command center.
	 *
	 * @param int $event_id Event ID.
	 */
	public static function render_event_operations_view( $event_id ) {
		if ( ! LNKup_Capabilities::organizer_owns_event( $event_id ) && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'You do not have permission to view operations for this event.', 'lnkup-marketplace' ) . '</p>';
		}
		$snap = LNKup_Event_Operations::snapshot( $event_id, get_current_user_id() );
		if ( ! $snap ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Event not found.', 'lnkup-marketplace' ) . '</p>';
		}
		$event = get_post( $event_id );
		$kanban = LNKup_Event_Operations::vendors_for_kanban( $event_id );
		$booths = LNKup_Booths::get_for_event( $event_id );
		$parking = LNKup_Parking::get_for_event( $event_id );
		$loadin_windows = LNKup_Loadin_Schedule::get_windows( $event_id );
		$readiness_summary = $snap['readiness_summary'] ?? LNKup_Vendor_Readiness::event_readiness_summary( $event_id );
		$back = lnkup_page_url_helper( 'organizer-dashboard' ) . '#events';
		$scan_url = add_query_arg( array( 'event' => $event_id, 'scan' => 1 ), lnkup_page_url_helper( 'organizer-dashboard' ) );
		ob_start();
		?>
		<div class="lnkup-mp lnkup-ops" id="lnkup-event-ops" data-event-id="<?php echo esc_attr( (string) $event_id ); ?>">
			<p><a href="<?php echo esc_url( $back ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm">&larr; <?php esc_html_e( 'Back to events', 'lnkup-marketplace' ); ?></a></p>
			<header class="lnkup-ops-header">
				<h1 class="lnkup-heading lnkup-heading--page"><?php echo esc_html( $event ? $event->post_title : '' ); ?> — <?php esc_html_e( 'Operations', 'lnkup-marketplace' ); ?></h1>
				<div class="lnkup-ops-header__actions">
					<a href="<?php echo esc_url( $scan_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'QR Scan', 'lnkup-marketplace' ); ?></a>
				</div>
			</header>
			<div id="lnkup-ops-kpis" class="lnkup-ops-kpis-wrap"><?php echo LNKup_Operations_Render::kpi_row( $snap['kpis'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div id="lnkup-ops-lifecycle"><?php echo LNKup_Operations_Render::lifecycle_bar( $snap['lifecycle'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<nav class="lnkup-ops-section-nav" role="tablist" aria-label="<?php esc_attr_e( 'Operations sections', 'lnkup-marketplace' ); ?>">
				<button type="button" class="lnkup-ops-section is-active" data-section="command"><?php esc_html_e( 'Command', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-section" data-section="logistics"><?php esc_html_e( 'Logistics', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-section" data-section="maps"><?php esc_html_e( 'Maps', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-section" data-section="field"><?php esc_html_e( 'Field', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-section" data-section="intel"><?php esc_html_e( 'Intel', 'lnkup-marketplace' ); ?></button>
			</nav>
			<label class="lnkup-ops-section-select-wrap">
				<span class="screen-reader-text"><?php esc_html_e( 'Select operations section', 'lnkup-marketplace' ); ?></span>
				<select class="lnkup-ops-section-select" id="lnkup-ops-section-select">
					<option value="command"><?php esc_html_e( 'Command', 'lnkup-marketplace' ); ?></option>
					<option value="logistics"><?php esc_html_e( 'Logistics', 'lnkup-marketplace' ); ?></option>
					<option value="maps"><?php esc_html_e( 'Maps', 'lnkup-marketplace' ); ?></option>
					<option value="field"><?php esc_html_e( 'Field', 'lnkup-marketplace' ); ?></option>
					<option value="intel"><?php esc_html_e( 'Intel', 'lnkup-marketplace' ); ?></option>
				</select>
			</label>
			<div class="lnkup-ops-tabs-wrap">
			<nav class="lnkup-ops-tabs" role="tablist">
				<button type="button" class="lnkup-ops-tab is-active" data-section="command" data-ops-tab="overview" role="tab" aria-selected="true" aria-controls="lnkup-ops-overview-panel"><?php esc_html_e( 'Overview', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="command" data-ops-tab="readiness" role="tab" aria-selected="false" aria-controls="lnkup-ops-readiness-panel"><?php esc_html_e( 'Readiness', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="command" data-ops-tab="kanban" role="tab" aria-selected="false" aria-controls="lnkup-ops-kanban-wrap"><?php esc_html_e( 'Roster / Kanban', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="logistics" data-ops-tab="booths" role="tab" aria-selected="false" aria-controls="lnkup-ops-booths-panel"><?php esc_html_e( 'Booths', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="logistics" data-ops-tab="parking" role="tab" aria-selected="false" aria-controls="lnkup-ops-parking-panel"><?php esc_html_e( 'Parking', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="logistics" data-ops-tab="loadin" role="tab" aria-selected="false" aria-controls="lnkup-ops-loadin-panel"><?php esc_html_e( 'Load-In', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="maps" data-ops-tab="map" role="tab" aria-selected="false" aria-controls="lnkup-ops-map-panel"><?php esc_html_e( 'Venue Map', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="maps" data-ops-tab="map-builder" role="tab" aria-selected="false" aria-controls="lnkup-ops-map-builder-panel"><?php esc_html_e( 'Map Builder', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="maps" data-ops-tab="live-map" role="tab" aria-selected="false" aria-controls="lnkup-ops-live-map-panel"><?php esc_html_e( 'Live Map', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="field" data-ops-tab="support" role="tab" aria-selected="false" aria-controls="lnkup-ops-support-panel"><?php esc_html_e( 'Support', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="field" data-ops-tab="incidents" role="tab" aria-selected="false" aria-controls="lnkup-ops-incidents-panel"><?php esc_html_e( 'Incidents', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="field" data-ops-tab="comms" role="tab" aria-selected="false" aria-controls="lnkup-ops-comms-panel"><?php esc_html_e( 'Comms', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="intel" data-ops-tab="analytics" role="tab" aria-selected="false" aria-controls="lnkup-ops-analytics-panel"><?php esc_html_e( 'Analytics', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="intel" data-ops-tab="financial" role="tab" aria-selected="false" aria-controls="lnkup-ops-financial-panel"><?php esc_html_e( 'Financial', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-ops-tab" data-section="intel" data-ops-tab="insights" role="tab" aria-selected="false" aria-controls="lnkup-ops-insights-panel"><?php esc_html_e( 'Insights', 'lnkup-marketplace' ); ?></button>
			</nav>
			</div>
			<div class="lnkup-ops-tab-panels">
				<div class="lnkup-ops-tab-panel is-active" data-ops-panel="overview" id="lnkup-ops-overview-panel" role="tabpanel">
					<?php echo LNKup_Operations_Render::readiness_overview_card( $readiness_summary, $event_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<div class="lnkup-ops-panel-shell">
						<?php
						echo LNKup_Operations_Render::panel_header(
							__( 'Logistics Snapshot', 'lnkup-marketplace' ),
							__( 'Live view of current allocations and windows.', 'lnkup-marketplace' ),
							''
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo LNKup_Operations_Render::panel_stats_strip(
							array(
								array( 'label' => __( 'Booths', 'lnkup-marketplace' ), 'value' => count( (array) $booths ) ),
								array( 'label' => __( 'Parking spots', 'lnkup-marketplace' ), 'value' => count( (array) $parking ) ),
								array( 'label' => __( 'Load-in windows', 'lnkup-marketplace' ), 'value' => count( (array) $loadin_windows ) ),
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</div>
					<div class="lnkup-ops-overview-actions">
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline lnkup-ops-goto-section" data-ops-section="logistics"><?php esc_html_e( 'Go to Logistics', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost lnkup-ops-goto-section" data-ops-section="field"><?php esc_html_e( 'Go to Field', 'lnkup-marketplace' ); ?></button>
					</div>
					<div class="lnkup-ops-overview-grid">
						<section class="lnkup-ops-panel">
							<h2><?php esc_html_e( 'Compliance Alerts', 'lnkup-marketplace' ); ?></h2>
							<div id="lnkup-ops-compliance"><?php echo LNKup_Operations_Render::compliance_alerts( $snap['compliance'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						</section>
						<section class="lnkup-ops-panel">
							<h2><?php esc_html_e( 'Live Feed', 'lnkup-marketplace' ); ?></h2>
							<div id="lnkup-ops-feed"><?php echo LNKup_Operations_Render::feed_list( $snap['feed'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						</section>
					</div>
					<p class="lnkup-muted"><?php echo esc_html( $snap['weather'] ); ?></p>
					<?php if ( ! empty( $snap['emergency'] ) ) : ?>
						<h3><?php esc_html_e( 'Emergency Contacts', 'lnkup-marketplace' ); ?></h3>
						<ul><?php foreach ( $snap['emergency'] as $c ) : ?><li><?php echo esc_html( ( $c['name'] ?? '' ) . ' — ' . ( $c['phone'] ?? '' ) ); ?></li><?php endforeach; ?></ul>
					<?php endif; ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="readiness" id="lnkup-ops-readiness-panel" role="tabpanel">
					<?php echo LNKup_Operations_Render::readiness_dashboard( $readiness_summary, $event_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="kanban" id="lnkup-ops-kanban-wrap" role="tabpanel">
					<?php echo LNKup_Operations_Render::kanban_board( $kanban ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="booths" id="lnkup-ops-booths-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Booths', 'lnkup-marketplace' ), __( 'Assign booth space and track coverage.', 'lnkup-marketplace' ), '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" id="lnkup-ops-add-booth">' . esc_html__( 'Add Booth', 'lnkup-marketplace' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-ops-booths-stats"></div>
						<div id="lnkup-ops-booths-list" class="lnkup-ops-table-wrap"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="parking" id="lnkup-ops-parking-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Parking', 'lnkup-marketplace' ), __( 'Lot assignments and gate instructions.', 'lnkup-marketplace' ), '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" id="lnkup-ops-add-parking">' . esc_html__( 'Add Parking', 'lnkup-marketplace' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-ops-parking-stats"></div>
						<div id="lnkup-ops-parking-list" class="lnkup-ops-table-wrap"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="loadin" id="lnkup-ops-loadin-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Load-In', 'lnkup-marketplace' ), __( 'Schedule entry windows and gate flow.', 'lnkup-marketplace' ), '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" id="lnkup-ops-add-loadin">' . esc_html__( 'Add Window', 'lnkup-marketplace' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-ops-loadin-stats"></div>
						<div id="lnkup-ops-loadin-list" class="lnkup-ops-table-wrap"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="map" id="lnkup-ops-map-panel" role="tabpanel">
					<p class="lnkup-muted"><?php esc_html_e( 'Venue Map = legacy pins. Map Builder = layout editor. Live Map = day-of status.', 'lnkup-marketplace' ); ?></p>
					<?php echo LNKup_Operations_Render::venue_map( $event_id, $booths ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="map-builder" id="lnkup-ops-map-builder-panel" role="tabpanel">
					<?php echo LNKup_Map_Render::shell( $event_id, 'builder' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="live-map" id="lnkup-ops-live-map-panel" role="tabpanel">
					<?php echo LNKup_Map_Render::shell( $event_id, 'live' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="support" id="lnkup-ops-support-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Support Requests', 'lnkup-marketplace' ), __( 'Track open field support work.', 'lnkup-marketplace' ), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-ops-support-list" class="lnkup-ops-table-wrap"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="incidents" id="lnkup-ops-incidents-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Incidents', 'lnkup-marketplace' ), __( 'Safety, medical, and logistics incident queue.', 'lnkup-marketplace' ), '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" id="lnkup-ops-new-incident">' . esc_html__( 'New Incident', 'lnkup-marketplace' ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div id="lnkup-ops-incidents-list" class="lnkup-ops-table-wrap"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="comms" id="lnkup-ops-comms-panel" role="tabpanel">
					<div class="lnkup-ops-comms-grid">
						<div class="lnkup-ops-panel-shell">
							<?php echo LNKup_Operations_Render::panel_header( __( 'Broadcast', 'lnkup-marketplace' ), __( 'Send updates to paid vendors and cohorts.', 'lnkup-marketplace' ), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<form id="lnkup-ops-broadcast-form" class="lnkup-ops-form">
								<label><?php esc_html_e( 'Audience', 'lnkup-marketplace' ); ?>
									<select name="audience">
										<option value="all_paid"><?php esc_html_e( 'All paid vendors', 'lnkup-marketplace' ); ?></option>
										<option value="checked_in"><?php esc_html_e( 'Checked in', 'lnkup-marketplace' ); ?></option>
										<option value="missing_docs"><?php esc_html_e( 'Missing documents', 'lnkup-marketplace' ); ?></option>
									</select>
								</label>
								<label><?php esc_html_e( 'Message', 'lnkup-marketplace' ); ?>
									<textarea name="message" rows="4" required></textarea>
								</label>
								<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Send Broadcast', 'lnkup-marketplace' ); ?></button>
							</form>
						</div>
						<div class="lnkup-ops-panel-shell">
							<?php echo LNKup_Operations_Render::panel_header( __( 'Recent Broadcasts', 'lnkup-marketplace' ), '', '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<div id="lnkup-ops-broadcasts-list" class="lnkup-ops-table-wrap"></div>
						</div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="analytics" id="lnkup-ops-analytics-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Analytics', 'lnkup-marketplace' ), __( 'Live operations metrics for day-of decisions.', 'lnkup-marketplace' ), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<div id="lnkup-ops-analytics" class="lnkup-ops-analytics-grid"></div>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="financial" id="lnkup-ops-financial-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Financial', 'lnkup-marketplace' ), __( 'Event payment and payout summary.', 'lnkup-marketplace' ), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo LNKup_Financial_Render::event_financial_tab( $event_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				</div>
				<div class="lnkup-ops-tab-panel" data-ops-panel="insights" id="lnkup-ops-insights-panel" role="tabpanel">
					<div class="lnkup-ops-panel-shell">
						<?php echo LNKup_Operations_Render::panel_header( __( 'Insights', 'lnkup-marketplace' ), __( 'AI-assisted event intelligence and risk flags.', 'lnkup-marketplace' ), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<div id="lnkup-event-insights" class="lnkup-intel-shell" data-event-id="<?php echo esc_attr( (string) $event_id ); ?>">
						<p class="lnkup-muted"><?php esc_html_e( 'Loading event insights…', 'lnkup-marketplace' ); ?></p>
					</div>
					</div>
				</div>
			</div>
			<div class="lnkup-ops-mobile-bar">
				<a href="<?php echo esc_url( $scan_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Scan', 'lnkup-marketplace' ); ?></a>
				<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-ops-goto-tab" data-ops-tab="readiness"><?php esc_html_e( 'Readiness', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-ops-goto-tab" data-ops-tab="kanban"><?php esc_html_e( 'Roster', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm" id="lnkup-ops-mobile-incident"><?php esc_html_e( 'Incident', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--accent" id="lnkup-ops-mobile-broadcast"><?php esc_html_e( 'Broadcast', 'lnkup-marketplace' ); ?></button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * QR scan check-in page for event staff.
	 *
	 * @param int $event_id Event ID.
	 */
	public static function render_qr_scan_view( $event_id ) {
		if ( ! LNKup_Capabilities::organizer_owns_event( $event_id ) && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Permission denied.', 'lnkup-marketplace' ) . '</p>';
		}
		$event = get_post( $event_id );
		$ops_url = add_query_arg( array( 'event' => $event_id, 'ops' => 1 ), lnkup_page_url_helper( 'organizer-dashboard' ) );
		ob_start();
		?>
		<div class="lnkup-mp lnkup-ops" id="lnkup-qr-scan" data-event-id="<?php echo esc_attr( (string) $event_id ); ?>">
			<p><a href="<?php echo esc_url( $ops_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm">&larr; <?php esc_html_e( 'Back to operations', 'lnkup-marketplace' ); ?></a></p>
			<h1 class="lnkup-heading lnkup-heading--page"><?php echo esc_html( $event ? $event->post_title : '' ); ?> — <?php esc_html_e( 'QR Check-In', 'lnkup-marketplace' ); ?></h1>
			<div id="lnkup-qr-reader" class="lnkup-ops-qr-reader"></div>
			<form id="lnkup-qr-manual" class="lnkup-ops-form">
				<label><?php esc_html_e( 'Or enter pass code manually', 'lnkup-marketplace' ); ?>
					<input type="text" name="token" autocomplete="off" required />
				</label>
				<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Check In', 'lnkup-marketplace' ); ?></button>
			</form>
			<div id="lnkup-qr-result" class="lnkup-ops-scan-result" role="status" aria-live="polite"></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Applications manager shortcode.
	 *
	 * @param array|null $apps_override Optional subset of applications to render.
	 */
	public static function render_applications_manager( $apps_override = null ) {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_organizer() && ! LNKup_Capabilities::user_has_manage_all() ) {
			return '';
		}

		$apps = is_array( $apps_override ) ? $apps_override : lnkup_get_applications_for_user( get_current_user_id(), 'organizer' );

		ob_start();
		if ( ! $apps ) {
			echo lnkup_empty_state(
				__( 'No vendor requests yet', 'lnkup-marketplace' ),
				lnkup_copy( 'empty_vendor_requests' ),
				lnkup_copy( 'launch_event' ),
				lnkup_page_url_helper( 'organizer-dashboard' ) . '#create'
			); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return ob_get_clean();
		}
		?>
		<div class="lnkup-crm-app-grid lnkup-crm-app-grid--v2">
		<?php foreach ( $apps as $app ) : ?>
			<?php
			$profile_id = (int) get_post_meta( $app->ID, '_lnkup_vendor_profile_id', true );
			$profile = $profile_id ? LNKup_Vendor_CRM_Profile::get( $profile_id, get_current_user_id() ) : null;
			$event_id  = (int) get_post_meta( $app->ID, '_lnkup_event_id', true );
			$event     = $event_id ? get_post( $event_id ) : null;
			$status    = get_post_meta( $app->ID, '_lnkup_application_status', true );
			$readiness = LNKup_Vendor_Readiness::refresh( $app->ID );
			$filter_pending = in_array( $status, array( 'submitted', 'under_review' ), true ) ? 'pending' : '';
			$filter_approved = in_array( $status, array( 'approved', 'payment_required', 'paid', 'completed' ), true ) ? 'approved' : '';
			$filter_unpaid = in_array( $status, array( 'approved', 'payment_required' ), true ) ? 'unpaid' : '';
			$filter_docs = 'ready' !== $readiness ? 'missing_docs' : '';
			$filter_key = $filter_pending ?: ( 'waitlisted' === $status ? 'waitlisted' : ( 'rejected' === $status ? 'rejected' : ( $filter_unpaid ?: ( $filter_approved ?: $filter_docs ) ) ) );
			$profile_url = $profile_id ? add_query_arg( 'vendor', $profile_id, lnkup_page_url_helper( 'organizer-dashboard' ) ) : '#';
			$initials    = '';
			if ( $profile && ! empty( $profile['business_name'] ) ) {
				foreach ( preg_split( '/\s+/', trim( $profile['business_name'] ) ) as $part ) {
					$initials .= strtoupper( substr( $part, 0, 1 ) );
					if ( strlen( $initials ) >= 2 ) {
						break;
					}
				}
			}
			$category_label = $profile && ! empty( $profile['category'] ) ? implode( ', ', array_slice( $profile['category'], 0, 2 ) ) : '—';
			$rating         = $profile && ! empty( $profile['avg_rating'] ) ? (string) $profile['avg_rating'] : '';
			$events_count   = $profile ? (string) ( $profile['reliability']['completed_events'] ?? $profile['completed_events'] ?? 0 ) : '0';
			$docs_ok        = 'ready' === $readiness;
			$is_paid       = in_array( $status, array( 'paid', 'completed' ), true );
			$status_label  = LNKup_Vendor_Dashboard_Data::application_status_label( $status );
			?>
			<article class="lnkup-crm-app-card lnkup-crm-app-card--v2" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-org-app-filter="<?php echo esc_attr( $filter_key ); ?>" data-org-app-status="<?php echo esc_attr( $status ); ?>" data-org-app-docs="<?php echo esc_attr( $docs_ok ? 'ready' : 'missing' ); ?>" data-org-app-paid="<?php echo esc_attr( $is_paid ? 'yes' : 'no' ); ?>">
				<div class="lnkup-crm-app-card__header">
					<?php if ( $profile && ! empty( $profile['logo'] ) ) : ?>
						<img src="<?php echo esc_url( $profile['logo'] ); ?>" alt="" class="lnkup-crm-app-card__avatar" />
					<?php else : ?>
						<span class="lnkup-crm-app-card__avatar lnkup-crm-app-card__avatar--placeholder"><?php echo esc_html( $initials ?: 'V' ); ?></span>
					<?php endif; ?>
					<div class="lnkup-crm-app-card__header-main">
						<h3 class="lnkup-crm-app-card__name"><a href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( $profile ? $profile['business_name'] : '—' ); ?></a></h3>
						<p class="lnkup-crm-app-card__meta lnkup-muted">
							<?php echo esc_html( $category_label ); ?>
							<?php if ( $rating ) : ?>
								· ★ <?php echo esc_html( $rating ); ?>
							<?php endif; ?>
							· <?php printf( esc_html__( '%s events', 'lnkup-marketplace' ), esc_html( $events_count ) ); ?>
						</p>
					</div>
				</div>
				<div class="lnkup-crm-app-card__chips">
					<span class="lnkup-status lnkup-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status_label ); ?></span>
					<span class="lnkup-crm-app-chip"><?php printf( esc_html__( 'Applied: %s', 'lnkup-marketplace' ), esc_html( $event ? $event->post_title : '—' ) ); ?></span>
					<?php
					$docs_badge_status = $docs_ok ? 'verified' : 'docs_pending';
					$docs_badge_label  = $docs_ok ? __( 'Docs verified', 'lnkup-marketplace' ) : __( 'Docs pending', 'lnkup-marketplace' );
					echo lnkup_status_badge( $docs_badge_status, $docs_badge_label ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
					<?php if ( in_array( $status, array( 'approved', 'payment_required' ), true ) ) : ?>
						<span class="lnkup-crm-app-chip lnkup-crm-app-chip--<?php echo esc_attr( $is_paid ? 'success' : 'warning' ); ?>"><?php echo esc_html( $is_paid ? __( 'Paid', 'lnkup-marketplace' ) : __( 'Balance due', 'lnkup-marketplace' ) ); ?></span>
					<?php endif; ?>
				</div>
				<?php
				$is_actionable = in_array( $status, array( 'submitted', 'under_review', 'waitlisted' ), true );
				if ( $is_actionable ) :
				?>
					<div class="lnkup-crm-app-card__actions lnkup-crm-app-card__actions--primary">
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary lnkup-review-btn" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="approve"><?php esc_html_e( 'Approve', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline lnkup-review-btn" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="waitlist"><?php esc_html_e( 'Waitlist', 'lnkup-marketplace' ); ?></button>
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost lnkup-review-btn lnkup-review-btn--decline" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="reject"><?php esc_html_e( 'Decline', 'lnkup-marketplace' ); ?></button>
					</div>
				<?php else : ?>
					<div class="lnkup-crm-app-card__decision">
						<span class="lnkup-crm-app-card__decision-label"><?php echo esc_html( LNKup_Vendor_Dashboard_Data::application_status_label( $status ) ); ?></span>
					</div>
				<?php endif; ?>
				<div class="lnkup-crm-app-card__more">
					<label class="lnkup-crm-compare-check"><input type="checkbox" class="lnkup-crm-compare-pick" value="<?php echo esc_attr( (string) $app->ID ); ?>" /> <?php esc_html_e( 'Compare', 'lnkup-marketplace' ); ?></label>
					<div class="lnkup-crm-app-card__more-actions">
						<?php
						$message_href = '';
						if ( $profile && ! empty( $profile['email'] ) ) {
							$message_href = 'mailto:' . sanitize_email( $profile['email'] );
						} elseif ( $profile_url ) {
							$message_href = $profile_url;
						}
						if ( $message_href ) :
							?>
							<a href="<?php echo esc_url( $message_href ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost"><?php esc_html_e( 'Message', 'lnkup-marketplace' ); ?></a>
						<?php endif; ?>
						<?php if ( ! $docs_ok && $profile_id ) : ?>
							<a href="<?php echo esc_url( add_query_arg( 'vendor', $profile_id, lnkup_page_url_helper( 'organizer-dashboard' ) ) ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline"><?php esc_html_e( 'Review docs', 'lnkup-marketplace' ); ?></a>
						<?php endif; ?>
						<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost lnkup-intel-open" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>"><?php esc_html_e( 'View Intel', 'lnkup-marketplace' ); ?></button>
					</div>
				</div>
			</article>
		<?php endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Documents manager shortcode.
	 */
	public static function render_documents_manager() {
		LNKup_Capabilities::require_login();
		$user_id    = get_current_user_id();
		$compliance = LNKup_Documents::compliance_summary( $user_id );
		$types      = LNKup_Documents::document_types();
		$pct        = $compliance['total'] ? round( ( $compliance['verified'] / $compliance['total'] ) * 100 ) : 0;

		$status_labels = array(
			'verified' => __( 'Verified', 'lnkup-marketplace' ),
			'expiring' => __( 'Expiring soon', 'lnkup-marketplace' ),
			'pending'  => __( 'Pending review', 'lnkup-marketplace' ),
			'missing'  => __( 'Missing', 'lnkup-marketplace' ),
		);

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash" id="documents">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Documents & compliance', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Upload and maintain the documents organizers require', 'lnkup-marketplace' ); ?></p>
			</header>

			<div class="lnkup-panel lnkup-doc-score">
				<div class="lnkup-doc-score__header">
					<div>
						<h2 class="lnkup-panel__title"><?php printf( esc_html__( '%1$d of %2$d documents verified', 'lnkup-marketplace' ), (int) $compliance['verified'], (int) $compliance['total'] ); ?></h2>
						<p class="lnkup-muted"><?php esc_html_e( 'Complete your compliance profile to unlock faster approvals.', 'lnkup-marketplace' ); ?></p>
					</div>
					<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( (string) $pct ); ?>%</span>
				</div>
				<div class="lnkup-doc-score__bar" role="progressbar" aria-valuenow="<?php echo esc_attr( (string) $pct ); ?>" aria-valuemin="0" aria-valuemax="100">
					<div class="lnkup-doc-score__fill" style="width:<?php echo esc_attr( (string) $pct ); ?>%"></div>
				</div>
			</div>

			<div class="lnkup-doc-grid">
				<?php foreach ( $compliance['items'] as $type_key => $item ) : ?>
					<article class="lnkup-doc-card">
						<h3 class="lnkup-doc-card__title"><?php echo esc_html( $item['label'] ); ?></h3>
						<p class="lnkup-doc-card__status lnkup-doc-card__status--<?php echo esc_attr( $item['status'] ); ?>"><?php echo esc_html( $status_labels[ $item['status'] ] ?? $item['status'] ); ?></p>
						<?php if ( $item['expires'] && 'verified' !== $item['status'] && 'missing' !== $item['status'] ) : ?>
							<p class="lnkup-muted"><?php printf( esc_html__( 'Expires %s', 'lnkup-marketplace' ), esc_html( date_i18n( 'M j, Y', strtotime( $item['expires'] ) ) ) ); ?></p>
						<?php endif; ?>
						<div class="lnkup-doc-card__actions">
							<?php if ( $item['doc_id'] ) : ?>
								<a href="<?php echo esc_url( LNKup_Documents::download_url( $item['doc_id'] ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Download', 'lnkup-marketplace' ); ?></a>
							<?php endif; ?>
							<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm" data-doc-upload="<?php echo esc_attr( $type_key ); ?>"><?php echo $item['doc_id'] ? esc_html__( 'Replace', 'lnkup-marketplace' ) : esc_html__( 'Upload', 'lnkup-marketplace' ); ?></button>
						</div>
					</article>
				<?php endforeach; ?>
			</div>

			<form class="lnkup-form lnkup-document-form lnkup-doc-upload-form" id="lnkup-document-upload-form" enctype="multipart/form-data">
				<?php wp_nonce_field( 'lnkup_document', 'lnkup_nonce' ); ?>
				<input type="hidden" name="action" value="lnkup_upload_document" />
				<div class="lnkup-grid lnkup-grid--2">
					<div class="lnkup-form-row">
						<label for="document_type"><?php esc_html_e( 'Document Type', 'lnkup-marketplace' ); ?></label>
						<select id="document_type" name="document_type" required>
							<?php foreach ( $types as $key => $label ) : ?>
								<?php if ( 'other' === $key ) { continue; } ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="lnkup-form-row">
						<label for="expiration_date"><?php esc_html_e( 'Expiration Date', 'lnkup-marketplace' ); ?></label>
						<input type="date" id="expiration_date" name="expiration_date" />
					</div>
				</div>
				<input type="file" id="lnkup_document" name="lnkup_document" accept=".pdf,.jpg,.jpeg,.png" />
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Payments dashboard shortcode.
	 *
	 * @param string $role vendor|organizer.
	 */
	public static function render_payments_dashboard( $role = 'vendor' ) {
		LNKup_Capabilities::require_login();
		if ( 'organizer' === $role ) {
			return '<p class="lnkup-muted">' . esc_html__( 'Organizer payments are managed in the Financial dashboard.', 'lnkup-marketplace' ) . '</p>';
		}

		ob_start();
		$payments = lnkup_get_payments_for_user( get_current_user_id(), $role );
		$totals   = LNKup_Vendor_Dashboard_Data::payment_totals( $payments );
		if ( 'vendor' === $role ) {
			$wallet       = LNKup_Wallet::get_balance( get_current_user_id(), 'vendor' );
			$installments = LNKup_Installments::upcoming_for_vendor( get_current_user_id() );
			$next_due     = $installments ? $installments[0] : null;
			$apps_url     = add_query_arg( 'view', 'applications', lnkup_page_url_helper( 'vendor-dashboard' ) );
			?>
		<div class="lnkup-mp lnkup-vendor-dash" id="payments">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Payments', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Payments, invoices, credits, and transaction history', 'lnkup-marketplace' ); ?></p>
			</header>

			<?php if ( ! $payments ) : ?>
				<?php
				echo lnkup_empty_state(
					__( 'No payments yet', 'lnkup-marketplace' ),
					__( 'Application fees and invoices will appear here once you are approved for events.', 'lnkup-marketplace' ),
					__( 'View applications', 'lnkup-marketplace' ),
					$apps_url
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			<?php endif; ?>

			<?php echo LNKup_Financial_Render::vendor_shell(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php
		}
		?>

		<?php
		if ( 'vendor' === $role ) :
			?>
		</div>
		<?php
		endif;
		return ob_get_clean();
	}

	/**
	 * Public vendor profile shortcode.
	 */
	public static function render_vendor_public_profile() {
		$slug = isset( $_GET['vendor'] ) ? sanitize_text_field( wp_unslash( $_GET['vendor'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $slug ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Vendor not found.', 'lnkup-marketplace' ) . '</p>';
		}
		$profile_id = LNKup_Vendor_Reputation::resolve_profile( $slug );
		if ( ! $profile_id ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Vendor not found.', 'lnkup-marketplace' ) . '</p>';
		}
		$data = LNKup_Vendor_CRM_Profile::get_public( $profile_id );
		if ( ! $data ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Vendor not found.', 'lnkup-marketplace' ) . '</p>';
		}
		$public_url = lnkup_page_url_helper( 'vendors' );
		ob_start();
		?>
		<div class="lnkup-mp lnkup-rep-public" id="lnkup-public-vendor-profile" data-profile-id="<?php echo esc_attr( (string) $profile_id ); ?>">
			<div class="lnkup-rep-public__header">
				<h1 class="lnkup-heading lnkup-heading--page"><?php echo esc_html( $data['business_name'] ); ?></h1>
				<p class="lnkup-muted"><?php echo esc_html( $data['city'] . ( $data['state'] ? ', ' . $data['state'] : '' ) ); ?></p>
				<?php echo LNKup_Reputation_Render::summary_card( $data['reputation'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<div class="lnkup-rep-public__grid">
				<section class="lnkup-panel">
					<h2><?php esc_html_e( 'About', 'lnkup-marketplace' ); ?></h2>
					<p><?php echo esc_html( $data['description'] ); ?></p>
					<p><?php echo esc_html( $data['products_services'] ); ?></p>
					<p><?php echo esc_html( implode( ', ', (array) $data['categories'] ) ); ?></p>
				</section>
				<section class="lnkup-panel">
					<h2><?php esc_html_e( 'Reliability', 'lnkup-marketplace' ); ?></h2>
					<?php echo LNKup_Reputation_Render::reliability_meter( $data['reputation']['metrics'] ?? array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</section>
				<section class="lnkup-panel">
					<h2><?php esc_html_e( 'Reviews', 'lnkup-marketplace' ); ?></h2>
					<?php foreach ( $data['reviews'] as $review ) : ?>
						<?php echo LNKup_Reputation_Render::review_card( $review ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endforeach; ?>
				</section>
				<section class="lnkup-panel">
					<h2><?php esc_html_e( 'Event history', 'lnkup-marketplace' ); ?></h2>
					<?php echo LNKup_Reputation_Render::completed_events_timeline( $data['events'], 12 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</section>
			</div>
			<?php if ( is_user_logged_in() && ( LNKup_Roles::is_organizer() || LNKup_Capabilities::user_has_manage_all() ) ) : ?>
				<p><a class="lnkup-btn lnkup-btn--primary" href="<?php echo esc_url( add_query_arg( 'vendor', $profile_id, lnkup_page_url_helper( 'organizer-dashboard' ) ) ); ?>"><?php esc_html_e( 'View in CRM', 'lnkup-marketplace' ); ?></a></p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Check if application post has paid status.
	 *
	 * @param WP_Post $application Application post.
	 */
	public static function is_paid_application( $application ) {
		return 'paid' === get_post_meta( $application->ID, '_lnkup_application_status', true );
	}
}
