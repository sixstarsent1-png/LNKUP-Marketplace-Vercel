<?php
/**
 * Vendor dashboard view renderers.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Vendor_Dashboard_Views {

	/**
	 * Render stat card.
	 *
	 * @param string $label Label.
	 * @param string $value Value.
	 * @param string $trend Trend line.
	 * @param string $icon  Icon key.
	 * @param bool   $is_zero Whether value is zero for muted styling.
	 * @param string $trend_dir Trend direction: up|down|neutral.
	 * @param string $href    Optional link URL (wraps card as anchor).
	 */
	public static function stat_card( $label, $value, $trend = '', $icon = 'apps', $is_zero = false, $trend_dir = 'neutral', $href = '' ) {
		return lnkup_kpi_card(
			array(
				'label'     => $label,
				'value'     => $value,
				'trend'     => $trend,
				'icon'      => $icon,
				'is_zero'   => $is_zero,
				'trend_dir' => $trend_dir,
				'href'      => $href,
			)
		);
	}

	/**
	 * Render organizer overview action card with icon tile.
	 *
	 * @param string $href     Link URL.
	 * @param string $title    Card title.
	 * @param string $subtitle Subtitle text.
	 * @param string $icon     Icon key (inbox|users|payment|search|docs|chart).
	 */
	public static function organizer_action_card( $href, $title, $subtitle, $icon = 'inbox' ) {
		$icons = array(
			'inbox'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-6l-2 3H10l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
			'users'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
			'payment'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/></svg>',
			'calendar' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
			'search'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
			'docs'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/></svg>',
			'chart'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>',
		);
		$icon_html = function_exists( 'lnkup_inline_icon' )
			? lnkup_inline_icon( $icons[ $icon ] ?? $icons['inbox'], 18 )
			: ( $icons[ $icon ] ?? $icons['inbox'] );
		ob_start();
		?>
		<a href="<?php echo esc_url( $href ); ?>" class="lnkup-organizer-action-card">
			<span class="lnkup-organizer-action-card__icon" style="display:inline-flex;width:1.75rem;height:1.75rem;flex-shrink:0;overflow:hidden;align-items:center;justify-content:center;" aria-hidden="true"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<strong><?php echo esc_html( $title ); ?></strong>
			<span><?php echo esc_html( $subtitle ); ?></span>
		</a>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render vendor home action card with icon tile.
	 *
	 * @param string $href     Link URL.
	 * @param string $title    Card title.
	 * @param string $subtitle Subtitle text.
	 * @param string $icon     Icon key.
	 */
	public static function action_card( $href, $title, $subtitle, $icon = 'apps' ) {
		$icons = array(
			'search'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
			'store'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9 12 2l9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/></svg>',
			'docs'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/></svg>',
			'payment' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/></svg>',
			'chart'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>',
		);
		$icon_html = function_exists( 'lnkup_inline_icon' )
			? lnkup_inline_icon( $icons[ $icon ] ?? $icons['search'], 18 )
			: ( $icons[ $icon ] ?? $icons['search'] );
		ob_start();
		?>
		<a href="<?php echo esc_url( $href ); ?>" class="lnkup-vendor-action-card">
			<span class="lnkup-vendor-action-card__icon" style="display:inline-flex;width:1.75rem;height:1.75rem;flex-shrink:0;overflow:hidden;align-items:center;justify-content:center;" aria-hidden="true"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<strong><?php echo esc_html( $title ); ?></strong>
			<span class="lnkup-muted"><?php echo esc_html( $subtitle ); ?></span>
		</a>
		<?php
		return ob_get_clean();
	}

	/**
	 * Vendor dashboard home view.
	 */
	public static function render_home() {
		LNKup_Capabilities::require_login();
		$ctx           = LNKup_Vendor_Dashboard_Data::context();
		$user_id       = $ctx['user_id'];
		$applications  = $ctx['applications'];
		$payments      = $ctx['payments'];
		$profile_id    = $ctx['profile_id'];
		$compliance    = $ctx['compliance'];
		$display_name  = $ctx['business_name'] ? $ctx['business_name'] : wp_get_current_user()->display_name;
		$subtitle      = $ctx['city'] ? trim( $ctx['city'] . ( $ctx['state'] ? ', ' . $ctx['state'] : '' ) ) : __( 'Complete your profile to unlock personalized recommendations.', 'lnkup-marketplace' );
		$active_count  = LNKup_Vendor_Dashboard_Data::count_active_applications( $applications );
		$bookings      = LNKup_Vendor_Dashboard_Data::count_confirmed_bookings( $applications );
		$earned        = LNKup_Vendor_Dashboard_Data::earned_this_season( $payments );
		$attention     = LNKup_Vendor_Dashboard_Data::attention_applications( $applications );
		$recommended   = lnkup_marketplace_phase_at_least( '1b' ) ? LNKup_Recommendations::get_for_user( $user_id, 3 ) : array();
		$apps_url      = add_query_arg( 'view', 'applications', lnkup_page_url_helper( 'vendor-dashboard' ) );
		$docs_url      = add_query_arg( 'view', 'documents', lnkup_page_url_helper( 'vendor-dashboard' ) );
		$doc_value     = $compliance['attention_count'] > 0
			? (string) $compliance['attention_count']
			: (string) $compliance['verified'];
		$doc_trend     = $compliance['attention_count'] > 0
			? __( 'need attention', 'lnkup-marketplace' )
			: sprintf( __( 'of %d verified', 'lnkup-marketplace' ), $compliance['total'] );
		$reviews_url   = add_query_arg( 'view', 'reviews', lnkup_page_url_helper( 'vendor-dashboard' ) );

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash">
			<?php if ( isset( $_GET['lnkup_payment'] ) && 'success' === $_GET['lnkup_payment'] ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="lnkup-alert lnkup-alert--success"><?php esc_html_e( 'Payment successful! Your packet is unlocked.', 'lnkup-marketplace' ); ?></div>
			<?php endif; ?>

			<?php self::render_vendor_notices( $user_id ); ?>

			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php printf( esc_html__( 'Welcome back, %s', 'lnkup-marketplace' ), esc_html( $display_name ) ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php echo esc_html( $subtitle ); ?></p>
			</header>

			<?php
			$week         = LNKup_Vendor_Dashboard_Data::week_snapshot( $ctx );
			$ops_url      = add_query_arg( 'view', 'operations', lnkup_page_url_helper( 'vendor-dashboard' ) );
			$payments_url = add_query_arg( 'view', 'payments', lnkup_page_url_helper( 'vendor-dashboard' ) );
			$growth_url   = add_query_arg( 'view', 'growth', lnkup_page_url_helper( 'vendor-dashboard' ) );
			$profile_url  = lnkup_page_url_helper( 'vendor-profile' );
			$find_url     = lnkup_page_url_helper( 'opportunities' );
			?>

			<div class="lnkup-vendor-week-strip">
				<div class="lnkup-vendor-week-strip__item">
					<span class="lnkup-vendor-week-strip__label"><?php esc_html_e( 'Next event', 'lnkup-marketplace' ); ?></span>
					<strong><?php echo $week['next_event_date'] ? esc_html( date_i18n( 'M j', strtotime( $week['next_event_date'] ) ) ) : esc_html__( 'None booked', 'lnkup-marketplace' ); ?></strong>
				</div>
				<div class="lnkup-vendor-week-strip__item">
					<span class="lnkup-vendor-week-strip__label"><?php esc_html_e( 'Outstanding', 'lnkup-marketplace' ); ?></span>
					<strong><?php echo esc_html( (string) $week['outstanding_count'] ); ?></strong>
				</div>
				<div class="lnkup-vendor-week-strip__item">
					<span class="lnkup-vendor-week-strip__label"><?php esc_html_e( 'Profile strength', 'lnkup-marketplace' ); ?></span>
					<strong><?php echo esc_html( (string) $week['profile_strength'] ); ?>%</strong>
				</div>
			</div>

			<div class="lnkup-vendor-action-grid">
				<?php
				echo self::action_card( $find_url, __( 'Find Events', 'lnkup-marketplace' ), __( 'Browse and apply', 'lnkup-marketplace' ), 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::action_card( $profile_url, __( 'Complete Profile', 'lnkup-marketplace' ), $week['profile_strength'] . '% ' . __( 'strength', 'lnkup-marketplace' ), 'store' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::action_card( $docs_url, __( 'Upload Documents', 'lnkup-marketplace' ), $doc_value . ' ' . __( 'items', 'lnkup-marketplace' ), 'docs' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::action_card( $payments_url, __( 'View Payments', 'lnkup-marketplace' ), lnkup_currency( $earned ) . ' ' . __( 'earned', 'lnkup-marketplace' ), 'payment' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::action_card( $growth_url, __( 'View Growth', 'lnkup-marketplace' ), __( 'Insights & goals', 'lnkup-marketplace' ), 'chart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>

			<?php if ( ! $active_count && ! $bookings && ! $attention ) : ?>
				<div class="lnkup-panel lnkup-vendor-empty-home">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Your vendor command center', 'lnkup-marketplace' ); ?></h2>
					<p class="lnkup-muted"><?php esc_html_e( 'Start by finding events, completing your profile, and uploading compliance documents.', 'lnkup-marketplace' ); ?></p>
					<a href="<?php echo esc_url( $find_url ); ?>" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Browse Find Events', 'lnkup-marketplace' ); ?></a>
				</div>
			<?php endif; ?>

			<?php
			echo lnkup_dash_subnav(
				array(
					array( 'id' => 'overview', 'label' => __( 'Overview', 'lnkup-marketplace' ), 'href' => '#overview' ),
					array( 'id' => 'upcoming', 'label' => __( 'Upcoming', 'lnkup-marketplace' ), 'href' => '#upcoming' ),
					array( 'id' => 'recommendations', 'label' => __( 'Recommendations', 'lnkup-marketplace' ), 'href' => '#recommendations' ),
				),
				'overview'
			); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>

			<div class="lnkup-vendor-home-panels">
				<div class="lnkup-vendor-home-panel is-active" id="overview" data-vendor-home-panel="overview">
			<div class="lnkup-grid lnkup-grid--4 lnkup-vendor-dash__stats">
				<?php
				$apps_week   = LNKup_Vendor_Dashboard_Data::applications_this_week( $applications );
				$apps_trend  = $apps_week > 0
					? sprintf( _n( '+%d this week', '+%d this week', $apps_week, 'lnkup-marketplace' ), $apps_week )
					: __( 'No new apps this week', 'lnkup-marketplace' );
				$apps_t_dir  = $apps_week > 0 ? 'up' : 'neutral';
				$book_trend  = $week['next_event_date']
					? sprintf( __( 'Next: %s', 'lnkup-marketplace' ), date_i18n( 'M j', strtotime( $week['next_event_date'] ) ) )
					: __( 'No upcoming events', 'lnkup-marketplace' );
				$book_t_dir  = $week['next_event_date'] ? 'up' : 'neutral';
				$doc_t_dir   = $compliance['attention_count'] > 0 ? 'down' : 'neutral';
				echo self::stat_card( __( 'Active applications', 'lnkup-marketplace' ), (string) $active_count, $apps_trend, 'apps', 0 === $active_count, $apps_t_dir ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::stat_card( __( 'Confirmed bookings', 'lnkup-marketplace' ), (string) $bookings, $book_trend, 'star', 0 === $bookings, $book_t_dir ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::stat_card( __( 'Earned this season', 'lnkup-marketplace' ), lnkup_currency( $earned ), __( 'Season to date', 'lnkup-marketplace' ), 'cash', $earned <= 0, 'neutral' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::stat_card( __( 'Documents', 'lnkup-marketplace' ), $doc_value, $doc_trend, 'docs', 0 === (int) $doc_value && 0 === $compliance['attention_count'], $doc_t_dir ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>

			<div class="lnkup-grid lnkup-grid--2-1 lnkup-vendor-dash__split">
				<div class="lnkup-panel lnkup-panel--flush">
					<div class="lnkup-panel__header-row">
						<div>
							<h2 class="lnkup-panel__title"><?php esc_html_e( 'Needs your attention', 'lnkup-marketplace' ); ?></h2>
							<p class="lnkup-muted lnkup-panel__desc"><?php esc_html_e( 'Applications waiting on a next step from you', 'lnkup-marketplace' ); ?></p>
						</div>
						<a href="<?php echo esc_url( $apps_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View all', 'lnkup-marketplace' ); ?></a>
					</div>
					<div class="lnkup-attention-list">
						<?php if ( $attention ) : ?>
							<?php foreach ( array_slice( $attention, 0, 5 ) as $app ) : ?>
								<?php
								$meta   = LNKup_Vendor_Dashboard_Data::application_event_meta( $app );
								$status = get_post_meta( $app->ID, '_lnkup_application_status', true );
								$payment = LNKup_Payments::get_for_application( $app->ID );
								?>
								<div class="lnkup-attention-item lnkup-attention-item--action">
									<div>
										<p class="lnkup-attention-item__title"><?php echo esc_html( $meta['event_title'] ); ?></p>
										<p class="lnkup-attention-item__meta"><?php echo esc_html( trim( $meta['city'] . ( $meta['state'] ? ', ' . $meta['state'] : '' ) ) ); ?></p>
									</div>
									<div class="lnkup-attention-item__actions">
										<span class="lnkup-status lnkup-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( LNKup_Vendor_Dashboard_Data::application_status_label( $status ) ); ?></span>
										<?php if ( $payment && 'pending' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) : ?>
											<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm lnkup-pay-btn" data-payment-id="<?php echo esc_attr( (string) $payment->ID ); ?>"><?php esc_html_e( 'Pay now', 'lnkup-marketplace' ); ?></button>
										<?php else : ?>
											<a href="<?php echo esc_url( $apps_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View app', 'lnkup-marketplace' ); ?></a>
										<?php endif; ?>
									</div>
								</div>
							<?php endforeach; ?>
						<?php elseif ( $compliance['attention_count'] > 0 ) : ?>
							<div class="lnkup-attention-item lnkup-attention-item--action">
								<div>
									<p class="lnkup-attention-item__title"><?php esc_html_e( 'Documents need attention', 'lnkup-marketplace' ); ?></p>
									<p class="lnkup-attention-item__meta"><?php echo esc_html( sprintf( __( '%d items missing or expiring', 'lnkup-marketplace' ), $compliance['attention_count'] ) ); ?></p>
									<div class="lnkup-attention-item__chips">
										<?php foreach ( $compliance['items'] as $item ) : ?>
											<?php if ( 'verified' !== $item['status'] ) : ?>
												<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( $item['label'] ); ?></span>
											<?php endif; ?>
										<?php endforeach; ?>
									</div>
								</div>
								<a href="<?php echo esc_url( $docs_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Review', 'lnkup-marketplace' ); ?></a>
							</div>
						<?php else : ?>
							<div class="lnkup-empty-state lnkup-empty-state--compact">
								<p class="lnkup-empty-state__desc"><?php esc_html_e( 'You are all caught up.', 'lnkup-marketplace' ); ?></p>
								<div class="lnkup-empty-state__actions">
									<a href="<?php echo esc_url( $find_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Browse Find Events', 'lnkup-marketplace' ); ?></a>
									<a href="<?php echo esc_url( $profile_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Complete profile', 'lnkup-marketplace' ); ?></a>
								</div>
							</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="lnkup-panel lnkup-reputation-card">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Your reputation', 'lnkup-marketplace' ); ?></h2>
					<?php if ( $profile_id && class_exists( 'LNKup_Vendor_Reputation' ) ) : ?>
						<?php
						$rep = LNKup_Vendor_Reputation::get( $profile_id );
						if ( ! empty( $rep['is_new'] ) ) {
							echo '<span class="lnkup-rep-score lnkup-rep-score--new">' . esc_html__( 'New vendor', 'lnkup-marketplace' ) . '</span>';
							echo '<p class="lnkup-muted">' . esc_html__( 'Complete events to build your reputation.', 'lnkup-marketplace' ) . '</p>';
						} else {
							echo LNKup_Reputation_Render::summary_card( $rep ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
						?>
						<ul class="lnkup-reputation-card__metrics">
							<li><span><?php esc_html_e( 'Completed events', 'lnkup-marketplace' ); ?></span><strong><?php echo esc_html( (string) ( $rep['metrics']['completed_events'] ?? 0 ) ); ?></strong></li>
							<li><span><?php esc_html_e( 'On-time rate', 'lnkup-marketplace' ); ?></span><strong><?php echo esc_html( (string) ( $rep['metrics']['on_time_rate'] ?? '—' ) ); ?>%</strong></li>
							<li><span><?php esc_html_e( 'Repeat bookings', 'lnkup-marketplace' ); ?></span><strong><?php echo esc_html( (string) ( $rep['metrics']['repeat_bookings'] ?? 0 ) ); ?></strong></li>
						</ul>
						<a href="<?php echo esc_url( $reviews_url ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View reviews', 'lnkup-marketplace' ); ?></a>
					<?php else : ?>
						<p class="lnkup-muted"><?php esc_html_e( 'Complete your profile to start building reputation.', 'lnkup-marketplace' ); ?></p>
					<?php endif; ?>
				</div>
			</div>

			<div class="lnkup-grid lnkup-grid--2 lnkup-vendor-dash__previews">
				<a class="lnkup-panel lnkup-panel--link" href="<?php echo esc_url( add_query_arg( 'view', 'operations', lnkup_page_url_helper( 'vendor-dashboard' ) ) ); ?>">
					<h3 class="lnkup-panel__title"><?php esc_html_e( 'Event operations', 'lnkup-marketplace' ); ?></h3>
					<p class="lnkup-muted"><?php esc_html_e( 'Packets, readiness checklists, venue maps, and day-of support.', 'lnkup-marketplace' ); ?></p>
				</a>
				<a class="lnkup-panel lnkup-panel--link" href="<?php echo esc_url( $growth_url ); ?>">
					<h3 class="lnkup-panel__title"><?php esc_html_e( 'Growth insights', 'lnkup-marketplace' ); ?></h3>
					<p class="lnkup-muted"><?php esc_html_e( 'Revenue trends, market expansion, and profile recommendations.', 'lnkup-marketplace' ); ?></p>
				</a>
			</div>
				</div>

				<div class="lnkup-vendor-home-panel" id="upcoming" data-vendor-home-panel="upcoming" hidden>
					<?php if ( $week['next_event_title'] && $week['next_application_id'] ) : ?>
						<div class="lnkup-panel lnkup-vendor-upcoming-hero">
							<div class="lnkup-vendor-upcoming-hero__main">
								<p class="lnkup-muted"><?php esc_html_e( 'Upcoming event', 'lnkup-marketplace' ); ?></p>
								<h2 class="lnkup-panel__title"><?php echo esc_html( $week['next_event_title'] ); ?></h2>
								<?php if ( $week['next_event_date'] ) : ?>
									<p class="lnkup-vendor-upcoming-hero__date"><?php echo esc_html( date_i18n( 'l, F j, Y', strtotime( $week['next_event_date'] ) ) ); ?></p>
								<?php endif; ?>
								<p class="lnkup-vendor-upcoming-hero__readiness"><?php printf( esc_html__( '%d%% event ready', 'lnkup-marketplace' ), (int) $week['readiness_percent'] ); ?></p>
							</div>
							<a href="<?php echo esc_url( add_query_arg( array( 'view' => 'operations', 'app' => $week['next_application_id'] ), lnkup_page_url_helper( 'vendor-dashboard' ) ) ); ?>" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Event operations', 'lnkup-marketplace' ); ?></a>
						</div>
					<?php else : ?>
						<div class="lnkup-empty-state lnkup-empty-state--compact">
							<p class="lnkup-empty-state__title"><?php esc_html_e( 'No upcoming events', 'lnkup-marketplace' ); ?></p>
							<p class="lnkup-empty-state__desc"><?php esc_html_e( 'Book a booth to see your next event here.', 'lnkup-marketplace' ); ?></p>
							<a href="<?php echo esc_url( $find_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Find events', 'lnkup-marketplace' ); ?></a>
						</div>
					<?php endif; ?>
				</div>

				<div class="lnkup-vendor-home-panel" id="recommendations" data-vendor-home-panel="recommendations" hidden>
					<?php if ( $recommended ) : ?>
						<div class="lnkup-panel lnkup-vendor-recommendations">
							<div class="lnkup-panel__header-row">
								<h2 class="lnkup-panel__title"><?php esc_html_e( 'Recommended for you', 'lnkup-marketplace' ); ?></h2>
								<a href="<?php echo esc_url( lnkup_page_url_helper( 'opportunities' ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Browse all', 'lnkup-marketplace' ); ?></a>
							</div>
							<div class="lnkup-event-grid lnkup-event-grid--tight"><?php foreach ( $recommended as $opp ) { echo lnkup_render_opportunity_card_v2( $opp ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						</div>
					<?php else : ?>
						<div class="lnkup-empty-state lnkup-empty-state--compact">
							<p class="lnkup-empty-state__title"><?php esc_html_e( 'No recommendations yet', 'lnkup-marketplace' ); ?></p>
							<p class="lnkup-empty-state__desc"><?php esc_html_e( 'Complete your profile to unlock personalized event matches.', 'lnkup-marketplace' ); ?></p>
							<a href="<?php echo esc_url( $profile_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Complete profile', 'lnkup-marketplace' ); ?></a>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( ! $profile_id ) : ?>
				<div class="lnkup-alert lnkup-alert--warning"><?php esc_html_e( 'Complete your vendor profile to start applying.', 'lnkup-marketplace' ); ?> <a href="<?php echo esc_url( lnkup_page_url_helper( 'vendor-profile' ) ); ?>"><?php esc_html_e( 'Create profile', 'lnkup-marketplace' ); ?></a></div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Vendor notices banner.
	 *
	 * @param int $user_id User ID.
	 */
	private static function render_vendor_notices( $user_id ) {
		$notices = get_user_meta( $user_id, 'lnkup_vendor_notices', true );
		if ( ! is_array( $notices ) || ! $notices || ! class_exists( 'LNKup_Vendor_Invites' ) ) {
			return;
		}
		foreach ( array_slice( $notices, 0, 5 ) as $notice ) {
			$invite_id = absint( $notice['invite_id'] ?? 0 );
			if ( ! $invite_id ) {
				continue;
			}
			$token    = get_post_meta( $invite_id, '_lnkup_token', true );
			$event_id = (int) get_post_meta( $invite_id, '_lnkup_event_id', true );
			$link     = $token ? add_query_arg( 'invite', $token, lnkup_page_url_helper( 'opportunities' ) ) : lnkup_page_url_helper( 'opportunities' );
			?>
			<div class="lnkup-alert lnkup-alert--info">
				<strong><?php esc_html_e( 'Event invite', 'lnkup-marketplace' ); ?></strong>
				<?php if ( $event_id ) : ?> — <?php echo esc_html( get_the_title( $event_id ) ); ?><?php endif; ?>
				<a href="<?php echo esc_url( $link ); ?>" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary"><?php esc_html_e( 'View Invite', 'lnkup-marketplace' ); ?></a>
			</div>
			<?php
		}
	}

	/**
	 * Applications view.
	 */
	public static function render_applications() {
		$ctx          = LNKup_Vendor_Dashboard_Data::context();
		$applications = $ctx['applications'];
		$dashboard    = lnkup_page_url_helper( 'vendor-dashboard' );

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash" id="applications">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php echo esc_html( lnkup_copy( 'vendor_requests' ) ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Track every event you\'ve applied to in one place', 'lnkup-marketplace' ); ?></p>
			</header>

			<div class="lnkup-dash-tabs" role="tablist">
				<button type="button" class="lnkup-dash-tabs__btn is-active" data-app-tab="all"><?php esc_html_e( 'All', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-dash-tabs__btn" data-app-tab="active"><?php esc_html_e( 'Active', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-dash-tabs__btn" data-app-tab="action"><?php esc_html_e( 'Action needed', 'lnkup-marketplace' ); ?></button>
				<button type="button" class="lnkup-dash-tabs__btn" data-app-tab="past"><?php esc_html_e( 'Past', 'lnkup-marketplace' ); ?></button>
			</div>

			<div class="lnkup-panel lnkup-panel--flush">
				<?php if ( $applications ) : ?>
					<div class="lnkup-dash-table-wrap lnkup-dash-table-wrap--cards">
						<table class="lnkup-table lnkup-dash-table" id="lnkup-vendor-apps-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></th>
									<th><?php esc_html_e( 'Location', 'lnkup-marketplace' ); ?></th>
									<th><?php esc_html_e( 'Date', 'lnkup-marketplace' ); ?></th>
									<th><?php esc_html_e( 'Fee', 'lnkup-marketplace' ); ?></th>
									<th><?php esc_html_e( 'Status', 'lnkup-marketplace' ); ?></th>
									<th><?php esc_html_e( 'Action', 'lnkup-marketplace' ); ?></th>
								</tr>
							</thead>
							<tbody>
							<?php foreach ( $applications as $app ) : ?>
								<?php
								$meta    = LNKup_Vendor_Dashboard_Data::application_event_meta( $app );
								$status  = get_post_meta( $app->ID, '_lnkup_application_status', true );
								$tab     = LNKup_Vendor_Dashboard_Data::application_tab( $status );
								$payment = LNKup_Payments::get_for_application( $app->ID );
								?>
								<tr data-app-tab="<?php echo esc_attr( $tab ); ?>">
									<td data-label="<?php esc_attr_e( 'Event', 'lnkup-marketplace' ); ?>"><?php echo esc_html( $meta['event_title'] ); ?></td>
									<td data-label="<?php esc_attr_e( 'Location', 'lnkup-marketplace' ); ?>"><?php echo esc_html( trim( $meta['city'] . ( $meta['state'] ? ', ' . $meta['state'] : '' ) ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Date', 'lnkup-marketplace' ); ?>"><?php echo $meta['date'] ? esc_html( date_i18n( 'M j, Y', strtotime( $meta['date'] ) ) ) : '—'; ?></td>
									<td data-label="<?php esc_attr_e( 'Fee', 'lnkup-marketplace' ); ?>"><?php echo esc_html( lnkup_currency( $meta['fee'] ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Status', 'lnkup-marketplace' ); ?>"><span class="lnkup-status lnkup-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( LNKup_Vendor_Dashboard_Data::application_status_label( $status ) ); ?></span></td>
									<td data-label="<?php esc_attr_e( 'Action', 'lnkup-marketplace' ); ?>">
										<?php if ( $payment && 'pending' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) : ?>
											<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm lnkup-pay-btn" data-payment-id="<?php echo esc_attr( (string) $payment->ID ); ?>"><?php esc_html_e( 'Pay now', 'lnkup-marketplace' ); ?></button>
										<?php elseif ( in_array( $status, array( 'paid', 'completed' ), true ) ) : ?>
											<a href="<?php echo esc_url( add_query_arg( array( 'view' => 'operations', 'app' => $app->ID ), $dashboard ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View', 'lnkup-marketplace' ); ?></a>
										<?php else : ?>
											<a href="<?php echo esc_url( lnkup_page_url_helper( 'opportunities' ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View', 'lnkup-marketplace' ); ?></a>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php else : ?>
					<p class="lnkup-empty"><?php esc_html_e( 'No applications yet. Browse events to get started.', 'lnkup-marketplace' ); ?></p>
					<p><a href="<?php echo esc_url( lnkup_page_url_helper( 'opportunities' ) ); ?>" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Find Events', 'lnkup-marketplace' ); ?></a></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Event operations hub with per-booking sub-tabs.
	 */
	public static function render_operations() {
		LNKup_Capabilities::require_login();
		$ctx         = LNKup_Vendor_Dashboard_Data::context();
		$dashboard   = lnkup_page_url_helper( 'vendor-dashboard' );
		$paid_apps   = LNKup_Vendor_Dashboard_Data::confirmed_applications( $ctx['applications'] );
		$selected    = isset( $_GET['app'] ) ? absint( $_GET['app'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab         = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$valid_tabs  = array( 'overview', 'packet', 'readiness', 'map', 'support' );
		if ( ! in_array( $tab, $valid_tabs, true ) ) {
			$tab = 'overview';
		}
		if ( ! $selected && $paid_apps ) {
			$selected = $paid_apps[0]->ID;
		}
		$valid_ids = array_map( 'intval', wp_list_pluck( $paid_apps, 'ID' ) );
		if ( $selected && ! in_array( $selected, $valid_ids, true ) ) {
			$selected = $valid_ids[0] ?? 0;
		}
		$apps_url = add_query_arg( 'view', 'applications', $dashboard );
		$find_url = lnkup_page_url_helper( 'opportunities' );

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash lnkup-vendor-ops-page" id="operations">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Event Operations', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Packets, readiness, venue maps, and day-of support for confirmed bookings', 'lnkup-marketplace' ); ?></p>
			</header>

			<?php if ( ! $paid_apps ) : ?>
				<?php
				echo lnkup_empty_state(
					__( 'No confirmed events yet', 'lnkup-marketplace' ),
					__( 'Your event operations details will appear here once you\'re approved and paid for an event.', 'lnkup-marketplace' ),
					__( 'View applications', 'lnkup-marketplace' ),
					$apps_url
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
				<p class="lnkup-muted" style="margin-top:1rem;text-align:center;">
					<a href="<?php echo esc_url( $find_url ); ?>"><?php esc_html_e( 'Browse Find Events', 'lnkup-marketplace' ); ?></a>
				</p>
			<?php else : ?>
				<div class="lnkup-vendor-ops" id="lnkup-vendor-ops" data-app-id="<?php echo esc_attr( (string) $selected ); ?>">
					<?php if ( count( $paid_apps ) > 1 ) : ?>
						<label class="lnkup-vendor-ops__selector">
							<span class="lnkup-muted"><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></span>
							<select id="lnkup-vendor-ops-event-select" class="lnkup-input">
								<?php foreach ( $paid_apps as $app ) : ?>
									<?php $event_id = (int) get_post_meta( $app->ID, '_lnkup_event_id', true ); ?>
									<option value="<?php echo esc_attr( (string) $app->ID ); ?>"<?php selected( $selected, $app->ID ); ?>><?php echo esc_html( get_the_title( $event_id ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
					<?php endif; ?>

					<?php
					$checklist = class_exists( 'LNKup_Vendor_Readiness' ) ? LNKup_Vendor_Readiness::checklist( $selected ) : array( 'percent' => 0 );
					?>

					<nav class="lnkup-dash-subnav lnkup-vendor-ops__tabs" role="tablist">
						<?php
						$tabs = array(
							'overview'  => __( 'Overview', 'lnkup-marketplace' ),
							'packet'    => __( 'Packet', 'lnkup-marketplace' ),
							'readiness' => __( 'Readiness', 'lnkup-marketplace' ),
							'map'       => __( 'Venue map', 'lnkup-marketplace' ),
							'support'   => __( 'Support', 'lnkup-marketplace' ),
						);
						foreach ( $tabs as $key => $label ) :
							$tab_url = add_query_arg(
								array(
									'view' => 'operations',
									'app'  => $selected,
									'tab'  => $key,
								),
								$dashboard
							);
							$tab_badge = '';
							if ( 'readiness' === $key && ! empty( $checklist['percent'] ) ) {
								$tab_badge = '<span class="lnkup-dash-subnav__badge">' . esc_html( (string) $checklist['percent'] ) . '%</span>';
							}
							?>
							<a href="<?php echo esc_url( $tab_url ); ?>" class="lnkup-dash-subnav__link lnkup-vendor-ops__tab<?php echo $tab === $key ? ' is-active' : ''; ?>" role="tab" data-ops-tab="<?php echo esc_attr( $key ); ?>"<?php echo $tab === $key ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?><?php echo $tab_badge; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<?php endforeach; ?>
					</nav>

					<div class="lnkup-vendor-ops__panels">
						<?php
						$event_id = (int) get_post_meta( $selected, '_lnkup_event_id', true );
						$meta     = LNKup_Vendor_Dashboard_Data::application_event_meta( get_post( $selected ) );
						?>
						<div class="lnkup-vendor-ops__panel<?php echo 'overview' === $tab ? ' is-active' : ''; ?>" data-ops-panel="overview"<?php echo 'overview' !== $tab ? ' hidden' : ''; ?>>
							<div id="lnkup-vendor-ops-home" data-app-id="<?php echo esc_attr( (string) $selected ); ?>">
								<?php
								echo self::render_ops_overview( $selected, $ctx['user_id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</div>
						</div>
						<div class="lnkup-vendor-ops__panel<?php echo 'packet' === $tab ? ' is-active' : ''; ?>" data-ops-panel="packet"<?php echo 'packet' !== $tab ? ' hidden' : ''; ?>>
							<?php echo LNKup_Packets::render_interactive( $selected ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
						<div class="lnkup-vendor-ops__panel<?php echo 'readiness' === $tab ? ' is-active' : ''; ?>" data-ops-panel="readiness"<?php echo 'readiness' !== $tab ? ' hidden' : ''; ?>>
							<?php if ( class_exists( 'LNKup_Operations_Render' ) && class_exists( 'LNKup_Vendor_Readiness' ) ) : ?>
								<?php echo LNKup_Operations_Render::readiness_checklist( $checklist, $selected ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php endif; ?>
						</div>
						<div class="lnkup-vendor-ops__panel<?php echo 'map' === $tab ? ' is-active' : ''; ?>" data-ops-panel="map"<?php echo 'map' !== $tab ? ' hidden' : ''; ?>>
							<?php
							if ( class_exists( 'LNKup_Operations_Render' ) ) {
								$booths = class_exists( 'LNKup_Booths' ) ? LNKup_Booths::get_for_application( $selected ) : null;
								echo LNKup_Operations_Render::venue_map( $event_id, $booths ? array( $booths ) : null ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</div>
						<div class="lnkup-vendor-ops__panel<?php echo 'support' === $tab ? ' is-active' : ''; ?>" data-ops-panel="support"<?php echo 'support' !== $tab ? ' hidden' : ''; ?>>
							<div class="lnkup-panel lnkup-ops-support-panel" id="lnkup-vendor-support-panel" data-app-id="<?php echo esc_attr( (string) $selected ); ?>">
								<h3 class="lnkup-panel__title"><?php esc_html_e( 'Request support', 'lnkup-marketplace' ); ?></h3>
								<p class="lnkup-muted"><?php esc_html_e( 'Need help on event day? Send a message to the organizer operations team.', 'lnkup-marketplace' ); ?></p>
								<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-ops-support-open" data-app-id="<?php echo esc_attr( (string) $selected ); ?>"><?php esc_html_e( 'New request', 'lnkup-marketplace' ); ?></button>
								<div class="lnkup-ops-support-history" id="lnkup-vendor-support-history">
									<p class="lnkup-muted"><?php esc_html_e( 'Loading requests…', 'lnkup-marketplace' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Documents view wrapper.
	 */
	public static function render_documents() {
		return LNKup_Shortcodes::render_documents_manager();
	}

	/**
	 * Payments view wrapper.
	 */
	public static function render_payments() {
		return LNKup_Shortcodes::render_payments_dashboard( 'vendor' );
	}

	/**
	 * Vendor growth dashboard.
	 */
	public static function render_growth() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Capabilities::can_view_growth() ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Growth dashboard access required.', 'lnkup-marketplace' ) . '</p>';
		}
		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash lnkup-vendor-growth" id="growth">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Growth', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'Revenue, markets, and business performance', 'lnkup-marketplace' ); ?></p>
			</header>
			<?php echo LNKup_Growth_Render::vendor_shell(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Reviews view.
	 */
	public static function render_reviews() {
		$ctx        = LNKup_Vendor_Dashboard_Data::context();
		$profile_id = $ctx['profile_id'];

		ob_start();
		?>
		<div class="lnkup-mp lnkup-vendor-dash" id="reviews">
			<header class="lnkup-dash-header">
				<h1 class="lnkup-dash-header__title"><?php esc_html_e( 'Reviews', 'lnkup-marketplace' ); ?></h1>
				<p class="lnkup-dash-header__subtitle"><?php esc_html_e( 'What organizers say after working with you', 'lnkup-marketplace' ); ?></p>
			</header>

			<?php if ( $profile_id && class_exists( 'LNKup_Vendor_Reputation' ) ) : ?>
				<?php
				$rep     = LNKup_Vendor_Reputation::get( $profile_id );
				$reviews = LNKup_Vendor_Reviews::get_for_vendor( $profile_id, 20 );
				$avg     = (float) ( $rep['avg_rating'] ?? 0 );
				$count   = (int) ( $rep['review_count'] ?? count( $reviews ) );
				?>
				<div class="lnkup-panel lnkup-review-score">
					<div class="lnkup-review-score__main">
						<span class="lnkup-review-score__value"><?php echo esc_html( number_format( $avg, 1 ) ); ?></span>
						<?php echo LNKup_Reputation_Render::star_rating( $avg, $count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<p class="lnkup-muted"><?php printf( esc_html( _n( '%d review', '%d reviews', $count, 'lnkup-marketplace' ) ), $count ); ?></p>
					</div>
					<ul class="lnkup-reputation-card__metrics">
						<li><span><?php esc_html_e( 'Completed events', 'lnkup-marketplace' ); ?></span><strong><?php echo esc_html( (string) ( $rep['metrics']['completed_events'] ?? 0 ) ); ?></strong></li>
						<li><span><?php esc_html_e( 'Reliability score', 'lnkup-marketplace' ); ?></span><strong><?php echo esc_html( (string) ( $rep['score'] ?? '—' ) ); ?></strong></li>
					</ul>
				</div>

				<div class="lnkup-review-list">
					<?php if ( $reviews ) : ?>
						<?php foreach ( $reviews as $review ) : ?>
							<?php echo LNKup_Reputation_Render::review_card( $review ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endforeach; ?>
					<?php else : ?>
						<div class="lnkup-panel">
							<p class="lnkup-empty"><?php esc_html_e( 'No reviews yet. Complete events to collect organizer feedback.', 'lnkup-marketplace' ); ?></p>
						</div>
					<?php endif; ?>
				</div>
			<?php else : ?>
				<div class="lnkup-panel">
					<p class="lnkup-empty"><?php esc_html_e( 'Complete your vendor profile to receive reviews.', 'lnkup-marketplace' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render vendor operations overview with booth, parking, load-in, and QR subsection.
	 *
	 * @param int $app_id  Application ID.
	 * @param int $user_id Vendor user ID.
	 */
	private static function render_ops_overview( $app_id, $user_id ) {
		$home = class_exists( 'LNKup_Event_Operations' )
			? LNKup_Event_Operations::vendor_home_for_application( $app_id, $user_id )
			: array( 'has_event' => false );
		$checklist      = $home['readiness'] ?? ( class_exists( 'LNKup_Vendor_Readiness' ) ? LNKup_Vendor_Readiness::checklist( $app_id ) : array() );
		$meta           = LNKup_Vendor_Dashboard_Data::application_event_meta( get_post( $app_id ) );
		$payment        = class_exists( 'LNKup_Payments' ) ? LNKup_Payments::get_for_application( $app_id ) : null;
		$payment_status = '';
		if ( $payment instanceof WP_Post ) {
			$payment_status = (string) get_post_meta( $payment->ID, '_lnkup_payment_status', true );
		}
		$organizer = (int) get_post_meta( $app_id, '_lnkup_organizer_user_id', true );
		$org_user  = $organizer ? get_userdata( $organizer ) : null;
		$venue     = $meta['venue'] ?? '';
		$map_url   = ! empty( $meta['venue_address'] ) ? 'https://maps.google.com/?q=' . rawurlencode( $meta['venue_address'] ) : '';
		$dashboard = lnkup_page_url_helper( 'vendor-dashboard' );
		$ops_base  = add_query_arg( array( 'view' => 'operations', 'app' => $app_id ), $dashboard );
		$tier      = $checklist['tier'] ?? 'on_track';
		ob_start();
		?>
		<div class="lnkup-ops-vendor-home">
			<?php if ( ! empty( $checklist['next_action'] ) || ! empty( $checklist['pending_top'] ) ) : ?>
				<div class="lnkup-ops-next-steps">
					<h4 class="lnkup-ops-next-steps__title"><?php esc_html_e( 'Next steps', 'lnkup-marketplace' ); ?></h4>
					<ul class="lnkup-ops-next-steps__list">
						<?php if ( ! empty( $checklist['next_action']['label'] ) ) : ?>
							<?php
							$na_url = add_query_arg( array( 'tab' => $checklist['next_action']['tab'] ?? 'readiness' ), $ops_base );
							if ( ! empty( $checklist['next_action']['section'] ) ) {
								$na_url = add_query_arg( 'section', $checklist['next_action']['section'], $na_url );
							}
							?>
							<li><a href="<?php echo esc_url( $na_url ); ?>"><?php echo esc_html( $checklist['next_action']['label'] ); ?></a></li>
						<?php endif; ?>
						<?php
						$extra = array_slice( $checklist['pending_top'] ?? array(), 1, 2 );
						foreach ( $extra as $item ) :
							if ( empty( $item['label'] ) ) {
								continue;
							}
							$item_url = add_query_arg( array( 'tab' => $item['cta_tab'] ?? 'readiness' ), $ops_base );
							if ( ! empty( $item['cta_section'] ) ) {
								$item_url = add_query_arg( 'section', $item['cta_section'], $item_url );
							}
							?>
							<li><a href="<?php echo esc_url( $item_url ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
			<article class="lnkup-ops-vendor-card lnkup-ops-vendor-card--hero">
				<h3><?php echo esc_html( $home['event_title'] ?? $meta['event_title'] ); ?></h3>
				<?php if ( ! empty( $home['event_date'] ) || ! empty( $meta['date'] ) ) : ?>
					<p class="lnkup-muted"><?php echo esc_html( date_i18n( 'l, F j, Y', strtotime( $home['event_date'] ?? $meta['date'] ) ) ); ?><?php echo ! empty( $meta['start_time'] ) ? ' · ' . esc_html( $meta['start_time'] ) : ''; ?></p>
				<?php endif; ?>
				<?php if ( $venue ) : ?>
					<p class="lnkup-muted"><?php echo esc_html( $venue ); ?></p>
				<?php endif; ?>
				<div class="lnkup-ops-vendor-card__chips">
					<span class="lnkup-badge lnkup-badge--readiness lnkup-badge--<?php echo esc_attr( $tier ); ?>"><?php printf( esc_html__( '%d%% ready', 'lnkup-marketplace' ), (int) ( $home['readiness_percent'] ?? 0 ) ); ?></span>
					<?php if ( $payment_status ) : ?>
						<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( ucfirst( $payment_status ) ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $home['packet_status'] ) ) : ?>
						<span class="lnkup-badge lnkup-badge--accent"><?php echo esc_html( $home['packet_status'] ); ?></span>
					<?php endif; ?>
				</div>
				<?php if ( ! empty( $home['countdown_label'] ) ) : ?>
					<p class="lnkup-ops-vendor-card__countdown"><?php echo esc_html( $home['countdown_label'] ); ?></p>
				<?php endif; ?>
				<?php if ( $org_user ) : ?>
					<p class="lnkup-muted">
						<?php esc_html_e( 'Organizer contact:', 'lnkup-marketplace' ); ?>
						<?php
						$show_name = $org_user->display_name && strtolower( $org_user->display_name ) !== strtolower( $org_user->user_email );
						if ( $show_name ) {
							echo esc_html( $org_user->display_name );
							if ( $org_user->user_email ) {
								echo ' · ';
							}
						}
						if ( $org_user->user_email ) {
							echo esc_html( $org_user->user_email );
						}
						?>
					</p>
				<?php endif; ?>
				<?php if ( $map_url ) : ?>
					<p><a class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open map', 'lnkup-marketplace' ); ?></a></p>
				<?php endif; ?>
				<button type="button" class="lnkup-btn lnkup-btn--outline lnkup-btn--sm lnkup-ops-support-open" data-app-id="<?php echo esc_attr( (string) $app_id ); ?>"><?php esc_html_e( 'Request help', 'lnkup-marketplace' ); ?></button>
			</article>
			<div class="lnkup-ops-overview-grid">
				<div class="lnkup-ops-panel lnkup-ops-panel--status<?php echo ! empty( $home['booth'] ) ? ' is-complete' : ''; ?>">
					<h4 class="lnkup-ops-panel__title"><span class="lnkup-ops-panel__icon" aria-hidden="true"><?php echo ! empty( $home['booth'] ) ? '✓' : '○'; ?></span><?php esc_html_e( 'Booth assignment', 'lnkup-marketplace' ); ?></h4>
					<?php if ( ! empty( $home['booth'] ) ) : ?>
						<p><strong><?php echo esc_html( $home['booth']['booth_number'] ?? '' ); ?></strong></p>
						<p class="lnkup-muted"><?php echo esc_html( $home['booth']['booth_type_label'] ?? '' ); ?><?php echo ! empty( $home['booth']['booth_size'] ) ? ' · ' . esc_html( $home['booth']['booth_size'] ) : ''; ?></p>
						<?php if ( ! empty( $home['booth']['has_power'] ) || ! empty( $home['booth']['has_water'] ) ) : ?>
							<p class="lnkup-muted">
								<?php
								$amenities = array();
								if ( ! empty( $home['booth']['has_power'] ) ) {
									$amenities[] = __( 'Power', 'lnkup-marketplace' );
								}
								if ( ! empty( $home['booth']['has_water'] ) ) {
									$amenities[] = __( 'Water', 'lnkup-marketplace' );
								}
								echo esc_html( implode( ' · ', $amenities ) );
								?>
							</p>
						<?php endif; ?>
						<p><a href="<?php echo esc_url( add_query_arg( 'tab', 'map', $ops_base ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'View on map', 'lnkup-marketplace' ); ?></a></p>
					<?php else : ?>
						<p class="lnkup-muted"><?php esc_html_e( 'Booth not assigned yet. Check your packet for updates.', 'lnkup-marketplace' ); ?></p>
						<p><a href="<?php echo esc_url( add_query_arg( array( 'tab' => 'packet', 'section' => 'booth' ), $ops_base ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Open packet', 'lnkup-marketplace' ); ?></a></p>
					<?php endif; ?>
				</div>
				<div class="lnkup-ops-panel lnkup-ops-panel--status<?php echo ! empty( $home['parking'] ) ? ' is-complete' : ''; ?>">
					<h4 class="lnkup-ops-panel__title"><span class="lnkup-ops-panel__icon" aria-hidden="true"><?php echo ! empty( $home['parking'] ) ? '✓' : '○'; ?></span><?php esc_html_e( 'Parking', 'lnkup-marketplace' ); ?></h4>
					<?php if ( ! empty( $home['parking'] ) ) : ?>
						<p><strong><?php echo esc_html( $home['parking']['label'] ?? '' ); ?></strong></p>
						<?php if ( ! empty( $home['parking']['gate'] ) ) : ?>
							<p class="lnkup-muted"><?php echo esc_html( sprintf( __( 'Gate: %s', 'lnkup-marketplace' ), $home['parking']['gate'] ) ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $home['parking']['instructions'] ) ) : ?>
							<p class="lnkup-muted"><?php echo esc_html( $home['parking']['instructions'] ); ?></p>
						<?php endif; ?>
					<?php else : ?>
						<p class="lnkup-muted"><?php esc_html_e( 'Parking details will appear when assigned.', 'lnkup-marketplace' ); ?></p>
						<p><a href="<?php echo esc_url( add_query_arg( array( 'tab' => 'packet', 'section' => 'parking' ), $ops_base ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Open packet', 'lnkup-marketplace' ); ?></a></p>
					<?php endif; ?>
				</div>
				<div class="lnkup-ops-panel lnkup-ops-panel--status<?php echo ! empty( $home['loadin'] ) ? ' is-complete' : ''; ?>">
					<h4 class="lnkup-ops-panel__title"><span class="lnkup-ops-panel__icon" aria-hidden="true"><?php echo ! empty( $home['loadin'] ) ? '✓' : '○'; ?></span><?php esc_html_e( 'Load-in', 'lnkup-marketplace' ); ?></h4>
					<?php if ( ! empty( $home['loadin'] ) ) : ?>
						<p><strong><?php echo esc_html( $home['loadin']['label'] ?? '' ); ?></strong></p>
						<?php if ( ! empty( $home['loadin']['gate'] ) ) : ?>
							<p class="lnkup-muted"><?php echo esc_html( sprintf( __( 'Gate: %s', 'lnkup-marketplace' ), $home['loadin']['gate'] ) ); ?></p>
						<?php endif; ?>
					<?php else : ?>
						<p class="lnkup-muted"><?php esc_html_e( 'Load-in window not scheduled yet.', 'lnkup-marketplace' ); ?></p>
						<p><a href="<?php echo esc_url( add_query_arg( array( 'tab' => 'packet', 'section' => 'loadin' ), $ops_base ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Open packet', 'lnkup-marketplace' ); ?></a></p>
					<?php endif; ?>
				</div>
				<?php if ( ! empty( $home['emergency'] ) && is_array( $home['emergency'] ) ) : ?>
					<div class="lnkup-ops-panel">
						<h4 class="lnkup-ops-panel__title"><?php esc_html_e( 'Emergency contacts', 'lnkup-marketplace' ); ?></h4>
						<ul class="lnkup-ops-emergency-list">
							<?php foreach ( array_slice( $home['emergency'], 0, 4 ) as $contact ) : ?>
								<li>
									<strong><?php echo esc_html( $contact['name'] ?? $contact['label'] ?? '' ); ?></strong>
									<?php if ( ! empty( $contact['phone'] ) ) : ?>
										<span class="lnkup-muted"><?php echo esc_html( $contact['phone'] ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $home['qr_pass'] ) ) : ?>
					<div class="lnkup-ops-panel lnkup-ops-panel--qr">
						<h4 class="lnkup-ops-panel__title"><?php esc_html_e( 'Check-in QR pass', 'lnkup-marketplace' ); ?></h4>
						<p class="lnkup-muted"><?php esc_html_e( 'Show this at vendor check-in.', 'lnkup-marketplace' ); ?></p>
						<div class="lnkup-ops-qr lnkup-ops-qr--compact" data-qr="<?php echo esc_attr( $home['qr_pass'] ); ?>"></div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}
