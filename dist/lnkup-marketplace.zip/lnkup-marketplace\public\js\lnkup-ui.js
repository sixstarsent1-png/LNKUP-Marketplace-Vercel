/**
 * LNKup shared dashboard UI utilities.
 */
(function (window) {
  'use strict';

  var copy = window.lnkupUiCopy || {};

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  function t(key, fallback) {
    return copy[key] || fallback || key;
  }

  /**
   * Safe JSON fetch with content-type validation.
   */
  function fetchJson(url, options) {
    options = options || {};
    var nonce = (window.lnkupAjax && window.lnkupAjax.restNonce) || '';
    var headers = Object.assign({ 'X-WP-Nonce': nonce }, options.headers || {});
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    return fetch(url, Object.assign({ credentials: 'same-origin', headers: headers }, options))
      .then(function (response) {
        var contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          return response.text().then(function (text) {
            console.error('[LNKupUI] Expected JSON:', text.slice(0, 300));
            throw new Error(t('panel_error', 'Invalid server response.'));
          });
        }
        return response.json().then(function (body) {
          if (!response.ok) {
            var message = (body && (body.message || body.code)) || t('panel_error', 'Request failed.');
            throw new Error(message);
          }
          return body;
        });
      })
      .catch(function (err) {
        console.error('[LNKupUI]', url, err);
        throw err;
      });
  }

  function panelSkeleton(el, count) {
    if (!el) {
      return;
    }
    var n = count || 3;
    var html = '';
    for (var i = 0; i < n; i++) {
      html += '<div class="lnkup-skeleton lnkup-skeleton--card" aria-hidden="true"></div>';
    }
    el.innerHTML = html;
  }

  function panelEmpty(el, opts) {
    if (!el) {
      return;
    }
    opts = opts || {};
    var compact = opts.compact ? ' lnkup-empty-state--compact' : '';
    var cta = '';
    if (opts.ctaLabel && opts.ctaHref) {
      cta = '<div class="lnkup-empty-state__actions"><a href="' + escapeHtml(opts.ctaHref) +
        '" class="lnkup-btn lnkup-btn--primary">' + escapeHtml(opts.ctaLabel) + '</a></div>';
    } else if (opts.ctaLabel && typeof opts.onCta === 'function') {
      cta = '<div class="lnkup-empty-state__actions"><button type="button" class="lnkup-btn lnkup-btn--primary lnkup-ui-empty-cta">' +
        escapeHtml(opts.ctaLabel) + '</button></div>';
    }
    el.innerHTML = '<div class="lnkup-empty-state' + compact + '">' +
      '<p class="lnkup-empty-state__title">' + escapeHtml(opts.title || '') + '</p>' +
      (opts.desc ? '<p class="lnkup-empty-state__desc">' + escapeHtml(opts.desc) + '</p>' : '') +
      cta + '</div>';
    if (opts.onCta) {
      var btn = el.querySelector('.lnkup-ui-empty-cta');
      if (btn) {
        btn.addEventListener('click', opts.onCta);
      }
    }
  }

  function panelError(el, opts) {
    if (!el) {
      return;
    }
    opts = opts || {};
    var retry = '';
    if (opts.onRetry) {
      retry = '<div class="lnkup-empty-state__actions"><button type="button" class="lnkup-btn lnkup-btn--outline lnkup-ui-retry">' +
        escapeHtml(t('retry', 'Try again')) + '</button></div>';
    }
    el.innerHTML = '<div class="lnkup-alert lnkup-alert--error lnkup-panel-state--error">' +
      '<p class="lnkup-empty-state__title">' + escapeHtml(opts.title || t('panel_error', 'We couldn\'t load this section.')) + '</p>' +
      (opts.desc ? '<p class="lnkup-empty-state__desc">' + escapeHtml(opts.desc) + '</p>' : '') +
      retry + '</div>';
    if (opts.onRetry) {
      var btn = el.querySelector('.lnkup-ui-retry');
      if (btn) {
        btn.addEventListener('click', opts.onRetry);
      }
    }
    el.dataset.loaded = '1';
  }

  function panelMessage(el, type, title, desc) {
    if (!el) {
      return;
    }
    if (type === 'error') {
      panelError(el, { title: title, desc: desc });
      return;
    }
    panelEmpty(el, { title: title, desc: desc, compact: true });
  }

  window.LNKupUI = {
    escapeHtml: escapeHtml,
    t: t,
    fetchJson: fetchJson,
    panelSkeleton: panelSkeleton,
    panelEmpty: panelEmpty,
    panelError: panelError,
    panelMessage: panelMessage
  };
})(window);
