(function () {
  function showToast(message, type) {
    var toast = document.createElement('div');
    toast.className = 'lnkup-toast lnkup-toast--' + (type || 'success');
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(function () {
      toast.classList.add('is-visible');
    });
    setTimeout(function () {
      toast.classList.remove('is-visible');
      setTimeout(function () { toast.remove(); }, 300);
    }, 4000);
  }

  window.lnkupShowToast = showToast;

  function postForm(form) {
    var data = new FormData(form);
    if (!data.get('lnkup_nonce') && window.lnkupAjax) {
      data.append('lnkup_nonce', window.lnkupAjax.nonce);
    }
    return fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
      .then(function (r) { return r.json(); });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.classList.contains('lnkup-profile-form') &&
        !form.classList.contains('lnkup-apply-form') &&
        !form.classList.contains('lnkup-event-form') &&
        !form.classList.contains('lnkup-opportunity-form')) {
      if (form.classList.contains('lnkup-document-form')) {
        e.preventDefault();
        postForm(form).then(function (res) {
          var docMsg = (res.data && res.data.message) ? res.data.message : (res.success ? 'Document saved.' : 'Upload failed.');
          showToast(docMsg, res.success ? 'success' : 'error');
          if (res.success) location.reload();
        });
      }
      return;
    }
    e.preventDefault();
    postForm(form).then(function (res) {
      var msg = (res.data && res.data.message) ? res.data.message : (res.success ? 'Saved.' : 'Error');
      if (form.classList.contains('lnkup-apply-form')) {
        if (res.success) {
          if (window.lnkupCloseApplyModal) {
            window.lnkupCloseApplyModal();
          }
          showToast(msg, 'success');
        } else {
          showToast(msg, 'error');
        }
        return;
      }
      if (form.classList.contains('lnkup-opportunity-form')) {
        if (res.success) {
          var oppSuccess = document.getElementById('lnkup-create-opportunity-success');
          if (oppSuccess) {
            oppSuccess.innerHTML = '<p class="lnkup-alert lnkup-alert--success">' + msg + '</p>';
            oppSuccess.hidden = false;
          }
          showToast(msg, 'success');
          form.reset();
        } else {
          showToast(msg, 'error');
        }
        return;
      }
      if (form.classList.contains('lnkup-event-form') && res.success && res.data) {
        var data = res.data;
        var successEl = document.getElementById('lnkup-create-event-success');
        if (successEl) {
          var links = '';
          if (data.view_event_url) {
            links += '<a class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost" href="' + data.view_event_url + '">View event</a> ';
          }
          if (data.manage_applications_url) {
            links += '<a class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost" href="' + data.manage_applications_url + '">Manage applications</a> ';
          }
          if (data.find_events_url) {
            links += '<a class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" href="' + data.find_events_url + '">View in Find Events</a>';
          }
          successEl.innerHTML = '<p class="lnkup-alert lnkup-alert--success">' + (data.message || msg) + '</p><div class="lnkup-create-event-success__links">' + links + '</div>';
          successEl.hidden = false;
          form.reset();
          showToast(data.message || msg, 'success');
          return;
        }
        if (data.find_events_url) {
          var extra = data.indexed === false
            ? '\n\nNote: listing may take a moment to appear. Rebuild the marketplace index in LNKup Settings if needed.'
            : '';
          alert((data.message || msg) + extra);
          if (data.indexed !== false) {
            window.location.href = data.find_events_url;
          }
          return;
        }
      }
      alert(msg);
      if (res.success && !form.classList.contains('lnkup-opportunity-form')) location.reload();
    }).catch(function () {
      showToast('Something went wrong. Please try again.', 'error');
    });
  });

  document.addEventListener('click', function (e) {
    var payBtn = e.target.closest('.lnkup-pay-btn');
    if (payBtn && window.lnkupCheckout && window.lnkupCheckout.open) {
      e.preventDefault();
      window.lnkupCheckout.open(payBtn.getAttribute('data-payment-id'));
      return;
    }
    if (payBtn) {
      var paymentId = payBtn.getAttribute('data-payment-id');
      var data = new FormData();
      data.append('action', 'lnkup_create_checkout');
      data.append('payment_id', paymentId);
      data.append('lnkup_nonce', window.lnkupAjax.nonce);
      data.append('mode', 'embedded');
      fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res.success && res.data.url) {
            window.location.href = res.data.url;
          } else if (!window.lnkupCheckout) {
            alert(res.data && res.data.message ? res.data.message : 'Payment error');
          }
        });
      return;
    }

    var reviewBtn = e.target.closest('.lnkup-review-btn');
    if (reviewBtn) {
      var appId = reviewBtn.getAttribute('data-app-id');
      var action = reviewBtn.getAttribute('data-action');
      var data = new FormData();
      data.append('action', 'lnkup_review_application');
      data.append('application_id', appId);
      data.append('review_action', action);
      data.append('lnkup_nonce', window.lnkupAjax.reviewNonce || window.lnkupAjax.nonce);
      if (action === 'reject') {
        var reason = prompt('Rejection reason (optional):');
        if (reason) data.append('rejection_reason', reason);
      }
      fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          var reviewMsg = (res.data && res.data.message) ? res.data.message : (res.success ? 'Application updated.' : 'Action failed.');
          showToast(reviewMsg, res.success ? 'success' : 'error');
          if (res.success) location.reload();
        });
    }
  });

  /**
   * Sync sticky publish summary on the create-event wizard.
   */
  function syncPublishSummary() {
    var categoryEl = document.getElementById('vendor_category');
    var spotsEl = document.getElementById('event_spots_total');
    var feeEl = document.getElementById('event_vendor_fee');
    var categoryOut = document.getElementById('lnkup-publish-category-count');
    var spotsOut = document.getElementById('lnkup-publish-spots-count');
    var feeOut = document.getElementById('lnkup-publish-fee-summary');
    var docsOut = document.getElementById('lnkup-publish-docs-count');
    var oppToggle = document.getElementById('lnkup_publish_opportunity_toggle');
    var oppField = document.getElementById('lnkup_create_opportunity_field');
    var oppFields = document.getElementById('lnkup-create-event-opportunity-fields');
    var submitBtn = document.getElementById('lnkup-create-event-submit');
    var publishOpp = !oppToggle || oppToggle.checked;
    if (oppField) {
      oppField.value = publishOpp ? '1' : '0';
    }
    if (oppFields) {
      oppFields.hidden = !publishOpp;
    }
    if (submitBtn) {
      submitBtn.textContent = publishOpp ? 'Publish event & opportunity' : 'Publish event';
    }
    if (categoryOut && categoryEl) {
      categoryOut.textContent = publishOpp ? (categoryEl.value || 'Any') : '—';
    }
    if (spotsOut && spotsEl) {
      spotsOut.textContent = publishOpp ? (spotsEl.value || '0') : '—';
    }
    if (feeOut && feeEl) {
      var fee = parseFloat(feeEl.value || '0');
      feeOut.textContent = publishOpp ? ('$' + (isNaN(fee) ? '0.00' : fee.toFixed(2))) : '—';
    }
    if (docsOut) {
      var checked = document.querySelectorAll('#lnkup-create-event-form input[name="required_documents[]"]:checked');
      docsOut.textContent = publishOpp ? String(checked.length) : '—';
    }
  }

  /**
   * Detect ticketing platform from import URL.
   */
  function detectImportPlatform(url) {
    var host = '';
    try {
      host = new URL(url).hostname.toLowerCase();
    } catch (err) {
      return 'Manual';
    }
    if (host.indexOf('eventbrite') !== -1) return 'Eventbrite';
    if (host.indexOf('posh') !== -1) return 'Posh';
    if (host.indexOf('universe') !== -1) return 'Universe';
    return 'Manual';
  }

  /**
   * Show import preview card after URL validation.
   */
  function runImportPreview() {
    var createPanel = document.getElementById('lnkup-create-panel');
    var input = createPanel ? createPanel.querySelector('#ticketing_url_import') : document.getElementById('ticketing_url_import');
    var loading = createPanel ? createPanel.querySelector('#lnkup-import-loading') : document.getElementById('lnkup-import-loading');
    var preview = createPanel ? createPanel.querySelector('#lnkup-import-preview') : document.getElementById('lnkup-import-preview');
    var platformSelect = createPanel ? createPanel.querySelector('#ticketing_platform') : document.getElementById('ticketing_platform');
    var hiddenUrl = createPanel ? createPanel.querySelector('#lnkup_create_event_ticketing_url') : document.getElementById('lnkup_create_event_ticketing_url');
    var importDetails = createPanel ? createPanel.querySelector('.lnkup-organizer-import-collapse') : null;
    if (!input || !loading || !preview) {
      return;
    }
    var url = (input.value || '').trim();
    if (!url) {
      showToast('Enter a ticketing URL first.', 'error');
      return;
    }
    preview.hidden = true;
    loading.hidden = false;
    setTimeout(function () {
      loading.hidden = true;
      var platform = detectImportPlatform(url);
      if (platformSelect) {
        platformSelect.value = platform;
      }
      if (hiddenUrl) {
        hiddenUrl.value = url;
      }
      preview.innerHTML = '<p class="lnkup-import-preview__title">Import ready</p>' +
        '<p class="lnkup-import-preview__meta">Source: <strong>' + platform + '</strong></p>' +
        '<p class="lnkup-import-preview__meta">' + url + '</p>' +
        '<p class="lnkup-muted">Complete the event form below — your ticketing URL is saved.</p>';
      preview.hidden = false;
      if (importDetails && !importDetails.open) {
        importDetails.open = true;
      }
      setCreateMode('new');
      showToast('Ticketing link recognized.', 'success');
    }, 900);
  }

  /**
   * Switch unified create panel between new event and add-to-existing modes.
   */
  function setCreateMode(mode) {
    var newMode = document.getElementById('lnkup-create-mode-new');
    var existingMode = document.getElementById('lnkup-create-mode-existing');
    document.querySelectorAll('[data-create-mode]').forEach(function (btn) {
      var active = btn.getAttribute('data-create-mode') === mode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    if (newMode) {
      newMode.classList.toggle('is-active', mode === 'new');
      newMode.hidden = mode !== 'new';
    }
    if (existingMode) {
      existingMode.classList.toggle('is-active', mode === 'existing');
      existingMode.hidden = mode !== 'existing';
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    var createPanel = document.getElementById('lnkup-create-panel');
    var createForm = createPanel ? createPanel.querySelector('#lnkup-create-event-form') : document.getElementById('lnkup-create-event-form');
    if (createForm) {
      createForm.addEventListener('input', syncPublishSummary);
      createForm.addEventListener('change', syncPublishSummary);
      syncPublishSummary();
    }
    var oppToggle = createPanel ? createPanel.querySelector('#lnkup_publish_opportunity_toggle') : document.getElementById('lnkup_publish_opportunity_toggle');
    if (oppToggle) {
      oppToggle.addEventListener('change', syncPublishSummary);
    }
    document.querySelectorAll('[data-create-mode]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        setCreateMode(btn.getAttribute('data-create-mode') || 'new');
      });
    });
    var initialMode = document.documentElement.getAttribute('data-lnkup-create-mode');
    var params = new URLSearchParams(window.location.search);
    if (params.get('mode') === 'existing') {
      initialMode = 'existing';
    }
    if (initialMode === 'existing') {
      setCreateMode('existing');
    }
    var previewBtn = createPanel ? createPanel.querySelector('#lnkup-import-preview-btn') : document.getElementById('lnkup-import-preview-btn');
    if (previewBtn) {
      previewBtn.addEventListener('click', runImportPreview);
    }
    var importInput = createPanel ? createPanel.querySelector('#ticketing_url_import') : document.getElementById('ticketing_url_import');
    if (importInput) {
      importInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          runImportPreview();
        }
      });
    }
    var importedUrl = params.get('import_url');
    var hiddenUrl = createPanel ? createPanel.querySelector('#lnkup_create_event_ticketing_url') : document.getElementById('lnkup_create_event_ticketing_url');
    if (importedUrl && hiddenUrl) {
      hiddenUrl.value = importedUrl;
      if (importInput) {
        importInput.value = importedUrl;
      }
      var importDetails = createPanel ? createPanel.querySelector('.lnkup-organizer-import-collapse') : null;
      if (importDetails) {
        importDetails.open = true;
      }
    }
  });
})();
