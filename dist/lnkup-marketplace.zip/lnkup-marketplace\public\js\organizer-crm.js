(function () {
  var ajax = window.lnkupAjax || {};
  var base = ajax.crmRestUrl || '';
  var nonce = ajax.restNonce || '';

  /**
   * Surface toast feedback when marketplace helper is loaded.
   */
  function toast(message, type) {
    if (window.lnkupShowToast) {
      window.lnkupShowToast(message, type || 'success');
    }
  }

  /**
   * Resilient CRM REST fetch with JSON parsing and error propagation.
   */
  function crmFetchJson(path, options) {
    options = options || {};
    if (!base) {
      return Promise.reject(new Error('CRM REST not configured'));
    }
    var headers = { 'X-WP-Nonce': nonce };
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    return fetch(base + path, Object.assign({ credentials: 'same-origin', headers: headers }, options))
      .then(function (r) {
        return r.json().then(function (body) {
          if (!r.ok) {
            var err = new Error((body && body.message) || 'Request failed');
            err.body = body;
            err.status = r.status;
            throw err;
          }
          return body;
        });
      });
  }

  function crmFetch(path, options) {
    return crmFetchJson(path, options).catch(function (err) {
      console.error('[LNKup CRM]', path, err);
      throw err;
    });
  }

  /**
   * Render a friendly empty or error panel.
   */
  function panelMessage(el, type, title, desc) {
    if (window.LNKupUI) {
      LNKupUI.panelMessage(el, type, title, desc);
      return;
    }
    if (!el) {
      return;
    }
    var cls = type === 'error' ? 'lnkup-alert lnkup-alert--error' : 'lnkup-empty-state lnkup-empty-state--compact';
    el.innerHTML = '<div class="' + cls + '"><p class="lnkup-empty-state__title">' + escapeHtml(title) + '</p>' +
      (desc ? '<p class="lnkup-empty-state__desc">' + escapeHtml(desc) + '</p>' : '') + '</div>';
  }

  /**
   * Debounce utility for search input.
   */
  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments;
      var ctx = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(ctx, args); }, ms);
    };
  }

  /**
   * Highlight dashboard nav link for current hash.
   */
  function syncHashNav() {
    var hash = (window.location.hash || '').replace(/^#/, '');
    if (window.location.pathname.indexOf('organizer-dashboard') > -1) {
      if (hash === 'payments') {
        hash = 'financial';
      } else if (hash === 'import' || hash === 'create-event' || hash === 'create-opportunity') {
        if (hash === 'create-opportunity') {
          document.documentElement.setAttribute('data-lnkup-create-mode', 'existing');
        }
        hash = 'create';
      }
    }
    if (!hash) {
      return;
    }
    document.querySelectorAll('.lnkup-dashboard__nav-link[data-hash]').forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('data-hash') === hash);
    });
    document.querySelectorAll('.lnkup-dashboard__bottom-link[data-hash]').forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('data-hash') === hash);
    });
  }

  var crmState = { scope: 'discover', view: 'card', q: '', sort: 'score' };

  /**
   * Load vendor directory into #lnkup-crm-directory.
   */
  function loadDirectory() {
    var el = document.getElementById('lnkup-crm-directory');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    var qs = '?scope=' + encodeURIComponent(crmState.scope) +
      '&view=' + encodeURIComponent(crmState.view) +
      '&q=' + encodeURIComponent(crmState.q) +
      '&sort=' + encodeURIComponent(crmState.sort);
    crmFetchJson('/vendors' + qs).then(function (res) {
      if (res && res.code) {
        panelMessage(el, 'error', 'Could not load directory', res.message || '');
        return;
      }
      if (res && res.html) {
        el.innerHTML = res.html;
        var moreBtn = document.getElementById('lnkup-crm-directory-more');
        if (moreBtn) {
          var cardCount = el.querySelectorAll('.lnkup-crm-card, .lnkup-vendor-card').length;
          moreBtn.hidden = cardCount <= 6;
          el.classList.toggle('lnkup-crm-directory--limited', cardCount > 6);
          el.classList.remove('lnkup-crm-directory--expanded');
        }
        return;
      }
      panelMessage(el, 'empty', 'No vendors found', 'Try adjusting search or filters.');
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load directory', 'Please refresh and try again.');
    });
  }

  /**
   * Render CRM dashboard widgets.
   */
  function loadWidgets() {
    var grid = document.getElementById('lnkup-crm-widgets-grid');
    var activity = document.getElementById('lnkup-crm-activity');
    if (!grid || !base) {
      return;
    }
    crmFetchJson('/dashboard/widgets').then(function (data) {
      if (!data || data.code) {
        panelMessage(grid, 'empty', 'No activity yet', 'Widgets will appear when you have applications and vendor relationships.');
        return;
      }
      var html = '';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--pending"><h3>Pending Applications</h3><p class="lnkup-crm-widget__value">' + (data.pending_applications || 0) + '</p></div>';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--favorites"><h3>Favorites</h3><p class="lnkup-crm-widget__value">' + (data.favorites_count || 0) + '</p></div>';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--preferred"><h3>Preferred</h3><p class="lnkup-crm-widget__value">' + (data.preferred_count || 0) + '</p></div>';
      grid.innerHTML = html;

      if (activity) {
        var actHtml = '';
        if (data.recent_notes && data.recent_notes.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Recent Notes</h3><ul class="lnkup-crm-widget-list">';
          data.recent_notes.forEach(function (n) {
            actHtml += '<li>' + escapeHtml(n.content) + ' <span class="lnkup-muted">' + escapeHtml(n.date) + '</span></li>';
          });
          actHtml += '</ul></div>';
        }
        if (data.upcoming_rosters && data.upcoming_rosters.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Upcoming Rosters</h3>';
          data.upcoming_rosters.forEach(function (r) {
            var url = (ajax.organizerDashboardUrl || '') + '?event=' + r.event_id + '&roster=1';
            actHtml += '<div class="lnkup-crm-roster-row"><a href="' + escapeHtml(url) + '">' + escapeHtml(r.title) + '</a><span class="lnkup-crm-roster-row__chip">' + r.total + ' vendors</span></div>';
          });
          actHtml += '</div>';
        }
        if (data.rebook_recommendations && data.rebook_recommendations.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Rebook Recommendations</h3><ul class="lnkup-crm-widget-list">';
          data.rebook_recommendations.forEach(function (v) {
            var url = (ajax.organizerDashboardUrl || '') + '?vendor=' + v.profile_id;
            actHtml += '<li><a href="' + escapeHtml(url) + '">' + escapeHtml(v.business_name) + '</a></li>';
          });
          actHtml += '</ul></div>';
        }
        if (actHtml) {
          activity.innerHTML = actHtml;
          activity.hidden = false;
        } else {
          activity.hidden = true;
          activity.innerHTML = '';
        }
      }
    }).catch(function () {
      panelMessage(grid, 'error', 'Could not load activity', 'CRM data is temporarily unavailable.');
    });
  }

  /**
   * Load saved vendor lists.
   */
  function loadLists() {
    var el = document.getElementById('lnkup-crm-lists');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    crmFetchJson('/lists').then(function (res) {
      var items = (res && res.items) ? res.items : [];
      var summary = document.getElementById('lnkup-organizer-lists-summary');
      if (summary) {
        if (!items.length) {
          summary.textContent = 'No lists yet. Create one to organize vendors.';
        } else {
          var first = items[0];
          summary.textContent = items.length === 1
            ? first.name + ' (' + (first.count || 0) + ' vendors)'
            : items.length + ' lists · latest: ' + first.name;
        }
      }
      if (!items.length) {
        panelMessage(el, 'empty', 'No lists yet', 'Create a list to save vendor segments for future events.');
        return;
      }
      var html = '<div class="lnkup-crm-list-grid">';
      items.forEach(function (list) {
        html += '<article class="lnkup-crm-list-card" data-list-id="' + list.id + '">';
        html += '<strong>' + escapeHtml(list.name) + '</strong>';
        html += '<p class="lnkup-crm-list-card__count">' + (list.count || 0) + '</p>';
        html += '<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-crm-list-delete" data-list-id="' + list.id + '">Delete</button>';
        html += '</article>';
      });
      html += '</div>';
      el.innerHTML = html;
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load lists', 'Please refresh and try again.');
    });
  }

  /**
   * Status pill class for invite status.
   */
  function inviteStatusClass(status) {
    var s = (status || '').toLowerCase();
    if (s.indexOf('accept') > -1) {
      return 'lnkup-status-pill--accent';
    }
    if (s.indexOf('open') > -1 || s.indexOf('sent') > -1) {
      return 'lnkup-status-pill--muted';
    }
    return '';
  }

  /**
   * Load organizer invites.
   */
  function loadInvites() {
    var el = document.getElementById('lnkup-crm-invites');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    crmFetchJson('/invites/list').then(function (res) {
      var items = (res && res.items) ? res.items : [];
      var summary = document.getElementById('lnkup-organizer-invites-summary');
      if (summary) {
        if (!items.length) {
          summary.textContent = 'No invites sent yet.';
        } else {
          summary.textContent = items.length === 1
            ? '1 invite sent'
            : items.length + ' invites sent';
        }
      }
      if (!items.length) {
        panelMessage(el, 'empty', 'No invites sent yet', 'Invite vendors from the directory or vendor profiles.');
        return;
      }
      var html = '';
      items.forEach(function (inv) {
        var link = inv.link || inv.invite_link || '';
        html += '<article class="lnkup-crm-invite-card">';
        html += '<div class="lnkup-crm-invite-card__header"><strong>' + escapeHtml(inv.vendor) + '</strong>';
        html += '<span class="lnkup-status-pill ' + inviteStatusClass(inv.status) + '">' + escapeHtml(inv.status || 'sent') + '</span></div>';
        html += '<p class="lnkup-muted">' + escapeHtml(inv.type || '') + ' · ' + escapeHtml(inv.created || '') + '</p>';
        html += '<div class="lnkup-crm-card__actions">';
        if (link) {
          html += '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost lnkup-crm-copy-invite" data-link="' + escapeHtml(link) + '">Copy link</button>';
        }
        if (inv.id && link) {
          html += '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline lnkup-crm-resend-invite" data-link="' + escapeHtml(link) + '">Resend link</button>';
        }
        html += '</div></article>';
      });
      el.innerHTML = html;
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load invites', 'Please refresh and try again.');
    });
  }

  /**
   * Update compare toolbar visibility and count.
   */
  function updateCompareBar() {
    var bar = document.getElementById('lnkup-crm-compare-bar');
    var countEl = document.getElementById('lnkup-crm-compare-count');
    if (!bar || !countEl) {
      return;
    }
    var checked = document.querySelectorAll('.lnkup-crm-compare-pick:checked');
    var n = checked.length;
    bar.hidden = n < 2;
    countEl.textContent = n + (n === 1 ? ' selected' : ' selected');
  }

  /**
   * Filter application cards by tab selection.
   */
  function filterApplications(filter) {
    var cards = document.querySelectorAll('.lnkup-crm-app-card');
    var visible = 0;
    cards.forEach(function (card) {
      var show = filter === 'all';
      if (!show && filter === 'pending') {
        show = card.getAttribute('data-org-app-filter') === 'pending';
      } else if (!show && filter === 'approved') {
        show = card.getAttribute('data-org-app-filter') === 'approved' || card.getAttribute('data-org-app-status') === 'paid' || card.getAttribute('data-org-app-status') === 'completed';
      } else if (!show && filter === 'waitlisted') {
        show = card.getAttribute('data-org-app-status') === 'waitlisted';
      } else if (!show && filter === 'rejected') {
        show = card.getAttribute('data-org-app-status') === 'rejected';
      } else if (!show && filter === 'unpaid') {
        show = card.getAttribute('data-org-app-paid') === 'no' && (card.getAttribute('data-org-app-status') === 'approved' || card.getAttribute('data-org-app-status') === 'payment_required');
      } else if (!show && filter === 'missing_docs') {
        show = card.getAttribute('data-org-app-docs') === 'missing';
      }
      card.hidden = !show;
      if (show) {
        visible++;
      }
    });
    var grid = document.getElementById('lnkup-app-intel-grid');
    var empty = document.getElementById('lnkup-app-filter-empty');
    if (grid && filter !== 'all' && visible === 0) {
      if (!empty) {
        empty = document.createElement('p');
        empty.id = 'lnkup-app-filter-empty';
        empty.className = 'lnkup-muted';
        grid.appendChild(empty);
      }
      empty.textContent = 'No applications match this filter.';
      empty.hidden = false;
    } else if (empty) {
      empty.hidden = true;
    }
  }

  /**
   * Escape HTML for safe insertion.
   */
  function escapeHtml(str) {
    if (!str) {
      return '';
    }
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /**
   * Open compare modal for selected application IDs.
   */
  function openCompare(ids) {
    if (ids.length < 2) {
      alert('Select at least 2 applications to compare.');
      return;
    }
    crmFetch('/applications/compare?ids=' + ids.join(',')).then(function (res) {
      var items = (res && res.items) ? res.items : [];
      var modal = document.getElementById('lnkup-crm-compare-modal');
      if (!modal) {
        modal = document.createElement('div');
        modal.id = 'lnkup-crm-compare-modal';
        modal.className = 'lnkup-crm-modal';
        modal.innerHTML = '<div class="lnkup-crm-modal__inner"><button type="button" class="lnkup-crm-modal__close">&times;</button><div id="lnkup-crm-compare-body"></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function (e) {
          if (e.target === modal || e.target.classList.contains('lnkup-crm-modal__close')) {
            modal.hidden = true;
          }
        });
      }
      var body = document.getElementById('lnkup-crm-compare-body');
      var html = '<h2>Compare Applicants</h2><table class="lnkup-table lnkup-crm-compare-table"><thead><tr><th>Field</th>';
      items.forEach(function (p) {
        html += '<th>' + escapeHtml(p.business_name) + '</th>';
      });
      html += '</tr></thead><tbody>';
      var fields = [
        ['Score', 'vendor_score'],
        ['Rating', 'avg_rating'],
        ['Reviews', 'review_count'],
        ['City', 'city'],
        ['Events', 'completed_events'],
        ['Message', 'application_message']
      ];
      fields.forEach(function (pair) {
        html += '<tr><td>' + escapeHtml(pair[0]) + '</td>';
        items.forEach(function (p) {
          html += '<td>' + escapeHtml(String(p[pair[1]] != null ? p[pair[1]] : '—')) + '</td>';
        });
        html += '</tr>';
      });
      html += '</tbody></table>';
      body.innerHTML = html;
      modal.hidden = false;
    });
  }

  /**
   * Send invite to vendor from profile page.
   */
  function sendInvite(vendorUserId) {
    var oppId = prompt('Opportunity ID (optional):');
    var message = prompt('Personal message (optional):');
    crmFetch('/invites', {
      method: 'POST',
      body: {
        vendor_user_id: parseInt(vendorUserId, 10),
        opportunity_id: oppId ? parseInt(oppId, 10) : 0,
        message: message || '',
        type: 'apply'
      }
    }).then(function (res) {
      if (res && res.link) {
        toast('Invite sent.');
        loadInvites();
      } else if (res && res.code) {
        toast(res.message || 'Could not send invite.', 'error');
      } else {
        toast('Invite sent.');
        loadInvites();
      }
    });
  }

  /**
   * Respond to vendor invite token on opportunities page.
   */
  function bindInviteBanner() {
    var banner = document.getElementById('lnkup-invite-banner');
    if (!banner || !base) {
      return;
    }
    var token = banner.getAttribute('data-token');
    var acceptBtn = document.getElementById('lnkup-invite-accept');
    var declineBtn = document.getElementById('lnkup-invite-decline');
    function respond(accept) {
      crmFetch('/invites/respond', { method: 'POST', body: { token: token, accept: accept } }).then(function (res) {
        if (res && res.success) {
          banner.innerHTML = '<p class="lnkup-alert lnkup-alert--success">' + (accept ? 'Invite accepted!' : 'Invite declined.') + '</p>';
        } else {
          alert((res && res.message) ? res.message : 'Could not update invite.');
        }
      });
    }
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () { respond(true); });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () { respond(false); });
    }
  }

  /**
   * Roster bulk action handler.
   */
  function rosterBulk(action, eventId) {
    var ids = [];
    document.querySelectorAll('.lnkup-roster-pick:checked').forEach(function (cb) {
      ids.push(parseInt(cb.value, 10));
    });
    if (!ids.length) {
      alert('Select at least one vendor.');
      return;
    }
    crmFetch('/events/' + eventId + '/roster/bulk', {
      method: 'POST',
      body: { action: action, application_ids: ids }
    }).then(function () {
      location.reload();
    });
  }

  /**
   * Single roster action for one application.
   */
  function rosterSingle(action, appId) {
    var rosterEl = document.getElementById('lnkup-event-roster');
    if (!rosterEl || !base) {
      return;
    }
    crmFetch('/events/' + rosterEl.getAttribute('data-event-id') + '/roster/bulk', {
      method: 'POST',
      body: { action: action, application_ids: [parseInt(appId, 10)] }
    }).then(function () {
      location.reload();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    syncHashNav();
    window.addEventListener('hashchange', syncHashNav);

    if (document.getElementById('lnkup-organizer-crm')) {
      loadWidgets();
      var hash = (window.location.hash || '').replace(/^#/, '');
      var vendorsPanel = document.getElementById('lnkup-organizer-expand-vendors');
      var vendorsOpen = hash === 'vendors' || (vendorsPanel && !vendorsPanel.hidden);
      if (vendorsOpen) {
        loadDirectory();
      }
      loadLists();
      loadInvites();
    }

    var directoryMore = document.getElementById('lnkup-crm-directory-more');
    if (directoryMore) {
      directoryMore.addEventListener('click', function () {
        var dir = document.getElementById('lnkup-crm-directory');
        if (dir) {
          dir.classList.add('lnkup-crm-directory--expanded');
        }
        directoryMore.hidden = true;
      });
    }

    document.addEventListener('click', function (e) {
      var priorityTrigger = e.target.closest('[data-org-app-filter-trigger]');
      if (priorityTrigger) {
        e.preventDefault();
        window.location.hash = 'applications';
        document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn').forEach(function (b) {
          b.classList.toggle('is-active', b.getAttribute('data-org-app-filter') === 'missing_docs');
        });
        filterApplications('missing_docs');
      }
    });

    bindInviteBanner();

    document.querySelectorAll('[data-org-app-filter]').forEach(function (btn) {
      if (btn.tagName !== 'BUTTON' || !btn.classList.contains('lnkup-dash-tabs__btn')) {
        return;
      }
      btn.addEventListener('click', function () {
        document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn[data-org-app-filter]').forEach(function (b) {
          b.classList.remove('is-active');
        });
        btn.classList.add('is-active');
        filterApplications(btn.getAttribute('data-org-app-filter') || 'all');
      });
    });

    var moreFiltersBtn = document.querySelector('[data-org-app-filter-toggle]');
    var extraFilters = document.getElementById('lnkup-org-app-filters-extra');
    if (moreFiltersBtn && extraFilters) {
      moreFiltersBtn.addEventListener('click', function () {
        var expanded = moreFiltersBtn.getAttribute('aria-expanded') === 'true';
        moreFiltersBtn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
        extraFilters.hidden = expanded;
      });
    }

    document.querySelectorAll('[data-org-app-layout]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var layout = btn.getAttribute('data-org-app-layout') || 'grid';
        document.querySelectorAll('[data-org-app-layout]').forEach(function (b) {
          b.classList.toggle('is-active', b === btn);
        });
        var grid = document.querySelector('.lnkup-crm-app-grid--v2');
        if (grid) {
          grid.classList.toggle('lnkup-crm-app-grid--list', layout === 'list');
        }
      });
    });

    document.addEventListener('change', function (e) {
      if (e.target && e.target.classList && e.target.classList.contains('lnkup-crm-compare-pick')) {
        updateCompareBar();
      }
    });

    var compareClear = document.getElementById('lnkup-crm-compare-clear');
    if (compareClear) {
      compareClear.addEventListener('click', function () {
        document.querySelectorAll('.lnkup-crm-compare-pick:checked').forEach(function (cb) {
          cb.checked = false;
        });
        updateCompareBar();
      });
    }

    updateCompareBar();

    var searchInput = document.getElementById('lnkup-crm-vendor-search');
    if (searchInput) {
      searchInput.addEventListener('input', debounce(function (e) {
        crmState.q = e.target.value;
        loadDirectory();
      }, 350));
    }

    var sortSelect = document.getElementById('lnkup-crm-vendor-sort');
    if (sortSelect) {
      sortSelect.addEventListener('change', function (e) {
        crmState.sort = e.target.value;
        loadDirectory();
      });
    }

    document.addEventListener('click', function (e) {
      var smartBtn = e.target.closest('.lnkup-smart-list');
      if (smartBtn) {
        var appFilter = smartBtn.getAttribute('data-org-app-filter');
        if (appFilter) {
          window.location.hash = 'applications';
          document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn').forEach(function (b) {
            b.classList.toggle('is-active', b.getAttribute('data-org-app-filter') === appFilter);
          });
          filterApplications(appFilter);
          return;
        }
        var scope = smartBtn.getAttribute('data-crm-scope');
        var sort = smartBtn.getAttribute('data-crm-sort');
        if (scope) {
          crmState.scope = scope;
          document.querySelectorAll('[data-crm-scope]').forEach(function (b) {
            if (b.hasAttribute('data-crm-scope') && b.classList.contains('lnkup-btn')) {
              b.classList.toggle('is-active', b.getAttribute('data-crm-scope') === scope);
            }
          });
        }
        if (sort) {
          crmState.sort = sort;
          var sortEl = document.getElementById('lnkup-crm-vendor-sort');
          if (sortEl) {
            sortEl.value = sort;
          }
        }
        window.location.hash = 'vendors';
        loadDirectory();
        return;
      }

      var copyBtn = e.target.closest('.lnkup-crm-copy-invite');
      if (copyBtn && copyBtn.getAttribute('data-link')) {
        var link = copyBtn.getAttribute('data-link');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(link).then(function () {
            copyBtn.textContent = 'Copied!';
            toast('Invite link copied.');
          });
        } else {
          prompt('Copy invite link:', link);
        }
        return;
      }

      var resendBtn = e.target.closest('.lnkup-crm-resend-invite');
      if (resendBtn) {
        var resendLink = resendBtn.getAttribute('data-link');
        if (resendLink && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(resendLink).then(function () {
            resendBtn.textContent = 'Link copied';
            toast('Invite link copied.');
          });
        } else if (resendLink) {
          prompt('Copy invite link:', resendLink);
        }
        return;
      }

      var scopeBtn = e.target.closest('[data-crm-scope]');
      if (scopeBtn && scopeBtn.classList.contains('lnkup-btn')) {
        document.querySelectorAll('[data-crm-scope]').forEach(function (b) {
          if (b.classList.contains('lnkup-btn')) {
            b.classList.remove('is-active');
          }
        });
        scopeBtn.classList.add('is-active');
        crmState.scope = scopeBtn.getAttribute('data-crm-scope');
        loadDirectory();
        return;
      }

      var viewBtn = e.target.closest('[data-crm-view]');
      if (viewBtn) {
        document.querySelectorAll('[data-crm-view]').forEach(function (b) { b.classList.remove('is-active'); });
        viewBtn.classList.add('is-active');
        crmState.view = viewBtn.getAttribute('data-crm-view');
        loadDirectory();
        return;
      }

      var newListBtn = document.getElementById('lnkup-crm-new-list');
      if (e.target === newListBtn || e.target.closest('#lnkup-crm-new-list')) {
        var name = prompt('List name:');
        if (!name) {
          return;
        }
        crmFetch('/lists', { method: 'POST', body: { name: name } }).then(function () {
          toast('List created.');
          loadLists();
        });
        return;
      }

      var delList = e.target.closest('.lnkup-crm-list-delete');
      if (delList) {
        var listId = delList.getAttribute('data-list-id');
        if (confirm('Delete this list?')) {
          crmFetch('/lists/' + listId, { method: 'DELETE' }).then(function () { loadLists(); });
        }
        return;
      }

      var favBtn = e.target.closest('.lnkup-crm-fav');
      if (favBtn) {
        var pid = favBtn.getAttribute('data-profile-id');
        crmFetch('/vendors/' + pid + '/favorite', { method: 'POST' }).then(function (res) {
          favBtn.textContent = (res && res.is_favorite) ? '★ Favorite' : '☆ Favorite';
          toast((res && res.is_favorite) ? 'Added to favorites.' : 'Removed from favorites.');
        });
        return;
      }

      var prefBtn = e.target.closest('.lnkup-crm-pref');
      if (prefBtn) {
        var profileId = prefBtn.getAttribute('data-profile-id') || prefBtn.closest('[data-profile-id]') && prefBtn.closest('[data-profile-id]').getAttribute('data-profile-id');
        if (!profileId) {
          profileId = document.getElementById('lnkup-crm-profile') && document.getElementById('lnkup-crm-profile').getAttribute('data-profile-id');
        }
        if (profileId) {
          crmFetch('/vendors/' + profileId + '/preferred', { method: 'POST' }).then(function () {
            prefBtn.classList.toggle('is-active');
          });
        }
        return;
      }

      var inviteBtn = e.target.closest('.lnkup-crm-invite');
      if (inviteBtn) {
        sendInvite(inviteBtn.getAttribute('data-vendor-id'));
        return;
      }

      var compareOpen = e.target.closest('#lnkup-crm-compare-open');
      if (compareOpen) {
        var ids = [];
        document.querySelectorAll('.lnkup-crm-compare-pick:checked').forEach(function (cb) {
          ids.push(cb.value);
        });
        openCompare(ids);
        return;
      }

      var checkin = e.target.closest('.lnkup-crm-checkin');
      if (checkin) {
        var appId = checkin.getAttribute('data-app-id');
        crmFetch('/applications/' + appId + '/check-in', { method: 'POST' }).then(function () {
          location.reload();
        });
        return;
      }

      var noshow = e.target.closest('.lnkup-crm-noshow');
      if (noshow) {
        var app = noshow.getAttribute('data-app-id');
        crmFetch('/applications/' + app + '/no-show', { method: 'POST' }).then(function () {
          location.reload();
        });
        return;
      }

      var lateBtn = e.target.closest('.lnkup-crm-late');
      if (lateBtn) {
        rosterSingle('late_arrival', lateBtn.getAttribute('data-app-id'));
        return;
      }

      var bulkBtn = e.target.closest('[data-roster-bulk]');
      if (bulkBtn) {
        var rosterEl = document.getElementById('lnkup-event-roster');
        if (rosterEl) {
          rosterBulk(bulkBtn.getAttribute('data-roster-bulk'), rosterEl.getAttribute('data-event-id'));
        }
        return;
      }
    });

    var selectAll = document.getElementById('lnkup-roster-select-all');
    if (selectAll) {
      selectAll.addEventListener('change', function () {
        document.querySelectorAll('.lnkup-roster-pick').forEach(function (cb) {
          cb.checked = selectAll.checked;
        });
      });
    }

    var noteForm = document.getElementById('lnkup-crm-note-form');
    if (noteForm) {
      noteForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var profileEl = document.getElementById('lnkup-crm-profile');
        var profileId = profileEl && profileEl.getAttribute('data-profile-id');
        var input = document.getElementById('lnkup-crm-note-input');
        if (!profileId || !input || !input.value.trim()) {
          return;
        }
        crmFetch('/vendors/' + profileId + '/notes', {
          method: 'POST',
          body: { content: input.value.trim() }
        }).then(function (res) {
          if (res && res.id) {
            var list = document.getElementById('lnkup-crm-notes-list');
            var li = document.createElement('li');
            li.textContent = input.value.trim();
            list.appendChild(li);
            input.value = '';
          }
        });
      });
    }

    var profileRoot = document.getElementById('lnkup-crm-profile');
    if (profileRoot) {
      var pref = profileRoot.querySelector('.lnkup-crm-pref');
      if (pref && !pref.getAttribute('data-profile-id')) {
        pref.setAttribute('data-profile-id', profileRoot.getAttribute('data-profile-id'));
      }
    }

    var dashSearchForm = document.getElementById('lnkup-dashboard-search-form');
    var dashSearchInput = document.getElementById('lnkup-dashboard-crm-search');
    if (dashSearchForm && dashSearchInput) {
      dashSearchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        crmState.q = dashSearchInput.value.trim();
        var vendorSearch = document.getElementById('lnkup-crm-vendor-search');
        if (vendorSearch) {
          vendorSearch.value = crmState.q;
        }
        window.location.hash = 'vendors';
        syncHashNav();
        loadDirectory();
      });
      var params = new URLSearchParams(window.location.search);
      if (params.get('crm_q')) {
        dashSearchInput.value = params.get('crm_q');
        crmState.q = params.get('crm_q');
        var crmVendorSearch = document.getElementById('lnkup-crm-vendor-search');
        if (crmVendorSearch) {
          crmVendorSearch.value = crmState.q;
        }
      }
    }
  });

  window.lnkupCrmLoadDirectory = loadDirectory;
})();
