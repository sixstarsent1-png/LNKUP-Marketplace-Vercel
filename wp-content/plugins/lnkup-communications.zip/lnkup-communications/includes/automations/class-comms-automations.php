<?php
/**
 * Automation hub: wires scheduled automations and describes them for the admin.
 *
 * @package LNKup_Communications
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

class LNKup_Comms_Automations {

	public static function init(): void {
		LNKup_Comms_Health::init();
		LNKup_Comms_Auto_Onboarding::init();
		LNKup_Comms_Auto_Discovery::init();
		LNKup_Comms_Auto_Countdown::init();
		LNKup_Comms_Auto_Digests::init();
		LNKup_Comms_Auto_Retention::init();
	}

	/**
	 * Catalog for the admin Automations screen.
	 */
	public static function catalog(): array {
		return array(
			array( 'key' => 'applications', 'label' => __( 'Application lifecycle', 'lnkup-communications' ), 'flag' => 'flow_applications', 'schedule' => __( 'Event-driven', 'lnkup-communications' ), 'audience' => __( 'Vendors + organizers', 'lnkup-communications' ), 'triggers' => array( 'v_application_submitted', 'v_application_approved', 'v_application_rejected', 'v_application_waitlisted', 'v_info_requested', 'v_application_withdrawn', 'v_application_cancelled', 'o_application_received', 'o_applications_grouped', 'o_info_response', 'o_application_withdrawn', 'o_waitlist_spot' ), 'locked' => false, 'rule' => __( 'Fires on lnkup_application_* hooks. First application per event is immediate; later ones are grouped per burst window and recounted at send time.', 'lnkup-communications' ) ),
			array( 'key' => 'payments', 'label' => __( 'Payments & bookings', 'lnkup-communications' ), 'flag' => 'flow_payments', 'schedule' => __( 'Event-driven + 72h/24h before payment deadline', 'lnkup-communications' ), 'audience' => __( 'Vendors + owning organizer', 'lnkup-communications' ), 'triggers' => array( 'v_payment_reminder', 'v_payment_failed', 'v_booking_confirmed', 'v_receipt_available', 'v_refund_completed', 'o_vendor_paid', 'o_vendor_payment_failed', 'o_refund_completed', 'o_dispute_opened', 'o_chargeback_closed' ), 'locked' => false, 'rule' => __( 'Only verified server outcomes (webhooks, Financial Service). Reminders cancel on payment and re-check payment status before sending.', 'lnkup-communications' ) ),
			array( 'key' => 'documents', 'label' => __( 'Documents & compliance', 'lnkup-communications' ), 'flag' => 'flow_documents', 'schedule' => __( 'Event-driven + daily expiry check', 'lnkup-communications' ), 'audience' => __( 'Vendors', 'lnkup-communications' ), 'triggers' => array( 'v_documents_needed', 'v_document_approved', 'v_document_rejected', 'v_document_expiring' ), 'locked' => false, 'rule' => __( 'Only documents required by the opportunity. Suppressed once nothing is missing.', 'lnkup-communications' ) ),
			array( 'key' => 'operations', 'label' => __( 'Event operations', 'lnkup-communications' ), 'flag' => 'flow_operations', 'schedule' => __( 'Event-driven', 'lnkup-communications' ), 'audience' => __( 'Booked vendors + organizer', 'lnkup-communications' ), 'triggers' => array( 'v_pass_updated', 'v_booth_assigned', 'v_logistics_changed', 'v_event_cancelled', 'v_checked_in', 'o_checkin_summary' ), 'locked' => true, 'rule' => __( 'Cancellations are critical and bypass category opt-outs. Check-ins are summarized every 15 minutes for organizers.', 'lnkup-communications' ) ),
			array( 'key' => 'countdown', 'label' => __( 'Event countdown', 'lnkup-communications' ), 'flag' => 'flow_countdown', 'schedule' => __( 'Hourly scan: vendors 14d/7d/72h/24h/morning, organizers 30d/14d/7d/72h/24h/morning', 'lnkup-communications' ), 'audience' => __( 'Confirmed vendors + organizer', 'lnkup-communications' ), 'triggers' => array( 'v_countdown', 'o_countdown' ), 'locked' => false, 'rule' => __( 'Prepared vendors only get 7d, 24h and morning reminders; vendors with missing items get every window with the exact missing items.', 'lnkup-communications' ) ),
			array( 'key' => 'onboarding', 'label' => __( 'Onboarding sequences', 'lnkup-communications' ), 'flag' => 'flow_onboarding', 'schedule' => __( 'Vendors: welcome, 24h, 72h, 7d. Organizers: day 0, 1, 3, 7', 'lnkup-communications' ), 'audience' => __( 'New accounts only', 'lnkup-communications' ), 'triggers' => array( 'v_welcome', 'v_onboarding', 'o_welcome', 'o_onboarding', 'o_event_published' ), 'locked' => false, 'rule' => __( 'Each reminder names the exact next step and is suppressed once that step is done.', 'lnkup-communications' ) ),
			array( 'key' => 'digests', 'label' => __( 'Digests & summaries', 'lnkup-communications' ), 'flag' => 'flow_digests', 'schedule' => __( 'Daily and weekly at the digest hour', 'lnkup-communications' ), 'audience' => __( 'Users who chose daily/weekly; organizers with upcoming events', 'lnkup-communications' ), 'triggers' => array( 'digest_email', 'o_ops_summary', 'o_pending_review' ), 'locked' => false, 'rule' => __( 'One grouped email per user. Pending-review reminders only when applications have waited longer than the configured hours.', 'lnkup-communications' ) ),
			array( 'key' => 'post_event', 'label' => __( 'Post-event follow-ups', 'lnkup-communications' ), 'flag' => 'flow_post_event', 'schedule' => __( 'After check-out or the day after the event', 'lnkup-communications' ), 'audience' => __( 'Vendors + organizer', 'lnkup-communications' ), 'triggers' => array( 'v_event_thanks', 'o_event_completed' ), 'locked' => false, 'rule' => __( 'One wrap-up per event for organizers with final counts.', 'lnkup-communications' ) ),
			array( 'key' => 'discovery', 'label' => __( 'Opportunity matching', 'lnkup-communications' ), 'flag' => 'flow_discovery', 'schedule' => __( '10 minutes after an opportunity opens', 'lnkup-communications' ), 'audience' => __( 'Matching vendors who have not applied', 'lnkup-communications' ), 'triggers' => array( 'v_opportunity_match', 'v_organizer_new_opportunity' ), 'locked' => false, 'rule' => __( 'Uses the lnkup-marketplace match engine when enabled (else category + city/state served). Promotional: capped, digest by default, honours opt-outs.', 'lnkup-communications' ) ),
			array( 'key' => 'recruitment', 'label' => __( 'Vendor recruitment', 'lnkup-communications' ), 'flag' => 'flow_recruitment', 'schedule' => __( '1 hour after an event goes live', 'lnkup-communications' ), 'audience' => __( 'Organizer', 'lnkup-communications' ), 'triggers' => array( 'o_recruit_vendors' ), 'locked' => false, 'rule' => __( 'Shows a vendor count only when real matching public profiles exist; no vendor identities are disclosed.', 'lnkup-communications' ) ),
			array( 'key' => 'retention', 'label' => __( 'Organizer retention', 'lnkup-communications' ), 'flag' => 'flow_retention', 'schedule' => __( 'Daily', 'lnkup-communications' ), 'audience' => __( 'Organizers', 'lnkup-communications' ), 'triggers' => array( 'o_no_applications', 'o_publish_next', 'o_reactivation' ), 'locked' => false, 'rule' => __( 'Recurring cadence is suggested only after 3+ events with a regular interval.', 'lnkup-communications' ) ),
		);
	}
}
