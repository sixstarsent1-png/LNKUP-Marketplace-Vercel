(function () {
  var ajax = window.lnkupAjax || {};
  var base = ajax.crmRestUrl || '';
  var nonce = ajax.restNonce || '';

  function toast(message, type) {
    if (window.lnkupShowToast) {
      window.lnkupShowToast(message, type || 'success');
    }
  }

  function crmFetchJson(path, options) {
    options = options || {};
    if (!base) {
      return Promise.reject(new Error('CRM REST not configured'));
    }
    var headers = { 'X-WP-Nonce': nonce };
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    return fetch(base + path, Object.assign({ credentials: 'same-origin', headers: headers }, options))
      .then(function (r) {
        return r.json().then(function (body) {
          if (!r.ok) {
            var err = new Error((body && body.message) || 'Request failed');
            err.body = body;
            err.status = r.status;
            throw err;
          }
          return body;
        });
      });
  }

  function crmFetch(path, options) {
    return crmFetchJson(path, options).catch(function (err) {
      console.error('[LNKup CRM]', path, err);
      throw err;
    });
  }

  function panelMessage(el, type, title, desc) {
    if (window.LNKupUI) {
      LNKupUI.panelMessage(el, type, title, desc);
      return;
    }
    if (!el) {
      return;
    }
    var cls = type === 'error' ? 'lnkup-alert lnkup-alert--error' : 'lnkup-empty-state lnkup-empty-state--compact';
    el.innerHTML = '<div class="' + cls + '"><p class="lnkup-empty-state__title">' + escapeHtml(title) + '</p>' +
      (desc ? '<p class="lnkup-empty-state__desc">' + escapeHtml(desc) + '</p>' : '') + '</div>';
  }

  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments;
      var ctx = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(ctx, args); }, ms);
    };
  }

  function syncHashNav() {
    var hash = (window.location.hash || '').replace(/^#/, '');
    if (window.location.pathname.indexOf('organizer-dashboard') > -1) {
      if (hash === 'payments') {
        hash = 'financial';
      } else if (hash === 'import' || hash === 'create-event' || hash === 'create-opportunity') {
        if (hash === 'create-opportunity') {
          document.documentElement.setAttribute('data-lnkup-create-mode', 'existing');
        }
        hash = 'create';
      }
    }
    if (!hash) {
      return;
    }
    document.querySelectorAll('.lnkup-dashboard__nav-link[data-hash]').forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('data-hash') === hash);
    });
    document.querySelectorAll('.lnkup-dashboard__bottom-link[data-hash]').forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('data-hash') === hash);
    });
  }

  var crmState = { scope: 'discover', view: 'card', q: '', sort: 'score', city: '', category: '', verified: '' };
  var inviteOptionsCache = null;
  var listsCache = [];

  function loadDirectory() {
    var el = document.getElementById('lnkup-crm-directory');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    var qs = '?scope=' + encodeURIComponent(crmState.scope) +
      '&view=' + encodeURIComponent(crmState.view) +
      '&q=' + encodeURIComponent(crmState.q) +
      '&sort=' + encodeURIComponent(crmState.sort) +
      '&city=' + encodeURIComponent(crmState.city) +
      '&category=' + encodeURIComponent(crmState.category) +
      (crmState.verified ? '&verified=1' : '');
    crmFetchJson('/vendors' + qs).then(function (res) {
      if (res && res.code) {
        panelMessage(el, 'error', 'Could not load directory', res.message || '');
        return;
      }
      if (res && res.html) {
        el.innerHTML = res.html;
        var moreBtn = document.getElementById('lnkup-crm-directory-more');
        if (moreBtn) {
          var cardCount = el.querySelectorAll('.lnkup-crm-card, .lnkup-vendor-card').length;
          moreBtn.hidden = cardCount <= 6;
          el.classList.toggle('lnkup-crm-directory--limited', cardCount > 6);
          el.classList.remove('lnkup-crm-directory--expanded');
        }
        return;
      }
      panelMessage(el, 'empty', 'No vendors found', 'Try adjusting search or filters.');
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load directory', 'Please refresh and try again.');
    });
  }

  function loadWidgets() {
    var grid = document.getElementById('lnkup-crm-widgets-grid');
    var activity = document.getElementById('lnkup-crm-activity');
    if (!grid || !base) {
      return;
    }
    var copy = (window.lnkupAjax && window.lnkupAjax.copy) || {};
    crmFetchJson('/dashboard/widgets').then(function (data) {
      if (!data || data.code) {
        panelMessage(grid, 'empty', copy.empty_activity || 'No activity yet', 'Widgets will appear when you have applications and vendor relationships.');
        return;
      }
      var html = '';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--pending lnkup-micro-lift"><h3>Pending reviews</h3><p class="lnkup-crm-widget__value">' + (data.pending_applications || 0) + '</p></div>';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--favorites lnkup-micro-lift"><h3>Favorites</h3><p class="lnkup-crm-widget__value">' + (data.favorites_count || 0) + '</p></div>';
      html += '<div class="lnkup-crm-widget lnkup-crm-widget--preferred lnkup-micro-lift"><h3>Preferred</h3><p class="lnkup-crm-widget__value">' + (data.preferred_count || 0) + '</p></div>';
      grid.innerHTML = html;

      var discoverHero = document.querySelector('#vendors .lnkup-executive-hero');
      if (discoverHero) {
        var metricEls = discoverHero.querySelectorAll('.lnkup-executive-hero__metric strong');
        if (metricEls[0]) metricEls[0].textContent = String(data.favorites_count || 0);
        if (metricEls[1]) metricEls[1].textContent = String(data.preferred_count || 0);
      }

      if (activity) {
        var actBody = activity.querySelector('.lnkup-organizer-activity__body') || activity;
        var actHtml = '';
        if (data.activity_feed && data.activity_feed.length) {
          actHtml += '<ul class="lnkup-organizer-activity-feed" data-testid="lnkup-organizer-activity-feed">';
          data.activity_feed.forEach(function (row) {
            var when = row.created_at ? new Date(row.created_at).toLocaleString() : '';
            var label = (row.activity_type || 'activity').replace(/_/g, ' ');
            actHtml += '<li class="lnkup-organizer-activity-feed__item"><span>' + escapeHtml(label) + '</span><span class="lnkup-muted">' + escapeHtml(when) + '</span></li>';
          });
          actHtml += '</ul>';
        }
        if (data.recent_notes && data.recent_notes.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Recent Notes</h3><ul class="lnkup-crm-widget-list">';
          data.recent_notes.forEach(function (n) {
            actHtml += '<li>' + escapeHtml(n.content) + ' <span class="lnkup-muted">' + escapeHtml(n.date) + '</span></li>';
          });
          actHtml += '</ul></div>';
        }
        if (data.upcoming_rosters && data.upcoming_rosters.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Upcoming Rosters</h3>';
          data.upcoming_rosters.forEach(function (r) {
            var url = (ajax.organizerDashboardUrl || '') + '?event=' + r.event_id + '&roster=1';
            actHtml += '<div class="lnkup-crm-roster-row"><a href="' + escapeHtml(url) + '">' + escapeHtml(r.title) + '</a><span class="lnkup-crm-roster-row__chip">' + r.total + ' vendors</span></div>';
          });
          actHtml += '</div>';
        }
        if (data.rebook_recommendations && data.rebook_recommendations.length) {
          actHtml += '<div class="lnkup-crm-widget lnkup-crm-widget--wide"><h3>Rebook Recommendations</h3><ul class="lnkup-crm-widget-list">';
          data.rebook_recommendations.forEach(function (v) {
            var url = (ajax.organizerDashboardUrl || '') + '?vendor=' + v.profile_id;
            actHtml += '<li><a href="' + escapeHtml(url) + '">' + escapeHtml(v.business_name) + '</a></li>';
          });
          actHtml += '</ul></div>';
        }
        if (actHtml) {
          actBody.innerHTML = actHtml;
        } else {
          actBody.innerHTML = '<p class="lnkup-muted">' + escapeHtml(copy.empty_activity || 'No recent activity yet.') + '</p>';
        }
      }
    }).catch(function () {
      panelMessage(grid, 'error', 'Could not load activity', 'CRM data is temporarily unavailable.');
    });
  }

  function loadLists() {
    var el = document.getElementById('lnkup-crm-lists');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    return crmFetchJson('/lists').then(function (res) {
      var items = (res && res.items) ? res.items : [];
      listsCache = items;
      var summary = document.getElementById('lnkup-organizer-lists-summary');
      if (summary) {
        if (!items.length) {
          summary.textContent = 'No lists yet. Create one to organize vendors.';
        } else {
          var first = items[0];
          summary.textContent = items.length === 1
            ? first.name + ' (' + (first.count || 0) + ' vendors)'
            : items.length + ' lists · latest: ' + first.name;
        }
      }
      if (!items.length) {
        if (window.LNKupUI && LNKupUI.panelEmpty) {
          var copy = (window.lnkupAjax && window.lnkupAjax.copy) || {};
          LNKupUI.panelEmpty(el, {
            title: copy.empty_vendor_lists || 'No lists yet',
            description: copy.empty_vendor_lists || 'Create a list to save vendor segments for future events.',
            ctaLabel: copy.discover_vendors || 'Discover vendors',
            ctaHref: (ajax.organizerDashboardUrl || '') + '#vendors'
          });
        } else {
          panelMessage(el, 'empty', 'No lists yet', 'Create a list to save vendor segments for future events.');
        }
        return;
      }
      var html = '<div class="lnkup-crm-list-grid">';
      items.forEach(function (list) {
        var color = list.color || '#c8ff00';
        html += '<article class="lnkup-crm-list-card lnkup-crm-list-card--clickable" data-list-id="' + list.id + '" role="button" tabindex="0">';
        html += '<div class="lnkup-crm-list-card__top">';
        html += '<span class="lnkup-crm-list-card__swatch" style="background:' + escapeHtml(color) + '"></span>';
        html += '<strong>' + escapeHtml(list.name) + '</strong>';
        html += '<span class="lnkup-crm-list-card__chevron" aria-hidden="true">›</span>';
        html += '</div>';
        html += '<p class="lnkup-crm-list-card__count">' + (list.count || 0) + ' <span class="lnkup-muted">vendors</span></p>';
        html += '<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-crm-list-delete" data-list-id="' + list.id + '">Delete</button>';
        html += '</article>';
      });
      html += '</div>';
      el.innerHTML = html;
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load lists', 'Please refresh and try again.');
    });
  }

  function inviteStatusClass(status) {
    var s = (status || '').toLowerCase();
    if (s.indexOf('accept') > -1) {
      return 'lnkup-status-pill--accent';
    }
    if (s.indexOf('open') > -1 || s.indexOf('sent') > -1) {
      return 'lnkup-status-pill--muted';
    }
    return '';
  }

  function loadInvites() {
    var el = document.getElementById('lnkup-crm-invites');
    if (!el || !base) {
      return;
    }
    el.innerHTML = '<div class="lnkup-crm-skeleton" aria-hidden="true"></div>';
    crmFetchJson('/invites/list').then(function (res) {
      var items = (res && res.items) ? res.items : [];
      var summary = document.getElementById('lnkup-organizer-invites-summary');
      if (summary) {
        if (!items.length) {
          summary.textContent = 'No invites sent yet.';
        } else {
          summary.textContent = items.length === 1
            ? '1 invite sent'
            : items.length + ' invites sent';
        }
      }
      if (!items.length) {
        if (window.LNKupUI && LNKupUI.panelEmpty) {
          var copy = (window.lnkupAjax && window.lnkupAjax.copy) || {};
          LNKupUI.panelEmpty(el, {
            title: copy.empty_vendor_invites || 'No invites sent yet',
            description: copy.empty_vendor_invites || 'Discover vendors and send your first invite.',
            ctaLabel: copy.discover_vendors || 'Discover vendors',
            ctaHref: (ajax.organizerDashboardUrl || '') + '#vendors'
          });
        } else {
          panelMessage(el, 'empty', 'No invites sent yet', 'Invite vendors from the directory or vendor profiles.');
        }
        return;
      }
      var html = '';
      items.forEach(function (inv) {
        var link = inv.link || inv.invite_link || '';
        var eventLine = inv.event_title ? escapeHtml(inv.event_title) + ' · ' : '';
        html += '<article class="lnkup-crm-invite-card">';
        html += '<div class="lnkup-crm-invite-card__header"><strong>' + escapeHtml(inv.vendor) + '</strong>';
        html += '<span class="lnkup-status-pill ' + inviteStatusClass(inv.status) + '">' + escapeHtml(inv.status || 'sent') + '</span></div>';
        html += '<p class="lnkup-muted">' + eventLine + escapeHtml(inv.created || '') + '</p>';
        html += '<div class="lnkup-crm-card__actions">';
        if (link) {
          html += '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--ghost lnkup-crm-copy-invite" data-link="' + escapeHtml(link) + '">Copy link</button>';
        }
        if (inv.id && link) {
          html += '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline lnkup-crm-resend-invite" data-link="' + escapeHtml(link) + '">Resend link</button>';
        }
        html += '</div></article>';
      });
      el.innerHTML = html;
    }).catch(function () {
      panelMessage(el, 'error', 'Could not load invites', 'Please refresh and try again.');
    });
  }

  function loadOutreachCampaigns() {
    var el = document.getElementById('lnkup-crm-outreach-campaigns');
    if (!el || !base) {
      return;
    }
    crmFetchJson('/outreach/list').then(function (res) {
      var items = (res && res.items) ? res.items : [];
      if (!items.length) {
        el.innerHTML = '';
        return;
      }
      var html = '<div class="lnkup-crm-outreach-campaigns__list"><p class="lnkup-muted lnkup-crm-outreach-campaigns__title">Email outreach campaigns</p>';
      items.forEach(function (c) {
        var progress = (c.sent || 0) + '/' + (c.total || 0);
        html += '<article class="lnkup-crm-outreach-card">';
        html += '<div class="lnkup-crm-outreach-card__header"><strong>' + escapeHtml(c.name || 'Campaign') + '</strong>';
        html += '<span class="lnkup-status-pill lnkup-status-pill--muted">' + escapeHtml(c.status || 'draft') + '</span></div>';
        html += '<p class="lnkup-muted">Sent ' + escapeHtml(progress) + ' · Registered ' + escapeHtml(String(c.registered || 0)) + '</p>';
        html += '</article>';
      });
      html += '</div>';
      el.innerHTML = html;
    }).catch(function () {
      el.innerHTML = '';
    });
  }

  function initBulkOutreachForm() {
    var form = document.getElementById('lnkup-crm-bulk-outreach-form');
    if (!form || !base) {
      return;
    }
    var eventSelect = document.getElementById('lnkup-crm-bulk-event');
    var oppSelect = document.getElementById('lnkup-crm-bulk-opp');
    if (!eventSelect || !oppSelect) {
      return;
    }

    fetchInviteOptions().then(function (options) {
      if (!options.items || !options.items.length) {
        eventSelect.innerHTML = '<option value="">Launch an event first</option>';
        oppSelect.innerHTML = '<option value="">—</option>';
        return;
      }
      var eventOptions = '<option value="">Select event (optional)…</option>';
      options.items.forEach(function (ev) {
        var meta = [];
        if (ev.date) {
          meta.push(ev.date);
        }
        if (ev.city) {
          meta.push(ev.city);
        }
        eventOptions += '<option value="' + ev.event_id + '">' + escapeHtml(ev.title) + (meta.length ? ' · ' + escapeHtml(meta.join(' · ')) : '') + '</option>';
      });
      eventSelect.innerHTML = eventOptions;
      oppSelect.innerHTML = '<option value="">Select opportunity…</option>';
    });

    eventSelect.addEventListener('change', function () {
      fetchInviteOptions().then(function (options) {
        oppSelect.innerHTML = buildOpportunityOptions(options.items || [], eventSelect.value);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var emailsEl = document.getElementById('lnkup-crm-bulk-emails');
      var messageEl = document.getElementById('lnkup-crm-bulk-message');
      var emails = emailsEl ? emailsEl.value.trim() : '';
      if (!emails) {
        toast('Add at least one email address.', 'error');
        return;
      }
      var submitBtn = form.querySelector('[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
      }
      crmFetch('/outreach/bulk', {
        method: 'POST',
        body: {
          event_id: eventSelect.value ? parseInt(eventSelect.value, 10) : 0,
          opportunity_id: oppSelect.value ? parseInt(oppSelect.value, 10) : 0,
          emails: emails,
          message: messageEl ? messageEl.value.trim() : ''
        }
      }).then(function () {
        toast('Bulk invites queued.');
        if (emailsEl) {
          emailsEl.value = '';
        }
        if (messageEl) {
          messageEl.value = '';
        }
        loadOutreachCampaigns();
      }).catch(function (err) {
        toast((err && err.message) || 'Could not send bulk invites.', 'error');
      }).finally(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
        }
      });
    });
  }

  function updateCompareBar() {
    var bar = document.getElementById('lnkup-crm-compare-bar');
    var countEl = document.getElementById('lnkup-crm-compare-count');
    if (!bar || !countEl) {
      return;
    }
    var checked = document.querySelectorAll('.lnkup-crm-compare-pick:checked');
    var n = checked.length;
    bar.hidden = n < 2;
    countEl.textContent = n + (n === 1 ? ' selected' : ' selected');
  }

  function filterApplications(filter) {
    var cards = document.querySelectorAll('.lnkup-crm-app-card');
    var visible = 0;
    cards.forEach(function (card) {
      var show = filter === 'all';
      if (!show && filter === 'pending') {
        show = card.getAttribute('data-org-app-filter') === 'pending';
      } else if (!show && filter === 'approved') {
        show = card.getAttribute('data-org-app-filter') === 'approved' || card.getAttribute('data-org-app-status') === 'paid' || card.getAttribute('data-org-app-status') === 'completed';
      } else if (!show && filter === 'waitlisted') {
        show = card.getAttribute('data-org-app-status') === 'waitlisted';
      } else if (!show && filter === 'rejected') {
        show = card.getAttribute('data-org-app-status') === 'rejected';
      } else if (!show && filter === 'unpaid') {
        show = card.getAttribute('data-org-app-paid') === 'no' && (card.getAttribute('data-org-app-status') === 'approved' || card.getAttribute('data-org-app-status') === 'payment_required');
      } else if (!show && filter === 'missing_docs') {
        show = card.getAttribute('data-org-app-docs') === 'missing';
      }
      card.hidden = !show;
      if (show) {
        visible++;
      }
    });
    var grid = document.getElementById('lnkup-app-intel-grid');
    var empty = document.getElementById('lnkup-app-filter-empty');
    if (grid && filter !== 'all' && visible === 0) {
      if (!empty) {
        empty = document.createElement('p');
        empty.id = 'lnkup-app-filter-empty';
        empty.className = 'lnkup-muted';
        grid.appendChild(empty);
      }
      empty.textContent = 'No applications match this filter.';
      empty.hidden = false;
    } else if (empty) {
      empty.hidden = true;
    }
  }

  function escapeHtml(str) {
    if (!str) {
      return '';
    }
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function openCompare(ids) {
    if (ids.length < 2) {
      alert('Select at least 2 applications to compare.');
      return;
    }
    crmFetch('/applications/compare?ids=' + ids.join(',')).then(function (res) {
      var items = (res && res.items) ? res.items : [];
      var modal = document.getElementById('lnkup-crm-compare-modal');
      if (!modal) {
        modal = document.createElement('div');
        modal.id = 'lnkup-crm-compare-modal';
        modal.className = 'lnkup-crm-modal';
        modal.innerHTML = '<div class="lnkup-crm-modal__inner"><button type="button" class="lnkup-crm-modal__close">&times;</button><div id="lnkup-crm-compare-body"></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function (e) {
          if (e.target === modal || e.target.classList.contains('lnkup-crm-modal__close')) {
            modal.hidden = true;
          }
        });
      }
      var body = document.getElementById('lnkup-crm-compare-body');
      var html = '<h2>Compare Applicants</h2><table class="lnkup-table lnkup-crm-compare-table"><thead><tr><th>Field</th>';
      items.forEach(function (p) {
        html += '<th>' + escapeHtml(p.business_name) + '</th>';
      });
      html += '</tr></thead><tbody>';
      var fields = [
        ['Score', 'vendor_score'],
        ['Rating', 'avg_rating'],
        ['Reviews', 'review_count'],
        ['City', 'city'],
        ['Events', 'completed_events'],
        ['Message', 'application_message']
      ];
      fields.forEach(function (pair) {
        html += '<tr><td>' + escapeHtml(pair[0]) + '</td>';
        items.forEach(function (p) {
          html += '<td>' + escapeHtml(String(p[pair[1]] != null ? p[pair[1]] : '—')) + '</td>';
        });
        html += '</tr>';
      });
      html += '</tbody></table>';
      body.innerHTML = html;
      modal.hidden = false;
    });
  }

  function fetchInviteOptions() {
    if (inviteOptionsCache) {
      return Promise.resolve(inviteOptionsCache);
    }
    return crmFetchJson('/events/invite-options').then(function (data) {
      inviteOptionsCache = data || { items: [], needs_event: true };
      return inviteOptionsCache;
    });
  }

  function invalidateInviteOptions() {
    inviteOptionsCache = null;
  }

  function closeSlideOver(overlay) {
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  function buildOpportunityOptions(events, eventId) {
    var html = '<option value="">Select opportunity…</option>';
    if (!eventId) {
      return html;
    }
    events.forEach(function (ev) {
      if (String(ev.event_id) !== String(eventId)) {
        return;
      }
      (ev.opportunities || []).forEach(function (opp) {
        var label = opp.label + ' — $' + (opp.vendor_fee || 0) + ' · ' + (opp.spots_remaining || 0) + ' spots';
        html += '<option value="' + opp.id + '">' + escapeHtml(label) + '</option>';
      });
    });
    return html;
  }

  function openInviteModal(opts) {
    opts = opts || {};
    var vendorUserId = opts.vendorUserId ? parseInt(opts.vendorUserId, 10) : 0;
    var vendorName = opts.vendorName || '';
    var bulkVendors = opts.bulkVendors || null;
    var prefillEventId = opts.prefillEventId || 0;
    var prefillOpportunityId = opts.prefillOpportunityId || 0;

    if (!vendorUserId && !bulkVendors) {
      window.location.hash = 'vendors';
      if (window.lnkupOrganizerExpandPanel) {
        window.lnkupOrganizerExpandPanel('vendors', true);
      }
      var search = document.getElementById('lnkup-crm-vendor-search');
      if (search) {
        search.focus();
      }
      toast('Choose a vendor from Discover Vendors, then click Invite.', 'success');
      return;
    }

    fetchInviteOptions().then(function (options) {
      var overlay = document.createElement('div');
      overlay.className = 'lnkup-crm-slide';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');

      var title = bulkVendors
        ? 'Invite ' + bulkVendors.length + ' vendors to event'
        : (vendorName ? 'Invite ' + vendorName : 'Invite vendor');

      var bodyHtml = '';
      if (options.needs_event || !options.items || !options.items.length) {
        bodyHtml = '<div class="lnkup-alert lnkup-alert--info"><p>Launch an event with a vendor opportunity before sending invites.</p>';
        bodyHtml += '<a href="#create" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm">Launch event</a></div>';
      } else {
        var eventOptions = '<option value="">Select event…</option>';
        options.items.forEach(function (ev) {
          var meta = [];
          if (ev.date) {
            meta.push(ev.date);
          }
          if (ev.city) {
            meta.push(ev.city);
          }
          var selected = prefillEventId && String(ev.event_id) === String(prefillEventId) ? ' selected' : '';
          eventOptions += '<option value="' + ev.event_id + '"' + selected + '>' + escapeHtml(ev.event_title) + (meta.length ? ' (' + escapeHtml(meta.join(' · ')) + ')' : '') + '</option>';
        });
        var initialEvent = prefillEventId || (options.items[0] && options.items[0].event_id) || '';
        bodyHtml += '<form id="lnkup-crm-invite-form" class="lnkup-crm-slide-form">';
        bodyHtml += '<label class="lnkup-form-row">Event<select name="event_id" id="lnkup-crm-invite-event" required>' + eventOptions + '</select></label>';
        bodyHtml += '<label class="lnkup-form-row">Opportunity<select name="opportunity_id" id="lnkup-crm-invite-opp" required>' + buildOpportunityOptions(options.items, initialEvent) + '</select></label>';
        bodyHtml += '<label class="lnkup-form-row">Personal message<textarea name="message" rows="3" placeholder="Optional note for the vendor"></textarea></label>';
        bodyHtml += '<div class="lnkup-crm-slide-form__actions">';
        bodyHtml += '<button type="submit" class="lnkup-btn lnkup-btn--primary">Send invite</button>';
        bodyHtml += '<button type="button" class="lnkup-btn lnkup-btn--ghost" id="lnkup-crm-invite-cancel">Cancel</button>';
        bodyHtml += '</div></form>';
      }

      overlay.innerHTML = '<div class="lnkup-crm-slide__panel"><button type="button" class="lnkup-crm-slide__close" aria-label="Close">&times;</button>';
      overlay.innerHTML += '<h2 class="lnkup-crm-slide__title">' + escapeHtml(title) + '</h2>' + bodyHtml + '</div>';
      document.body.appendChild(overlay);

      function close() {
        closeSlideOver(overlay);
      }
      overlay.querySelector('.lnkup-crm-slide__close').addEventListener('click', close);
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) {
          close();
        }
      });
      var cancelBtn = overlay.querySelector('#lnkup-crm-invite-cancel');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', close);
      }

      var eventSelect = overlay.querySelector('#lnkup-crm-invite-event');
      var oppSelect = overlay.querySelector('#lnkup-crm-invite-opp');
      if (eventSelect && oppSelect) {
        if (prefillOpportunityId) {
          oppSelect.value = String(prefillOpportunityId);
        }
        eventSelect.addEventListener('change', function () {
          oppSelect.innerHTML = buildOpportunityOptions(options.items, eventSelect.value);
        });
      }

      var form = overlay.querySelector('#lnkup-crm-invite-form');
      if (form) {
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          var fd = new FormData(form);
          var eventId = parseInt(fd.get('event_id'), 10) || 0;
          var oppId = parseInt(fd.get('opportunity_id'), 10) || 0;
          var message = fd.get('message') || '';
          var submitBtn = form.querySelector('[type="submit"]');
          if (submitBtn) {
            submitBtn.disabled = true;
          }

          function sendOne(uid) {
            return crmFetch('/invites', {
              method: 'POST',
              body: {
                vendor_user_id: uid,
                event_id: eventId,
                opportunity_id: oppId,
                message: message,
                type: 'apply'
              }
            });
          }

          var chain = Promise.resolve();
          if (bulkVendors && bulkVendors.length) {
            bulkVendors.forEach(function (v) {
              chain = chain.then(function () {
                return sendOne(parseInt(v.vendor_user_id, 10));
              });
            });
          } else {
            chain = sendOne(vendorUserId);
          }

          chain.then(function (res) {
            close();
            toast(bulkVendors ? 'Invites sent.' : 'Invite sent.');
            if (res && res.link && navigator.clipboard) {
              navigator.clipboard.writeText(res.link).catch(function () {});
            }
            loadInvites();
          }).catch(function (err) {
            toast((err && err.message) || 'Could not send invite.', 'error');
            if (submitBtn) {
              submitBtn.disabled = false;
            }
          });
        });
      }
    }).catch(function () {
      toast('Could not load your events.', 'error');
    });
  }

  function openListDrawer(listId) {
    var listMeta = listsCache.find(function (l) { return String(l.id) === String(listId); });
    var listName = listMeta ? listMeta.name : 'Vendor list';
    var overlay = document.createElement('div');
    overlay.className = 'lnkup-crm-slide';
    overlay.setAttribute('role', 'dialog');
    overlay.innerHTML = '<div class="lnkup-crm-slide__panel lnkup-crm-slide__panel--wide">' +
      '<button type="button" class="lnkup-crm-slide__close" aria-label="Close">&times;</button>' +
      '<h2 class="lnkup-crm-slide__title">' + escapeHtml(listName) + '</h2>' +
      '<div class="lnkup-crm-list-drawer__toolbar">' +
      '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline" id="lnkup-crm-list-invite-all">Invite all to event</button>' +
      '<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary" id="lnkup-crm-list-add-vendor">Add vendors</button>' +
      '</div>' +
      '<div id="lnkup-crm-list-drawer-body"><div class="lnkup-crm-skeleton"></div></div>' +
      '</div>';
    document.body.appendChild(overlay);

    function close() {
      closeSlideOver(overlay);
    }
    overlay.querySelector('.lnkup-crm-slide__close').addEventListener('click', close);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) {
        close();
      }
    });

    var body = overlay.querySelector('#lnkup-crm-list-drawer-body');
    var listVendors = [];

    function renderVendors(items) {
      listVendors = items || [];
      if (!items.length) {
        body.innerHTML = '<div class="lnkup-empty-state lnkup-empty-state--compact"><p class="lnkup-empty-state__title">No vendors in this list</p><p class="lnkup-empty-state__desc">Add vendors from Discover Vendors.</p></div>';
        return;
      }
      var html = '<ul class="lnkup-crm-list-items">';
      items.forEach(function (v) {
        html += '<li class="lnkup-crm-list-item">';
        html += '<span><strong>' + escapeHtml(v.business_name) + '</strong>';
        if (v.city) {
          html += ' <span class="lnkup-muted">' + escapeHtml(v.city) + '</span>';
        }
        html += '</span>';
        html += '<button type="button" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm lnkup-crm-list-remove" data-profile-id="' + v.profile_id + '">Remove</button>';
        html += '</li>';
      });
      html += '</ul>';
      body.innerHTML = html;
    }

    function refreshList() {
      crmFetchJson('/lists/' + listId + '/vendors').then(function (res) {
        renderVendors((res && res.items) ? res.items : []);
        loadLists();
      }).catch(function () {
        panelMessage(body, 'error', 'Could not load list', '');
      });
    }

    refreshList();

    overlay.querySelector('#lnkup-crm-list-invite-all').addEventListener('click', function () {
      if (!listVendors.length) {
        toast('Add vendors to this list first.', 'error');
        return;
      }
      close();
      openInviteModal({
        bulkVendors: listVendors.map(function (v) {
          return { vendor_user_id: v.vendor_user_id, business_name: v.business_name };
        })
      });
    });

    overlay.querySelector('#lnkup-crm-list-add-vendor').addEventListener('click', function () {
      body.innerHTML = '<input type="search" id="lnkup-crm-list-add-search" class="lnkup-crm-search" placeholder="Search vendors…" />';
      body.innerHTML += '<div id="lnkup-crm-list-add-results" class="lnkup-crm-list-add-results"></div>';
      var searchEl = body.querySelector('#lnkup-crm-list-add-search');
      var resultsEl = body.querySelector('#lnkup-crm-list-add-results');
      function searchVendors(q) {
        resultsEl.innerHTML = '<div class="lnkup-crm-skeleton"></div>';
        crmFetchJson('/vendors?scope=discover&view=compact&q=' + encodeURIComponent(q)).then(function (res) {
          var items = (res && res.items) ? res.items : [];
          if (!items.length) {
            resultsEl.innerHTML = '<p class="lnkup-muted">No vendors found.</p>';
            return;
          }
          var html = '';
          items.forEach(function (v) {
            html += '<button type="button" class="lnkup-crm-list-add-pick" data-profile-id="' + v.profile_id + '">';
            html += escapeHtml(v.business_name) + (v.city ? ' · ' + escapeHtml(v.city) : '');
            html += '</button>';
          });
          resultsEl.innerHTML = html;
        });
      }
      searchEl.addEventListener('input', debounce(function (e) {
        searchVendors(e.target.value);
      }, 300));
      searchVendors('');
      resultsEl.addEventListener('click', function (e) {
        var pick = e.target.closest('.lnkup-crm-list-add-pick');
        if (!pick) {
          return;
        }
        var profileId = pick.getAttribute('data-profile-id');
        crmFetch('/lists/' + listId + '/vendors', {
          method: 'POST',
          body: { profile_id: parseInt(profileId, 10) }
        }).then(function () {
          toast('Vendor added to list.');
          refreshList();
        });
      });
    });

    body.addEventListener('click', function (e) {
      var removeBtn = e.target.closest('.lnkup-crm-list-remove');
      if (!removeBtn) {
        return;
      }
      var profileId = removeBtn.getAttribute('data-profile-id');
      crmFetch('/lists/' + listId + '/vendors?profile_id=' + encodeURIComponent(profileId), {
        method: 'DELETE'
      }).then(function () {
        refreshList();
      });
    });
  }

  function openAddToListMenu(profileId, anchorBtn) {
    if (!listsCache.length) {
      loadLists().then(function () {
        openAddToListMenu(profileId, anchorBtn);
      });
      return;
    }
    document.querySelectorAll('.lnkup-crm-list-picker').forEach(function (el) {
      el.remove();
    });
    var menu = document.createElement('div');
    menu.className = 'lnkup-crm-list-picker';
    if (!listsCache.length) {
      menu.innerHTML = '<p class="lnkup-muted">Create a list first.</p>';
    } else {
      listsCache.forEach(function (list) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'lnkup-crm-list-picker__item';
        btn.textContent = list.name;
        btn.addEventListener('click', function () {
          crmFetch('/lists/' + list.id + '/vendors', {
            method: 'POST',
            body: { profile_id: parseInt(profileId, 10) }
          }).then(function () {
            toast('Saved to ' + list.name + '.');
            menu.remove();
            loadLists();
          });
        });
        menu.appendChild(btn);
      });
    }
    anchorBtn.parentElement.appendChild(menu);
    setTimeout(function () {
      document.addEventListener('click', function handler(e) {
        if (!menu.contains(e.target) && e.target !== anchorBtn) {
          menu.remove();
          document.removeEventListener('click', handler);
        }
      });
    }, 0);
  }

  function bindInviteBanner() {
    var banner = document.getElementById('lnkup-invite-banner');
    if (!banner || !base) {
      return;
    }
    var token = banner.getAttribute('data-token');
    var acceptBtn = document.getElementById('lnkup-invite-accept');
    var declineBtn = document.getElementById('lnkup-invite-decline');
    function respond(accept) {
      crmFetch('/invites/respond', { method: 'POST', body: { token: token, accept: accept } }).then(function (res) {
        if (res && res.success) {
          if (accept && res.apply_url) {
            window.location.href = res.apply_url;
            return;
          }
          banner.innerHTML = '<p class="lnkup-alert lnkup-alert--success">' + (accept ? 'Invite accepted!' : 'Invite declined.') + '</p>';
        } else {
          alert((res && res.message) ? res.message : 'Could not update invite.');
        }
      });
    }
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () { respond(true); });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () { respond(false); });
    }
  }

  function rosterBulk(action, eventId) {
    var ids = [];
    document.querySelectorAll('.lnkup-roster-pick:checked').forEach(function (cb) {
      ids.push(parseInt(cb.value, 10));
    });
    if (!ids.length) {
      alert('Select at least one vendor.');
      return;
    }
    crmFetch('/events/' + eventId + '/roster/bulk', {
      method: 'POST',
      body: { action: action, application_ids: ids }
    }).then(function () {
      location.reload();
    });
  }

  function rosterSingle(action, appId) {
    var rosterEl = document.getElementById('lnkup-event-roster');
    if (!rosterEl || !base) {
      return;
    }
    crmFetch('/events/' + rosterEl.getAttribute('data-event-id') + '/roster/bulk', {
      method: 'POST',
      body: { action: action, application_ids: [parseInt(appId, 10)] }
    }).then(function () {
      location.reload();
    });
  }

  function handleInviteDeepLink() {
    var params = new URLSearchParams(window.location.search);
    var eventId = params.get('invite_event');
    var oppId = params.get('opp');
    if (!eventId && !oppId) {
      return;
    }
    openInviteModal({
      prefillEventId: eventId ? parseInt(eventId, 10) : 0,
      prefillOpportunityId: oppId ? parseInt(oppId, 10) : 0
    });
  }

  function launchChecklistCopy() {
    return window.lnkupUiCopy || (window.lnkupAjax && window.lnkupAjax.copy) || {};
  }

  function statusLabel(status) {
    var copy = launchChecklistCopy();
    if (status === 'complete') {
      return copy.launch_checklist_status_complete || 'Complete';
    }
    if (status === 'in_progress') {
      return copy.launch_checklist_status_in_progress || 'In progress';
    }
    return copy.launch_checklist_status_not_started || 'Not started';
  }

  function statusClass(status) {
    return (status || 'not_started').replace(/_/g, '-');
  }

  function refreshLaunchChecklist() {
    var root = document.getElementById('lnkup-launch-checklist');
    if (!root || !base) {
      return Promise.resolve();
    }
    return crmFetchJson('/launch-checklist').then(function (data) {
      if (!data || !data.items) {
        return;
      }
      var progressEl = root.querySelector('[data-launch-checklist-progress]');
      var percentEl = root.querySelector('[data-launch-checklist-percent]');
      var bar = root.querySelector('.lnkup-launch-checklist__progress-bar');
      var copy = launchChecklistCopy();
      var progressText = (copy.launch_checklist_progress || '%1$d of %2$d complete')
        .replace('%1$d', String(data.completed || 0))
        .replace('%2$d', String(data.total || 0));
      if (progressEl) {
        progressEl.textContent = progressText;
      }
      if (percentEl) {
        percentEl.style.width = (data.percent || 0) + '%';
      }
      if (bar) {
        bar.setAttribute('aria-valuenow', String(data.percent || 0));
        bar.setAttribute('aria-label', progressText);
      }
      data.items.forEach(function (item) {
        var card = root.querySelector('[data-launch-checklist-item="' + item.key + '"]');
        if (!card) {
          return;
        }
        var status = item.status || 'not_started';
        card.setAttribute('data-status', status);
        card.className = 'lnkup-launch-checklist-card lnkup-launch-checklist-card--' + statusClass(status);
        var pill = card.querySelector('[data-launch-checklist-status]');
        if (pill) {
          pill.textContent = statusLabel(status);
        }
        var cta = card.querySelector('[data-launch-checklist-cta]');
        if (cta) {
          var isComplete = status === 'complete';
          cta.textContent = isComplete ? (copy.launch_checklist_view || 'View') : (item.cta_label || cta.textContent);
          cta.classList.toggle('lnkup-btn--ghost', isComplete);
          cta.classList.toggle('lnkup-btn--outline', !isComplete);
          if (item.cta_url) {
            cta.setAttribute('href', item.cta_url);
          }
        }
      });
      if (data.all_complete) {
        root.setAttribute('data-all-complete', '1');
        root.classList.add('lnkup-launch-checklist--complete');
      }
    }).catch(function (err) {
      console.error('[LNKup CRM] launch-checklist', err);
    });
  }

  function initLaunchChecklistToggle() {
    var root = document.getElementById('lnkup-launch-checklist');
    if (!root) {
      return;
    }
    var toggle = root.querySelector('[data-launch-checklist-toggle]');
    var body = root.querySelector('.lnkup-launch-checklist__body');
    if (!toggle || !body) {
      return;
    }
    var copy = (window.lnkupAjax && window.lnkupAjax.copy) || {};
    toggle.addEventListener('click', function () {
      var expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.hidden = expanded;
      toggle.textContent = expanded
        ? (copy.launch_checklist_show || 'Show checklist')
        : (copy.launch_checklist_hide || 'Hide checklist');
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    syncHashNav();
    window.addEventListener('hashchange', syncHashNav);

    if (document.getElementById('lnkup-organizer-crm')) {
      loadWidgets();
      initLaunchChecklistToggle();
      if (window.LNKupUI && typeof LNKupUI.animateKpiCards === 'function') {
        LNKupUI.animateKpiCards(document.getElementById('lnkup-crm-stats'));
      }
      var hash = (window.location.hash || '').replace(/^#/, '');
      if (hash === 'vendors' || hash === 'lists' || hash === 'invites') {
        loadDirectory();
      }
      loadLists();
      loadInvites();
      loadOutreachCampaigns();
      initBulkOutreachForm();
      handleInviteDeepLink();
    }

    var directoryMore = document.getElementById('lnkup-crm-directory-more');
    if (directoryMore) {
      directoryMore.addEventListener('click', function () {
        var dir = document.getElementById('lnkup-crm-directory');
        if (dir) {
          dir.classList.add('lnkup-crm-directory--expanded');
        }
        directoryMore.hidden = true;
      });
    }

    var newListForm = document.getElementById('lnkup-crm-new-list-form');
    if (newListForm) {
      newListForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var nameInput = document.getElementById('lnkup-crm-new-list-name');
        var name = nameInput && nameInput.value.trim();
        if (!name) {
          return;
        }
        crmFetch('/lists', { method: 'POST', body: { name: name } }).then(function () {
          toast('List created.');
          if (nameInput) {
            nameInput.value = '';
          }
          loadLists();
        });
      });
    }

    var inviteFromPanel = document.getElementById('lnkup-crm-invite-from-panel');
    if (inviteFromPanel) {
      inviteFromPanel.addEventListener('click', function () {
        openInviteModal({});
      });
    }

    document.addEventListener('click', function (e) {
      var priorityTrigger = e.target.closest('[data-org-app-filter-trigger]');
      if (priorityTrigger) {
        e.preventDefault();
        window.location.hash = 'applications';
        document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn').forEach(function (b) {
          b.classList.toggle('is-active', b.getAttribute('data-org-app-filter') === 'missing_docs');
        });
        filterApplications('missing_docs');
      }
    });

    bindInviteBanner();

    document.querySelectorAll('[data-org-app-filter]').forEach(function (btn) {
      if (btn.tagName !== 'BUTTON' || !btn.classList.contains('lnkup-dash-tabs__btn')) {
        return;
      }
      btn.addEventListener('click', function () {
        document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn[data-org-app-filter]').forEach(function (b) {
          b.classList.remove('is-active');
        });
        btn.classList.add('is-active');
        filterApplications(btn.getAttribute('data-org-app-filter') || 'all');
      });
    });

    var moreFiltersBtn = document.querySelector('[data-org-app-filter-toggle]');
    var extraFilters = document.getElementById('lnkup-org-app-filters-extra');
    if (moreFiltersBtn && extraFilters) {
      moreFiltersBtn.addEventListener('click', function () {
        var expanded = moreFiltersBtn.getAttribute('aria-expanded') === 'true';
        moreFiltersBtn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
        extraFilters.hidden = expanded;
      });
    }

    document.querySelectorAll('[data-org-app-layout]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var layout = btn.getAttribute('data-org-app-layout') || 'grid';
        document.querySelectorAll('[data-org-app-layout]').forEach(function (b) {
          b.classList.toggle('is-active', b === btn);
        });
        var grid = document.querySelector('.lnkup-crm-app-grid--v2');
        if (grid) {
          grid.classList.toggle('lnkup-crm-app-grid--list', layout === 'list');
        }
      });
    });

    document.addEventListener('change', function (e) {
      if (e.target && e.target.classList && e.target.classList.contains('lnkup-crm-compare-pick')) {
        updateCompareBar();
      }
    });

    var compareClear = document.getElementById('lnkup-crm-compare-clear');
    if (compareClear) {
      compareClear.addEventListener('click', function () {
        document.querySelectorAll('.lnkup-crm-compare-pick:checked').forEach(function (cb) {
          cb.checked = false;
        });
        updateCompareBar();
      });
    }

    updateCompareBar();

    var searchInput = document.getElementById('lnkup-crm-vendor-search');
    if (searchInput) {
      searchInput.addEventListener('input', debounce(function (e) {
        crmState.q = e.target.value;
        loadDirectory();
      }, 350));
    }

    var sortSelect = document.getElementById('lnkup-crm-vendor-sort');
    if (sortSelect) {
      sortSelect.addEventListener('change', function (e) {
        crmState.sort = e.target.value;
        loadDirectory();
      });
    }

    var cityInput = document.getElementById('lnkup-crm-vendor-city');
    if (cityInput) {
      cityInput.addEventListener('input', debounce(function (e) {
        crmState.city = e.target.value.trim();
        loadDirectory();
      }, 350));
    }

    var categorySelect = document.getElementById('lnkup-crm-vendor-category');
    if (categorySelect) {
      categorySelect.addEventListener('change', function (e) {
        crmState.category = e.target.value;
        loadDirectory();
      });
    }

    var verifiedInput = document.getElementById('lnkup-crm-vendor-verified');
    if (verifiedInput) {
      verifiedInput.addEventListener('change', function (e) {
        crmState.verified = e.target.checked ? '1' : '';
        loadDirectory();
      });
    }

    document.addEventListener('click', function (e) {
      var smartBtn = e.target.closest('.lnkup-smart-list');
      if (smartBtn) {
        var appFilter = smartBtn.getAttribute('data-org-app-filter');
        if (appFilter) {
          window.location.hash = 'applications';
          document.querySelectorAll('.lnkup-organizer-app-filters .lnkup-dash-tabs__btn').forEach(function (b) {
            b.classList.toggle('is-active', b.getAttribute('data-org-app-filter') === appFilter);
          });
          filterApplications(appFilter);
          return;
        }
        var scope = smartBtn.getAttribute('data-crm-scope');
        var sort = smartBtn.getAttribute('data-crm-sort');
        if (scope) {
          crmState.scope = scope;
          document.querySelectorAll('[data-crm-scope]').forEach(function (b) {
            if (b.hasAttribute('data-crm-scope') && b.classList.contains('lnkup-btn')) {
              b.classList.toggle('is-active', b.getAttribute('data-crm-scope') === scope);
            }
          });
        }
        if (sort) {
          crmState.sort = sort;
          var sortEl = document.getElementById('lnkup-crm-vendor-sort');
          if (sortEl) {
            sortEl.value = sort;
          }
        }
        window.location.hash = 'vendors';
        loadDirectory();
        return;
      }

      var copyBtn = e.target.closest('.lnkup-crm-copy-invite');
      if (copyBtn && copyBtn.getAttribute('data-link')) {
        var link = copyBtn.getAttribute('data-link');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(link).then(function () {
            copyBtn.textContent = 'Copied!';
            toast('Invite link copied.');
          });
        }
        return;
      }

      var resendBtn = e.target.closest('.lnkup-crm-resend-invite');
      if (resendBtn) {
        var resendLink = resendBtn.getAttribute('data-link');
        if (resendLink && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(resendLink).then(function () {
            resendBtn.textContent = 'Link copied';
            toast('Invite link copied.');
          });
        }
        return;
      }

      var scopeBtn = e.target.closest('[data-crm-scope]');
      if (scopeBtn && scopeBtn.classList.contains('lnkup-btn')) {
        document.querySelectorAll('[data-crm-scope]').forEach(function (b) {
          if (b.classList.contains('lnkup-btn')) {
            b.classList.remove('is-active');
          }
        });
        scopeBtn.classList.add('is-active');
        crmState.scope = scopeBtn.getAttribute('data-crm-scope');
        loadDirectory();
        return;
      }

      var viewBtn = e.target.closest('[data-crm-view]');
      if (viewBtn) {
        document.querySelectorAll('[data-crm-view]').forEach(function (b) { b.classList.remove('is-active'); });
        viewBtn.classList.add('is-active');
        crmState.view = viewBtn.getAttribute('data-crm-view');
        loadDirectory();
        return;
      }

      var listCard = e.target.closest('.lnkup-crm-list-card--clickable');
      if (listCard && !e.target.closest('.lnkup-crm-list-delete')) {
        openListDrawer(listCard.getAttribute('data-list-id'));
        return;
      }

      var delList = e.target.closest('.lnkup-crm-list-delete');
      if (delList) {
        e.stopPropagation();
        var listId = delList.getAttribute('data-list-id');
        if (confirm('Delete this list?')) {
          crmFetch('/lists/' + listId, { method: 'DELETE' }).then(function () { loadLists(); });
        }
        return;
      }

      var favBtn = e.target.closest('.lnkup-crm-fav');
      if (favBtn) {
        var pid = favBtn.getAttribute('data-profile-id');
        crmFetch('/vendors/' + pid + '/favorite', { method: 'POST' }).then(function (res) {
          favBtn.textContent = (res && res.is_favorite) ? '★ Favorite' : '☆ Favorite';
          toast((res && res.is_favorite) ? 'Added to favorites.' : 'Removed from favorites.');
        });
        return;
      }

      var addListBtn = e.target.closest('.lnkup-crm-add-to-list');
      if (addListBtn) {
        e.preventDefault();
        openAddToListMenu(addListBtn.getAttribute('data-profile-id'), addListBtn);
        return;
      }

      var prefBtn = e.target.closest('.lnkup-crm-pref');
      if (prefBtn) {
        var profileId = prefBtn.getAttribute('data-profile-id') || prefBtn.closest('[data-profile-id]') && prefBtn.closest('[data-profile-id]').getAttribute('data-profile-id');
        if (!profileId) {
          profileId = document.getElementById('lnkup-crm-profile') && document.getElementById('lnkup-crm-profile').getAttribute('data-profile-id');
        }
        if (profileId) {
          crmFetch('/vendors/' + profileId + '/preferred', { method: 'POST' }).then(function () {
            prefBtn.classList.toggle('is-active');
          });
        }
        return;
      }

      var inviteBtn = e.target.closest('.lnkup-crm-invite');
      if (inviteBtn) {
        openInviteModal({
          vendorUserId: inviteBtn.getAttribute('data-vendor-id'),
          vendorName: inviteBtn.getAttribute('data-vendor-name') || '',
          profileId: inviteBtn.getAttribute('data-profile-id') || ''
        });
        return;
      }

      var compareOpen = e.target.closest('#lnkup-crm-compare-open');
      if (compareOpen) {
        var ids = [];
        document.querySelectorAll('.lnkup-crm-compare-pick:checked').forEach(function (cb) {
          ids.push(cb.value);
        });
        openCompare(ids);
        return;
      }

      var checkin = e.target.closest('.lnkup-crm-checkin');
      if (checkin) {
        var appId = checkin.getAttribute('data-app-id');
        crmFetch('/applications/' + appId + '/check-in', { method: 'POST' }).then(function () {
          location.reload();
        });
        return;
      }

      var noshow = e.target.closest('.lnkup-crm-noshow');
      if (noshow) {
        var app = noshow.getAttribute('data-app-id');
        crmFetch('/applications/' + app + '/no-show', { method: 'POST' }).then(function () {
          location.reload();
        });
        return;
      }

      var lateBtn = e.target.closest('.lnkup-crm-late');
      if (lateBtn) {
        rosterSingle('late_arrival', lateBtn.getAttribute('data-app-id'));
        return;
      }

      var bulkBtn = e.target.closest('[data-roster-bulk]');
      if (bulkBtn) {
        var rosterEl = document.getElementById('lnkup-event-roster');
        if (rosterEl) {
          rosterBulk(bulkBtn.getAttribute('data-roster-bulk'), rosterEl.getAttribute('data-event-id'));
        }
        return;
      }
    });

    var selectAll = document.getElementById('lnkup-roster-select-all');
    if (selectAll) {
      selectAll.addEventListener('change', function () {
        document.querySelectorAll('.lnkup-roster-pick').forEach(function (cb) {
          cb.checked = selectAll.checked;
        });
      });
    }

    var noteForm = document.getElementById('lnkup-crm-note-form');
    if (noteForm) {
      noteForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var profileEl = document.getElementById('lnkup-crm-profile');
        var profileId = profileEl && profileEl.getAttribute('data-profile-id');
        var input = document.getElementById('lnkup-crm-note-input');
        if (!profileId || !input || !input.value.trim()) {
          return;
        }
        crmFetch('/vendors/' + profileId + '/notes', {
          method: 'POST',
          body: { content: input.value.trim() }
        }).then(function (res) {
          if (res && res.id) {
            var list = document.getElementById('lnkup-crm-notes-list');
            var li = document.createElement('li');
            li.textContent = input.value.trim();
            list.appendChild(li);
            input.value = '';
          }
        });
      });
    }

    var profileRoot = document.getElementById('lnkup-crm-profile');
    if (profileRoot) {
      var pref = profileRoot.querySelector('.lnkup-crm-pref');
      if (pref && !pref.getAttribute('data-profile-id')) {
        pref.setAttribute('data-profile-id', profileRoot.getAttribute('data-profile-id'));
      }
    }

    var dashSearchForm = document.getElementById('lnkup-dashboard-search-form');
    var dashSearchInput = document.getElementById('lnkup-dashboard-crm-search');
    if (dashSearchForm && dashSearchInput) {
      dashSearchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        crmState.q = dashSearchInput.value.trim();
        var vendorSearch = document.getElementById('lnkup-crm-vendor-search');
        if (vendorSearch) {
          vendorSearch.value = crmState.q;
        }
        window.location.hash = 'vendors';
        syncHashNav();
        loadDirectory();
      });
      var params = new URLSearchParams(window.location.search);
      if (params.get('crm_q')) {
        dashSearchInput.value = params.get('crm_q');
        crmState.q = params.get('crm_q');
        var crmVendorSearch = document.getElementById('lnkup-crm-vendor-search');
        if (crmVendorSearch) {
          crmVendorSearch.value = crmState.q;
        }
      }
    }
  });

  window.lnkupCrmLoadDirectory = loadDirectory;
  window.lnkupCrmLoadLists = loadLists;
  window.lnkupCrmSetScope = function (scope) {
    crmState.scope = scope || 'discover';
  };
  window.lnkupOpenInviteModal = openInviteModal;
  window.lnkupCrmInvalidateInviteOptions = invalidateInviteOptions;
  window.lnkupRefreshLaunchChecklist = refreshLaunchChecklist;
})();
