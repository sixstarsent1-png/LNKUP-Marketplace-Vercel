<?php
/**
 * Admin settings and overview.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Admin {

	/**
	 * Init admin hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Add admin menu.
	 */
	public static function add_menu() {
		add_menu_page(
			__( 'LNKup', 'lnkup-marketplace' ),
			__( 'LNKup', 'lnkup-marketplace' ),
			'lnkup_manage_all',
			'lnkup-marketplace',
			array( __CLASS__, 'render_overview' ),
			'dashicons-networking',
			30
		);

		add_submenu_page(
			'lnkup-marketplace',
			__( 'Settings', 'lnkup-marketplace' ),
			__( 'Settings', 'lnkup-marketplace' ),
			'lnkup_manage_settings',
			'lnkup-settings',
			array( __CLASS__, 'render_settings' )
		);
	}

	/**
	 * Register settings.
	 */
	public static function register_settings() {
		register_setting(
			'lnkup_settings_group',
			'lnkup_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
			)
		);
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Input.
	 */
	public static function sanitize_settings( $input ) {
		$output = lnkup_get_settings();
		$output['default_fee']         = isset( $input['default_fee'] ) ? LNKup_Security::sanitize_money( $input['default_fee'] ) : $output['default_fee'];
		$output['stripe_public_key']   = isset( $input['stripe_public_key'] ) ? sanitize_text_field( $input['stripe_public_key'] ) : '';
		$output['stripe_secret_key']   = isset( $input['stripe_secret_key'] ) ? sanitize_text_field( $input['stripe_secret_key'] ) : '';
		$output['test_mode']           = ! empty( $input['test_mode'] );
		$output['default_packet_lock'] = ! empty( $input['default_packet_lock'] );
		$output['support_email']       = isset( $input['support_email'] ) ? sanitize_email( $input['support_email'] ) : $output['support_email'];
		$output['notify_vendor']       = ! empty( $input['notify_vendor'] );
		$output['notify_organizer']    = ! empty( $input['notify_organizer'] );
		$output['notify_admin']        = ! empty( $input['notify_admin'] );
		if ( ! empty( $input['default_documents'] ) && is_array( $input['default_documents'] ) ) {
			$output['default_documents'] = array_map( 'sanitize_text_field', $input['default_documents'] );
		}
		return $output;
	}

	/**
	 * Render admin overview.
	 */
	public static function render_overview() {
		if ( ! current_user_can( 'lnkup_manage_all' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'lnkup-marketplace' ) );
		}

		$vendors     = count_users()['avail_roles']['lnkup_vendor'] ?? 0;
		$organizers  = count_users()['avail_roles']['lnkup_organizer'] ?? 0;
		$events      = wp_count_posts( 'lnkup_event' )->publish ?? 0;
		$applications = wp_count_posts( 'lnkup_application' )->publish ?? 0;
		$payments    = get_posts( array( 'post_type' => 'lnkup_payment', 'posts_per_page' => -1, 'meta_key' => '_lnkup_payment_status', 'meta_value' => 'paid' ) );
		$gmv         = array_reduce(
			$payments,
			function ( $sum, $p ) {
				return $sum + (float) get_post_meta( $p->ID, '_lnkup_total_amount', true );
			},
			0
		);
		$lnkup_rev   = array_reduce(
			$payments,
			function ( $sum, $p ) {
				return $sum + (float) get_post_meta( $p->ID, '_lnkup_lnkup_fee', true );
			},
			0
		);
		$pending_docs = get_posts(
			array(
				'post_type'      => 'lnkup_document',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_verification_status',
				'meta_value'     => 'pending',
				'fields'         => 'ids',
			)
		);

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'LNKup Marketplace', 'lnkup-marketplace' ); ?></h1>
			<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:1rem;margin-top:1.5rem;">
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( (string) $vendors ); ?></strong><br><?php esc_html_e( 'Vendors', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( (string) $organizers ); ?></strong><br><?php esc_html_e( 'Organizers', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( (string) $events ); ?></strong><br><?php esc_html_e( 'Active Events', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( (string) $applications ); ?></strong><br><?php esc_html_e( 'Applications', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( lnkup_currency( $gmv ) ); ?></strong><br><?php esc_html_e( 'GMV', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( lnkup_currency( $lnkup_rev ) ); ?></strong><br><?php esc_html_e( 'LNKup Revenue', 'lnkup-marketplace' ); ?></div>
				<div class="card" style="padding:1rem;"><strong><?php echo esc_html( (string) count( $pending_docs ) ); ?></strong><br><?php esc_html_e( 'Documents Pending', 'lnkup-marketplace' ); ?></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render settings page.
	 */
	public static function render_settings() {
		if ( ! current_user_can( 'lnkup_manage_settings' ) && ! current_user_can( 'lnkup_manage_all' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'lnkup-marketplace' ) );
		}

		$settings = lnkup_get_settings();
		$doc_types = LNKup_Documents::document_types();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'LNKup Settings', 'lnkup-marketplace' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'lnkup_settings_group' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="default_fee"><?php esc_html_e( 'Default LNKup Fee ($)', 'lnkup-marketplace' ); ?></label></th>
						<td><input type="number" step="0.01" id="default_fee" name="lnkup_settings[default_fee]" value="<?php echo esc_attr( (string) $settings['default_fee'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="stripe_public_key"><?php esc_html_e( 'Stripe Public Key', 'lnkup-marketplace' ); ?></label></th>
						<td><input type="text" class="regular-text" id="stripe_public_key" name="lnkup_settings[stripe_public_key]" value="<?php echo esc_attr( $settings['stripe_public_key'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="stripe_secret_key"><?php esc_html_e( 'Stripe Secret Key', 'lnkup-marketplace' ); ?></label></th>
						<td><input type="password" class="regular-text" id="stripe_secret_key" name="lnkup_settings[stripe_secret_key]" value="<?php echo esc_attr( $settings['stripe_secret_key'] ); ?>" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Enable Test Mode', 'lnkup-marketplace' ); ?></th>
						<td><label><input type="checkbox" name="lnkup_settings[test_mode]" value="1" <?php checked( $settings['test_mode'] ); ?> /> <?php esc_html_e( 'Use payment simulation when Stripe is not configured', 'lnkup-marketplace' ); ?></label></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Default Packet Locking', 'lnkup-marketplace' ); ?></th>
						<td><label><input type="checkbox" name="lnkup_settings[default_packet_lock]" value="1" <?php checked( $settings['default_packet_lock'] ); ?> /> <?php esc_html_e( 'Lock packets until payment', 'lnkup-marketplace' ); ?></label></td>
					</tr>
					<tr>
						<th><label for="support_email"><?php esc_html_e( 'Platform Support Email', 'lnkup-marketplace' ); ?></label></th>
						<td><input type="email" id="support_email" name="lnkup_settings[support_email]" value="<?php echo esc_attr( $settings['support_email'] ); ?>" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Default Required Documents', 'lnkup-marketplace' ); ?></th>
						<td>
							<?php foreach ( $doc_types as $key => $label ) : ?>
								<label style="display:block;"><input type="checkbox" name="lnkup_settings[default_documents][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $settings['default_documents'], true ) ); ?> /> <?php echo esc_html( $label ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Email Notifications', 'lnkup-marketplace' ); ?></th>
						<td>
							<label><input type="checkbox" name="lnkup_settings[notify_vendor]" value="1" <?php checked( $settings['notify_vendor'] ); ?> /> <?php esc_html_e( 'Vendor notifications', 'lnkup-marketplace' ); ?></label><br>
							<label><input type="checkbox" name="lnkup_settings[notify_organizer]" value="1" <?php checked( $settings['notify_organizer'] ); ?> /> <?php esc_html_e( 'Organizer notifications', 'lnkup-marketplace' ); ?></label><br>
							<label><input type="checkbox" name="lnkup_settings[notify_admin]" value="1" <?php checked( $settings['notify_admin'] ); ?> /> <?php esc_html_e( 'Admin notifications', 'lnkup-marketplace' ); ?></label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
