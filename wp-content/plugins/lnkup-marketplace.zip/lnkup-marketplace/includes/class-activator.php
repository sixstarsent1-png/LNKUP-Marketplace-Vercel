<?php
/**
 * Plugin activation and seeding.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Activator {

	/**
	 * Activate plugin.
	 */
	public static function activate() {
		LNKup_Roles::register_roles();
		LNKup_Post_Types::register();
		LNKup_Taxonomies::register();
		LNKup_Taxonomies::seed_terms();
		self::create_pages();
		self::seed_sample_data();
		flush_rewrite_rules();
		update_option( 'lnkup_seeded', LNKUP_VERSION );
	}

	/**
	 * Deactivate plugin.
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}

	/**
	 * Create required pages.
	 */
	public static function create_pages() {
		$pages = array(
			'vendor-dashboard'    => array(
				'title'    => 'Vendor Dashboard',
				'template' => 'page-templates/vendor-dashboard.php',
				'content'  => '[lnkup_vendor_dashboard]',
			),
			'organizer-dashboard' => array(
				'title'    => 'Organizer Dashboard',
				'template' => 'page-templates/organizer-dashboard.php',
				'content'  => '[lnkup_organizer_dashboard]',
			),
			'opportunities'       => array(
				'title'    => 'Find Events',
				'template' => 'page-templates/full-width.php',
				'content'  => '[lnkup_opportunities_feed]',
			),
			'vendor-profile'      => array(
				'title'    => 'Vendor Profile',
				'template' => 'page-templates/full-width.php',
				'content'  => '[lnkup_vendor_profile_form]',
			),
		);

		$created = get_option( 'lnkup_pages_created', array() );

		foreach ( $pages as $slug => $data ) {
			if ( ! empty( $created[ $slug ] ) && get_post( $created[ $slug ] ) ) {
				continue;
			}
			$existing = get_page_by_path( $slug );
			if ( $existing ) {
				$created[ $slug ] = $existing->ID;
				continue;
			}
			$page_id = wp_insert_post(
				array(
					'post_title'   => $data['title'],
					'post_name'    => $slug,
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_content' => $data['content'],
				)
			);
			if ( $page_id && ! is_wp_error( $page_id ) ) {
				update_post_meta( $page_id, '_wp_page_template', $data['template'] );
				$created[ $slug ] = $page_id;
			}
		}

		update_option( 'lnkup_pages_created', $created );

		if ( ! empty( $created['vendor-dashboard'] ) ) {
			update_option( 'show_on_front', 'page' );
			$home = get_option( 'page_on_front' );
			if ( ! $home ) {
				$front = get_page_by_path( 'home' );
				if ( ! $front ) {
					$front_id = wp_insert_post(
						array(
							'post_title'  => 'Home',
							'post_name'   => 'home',
							'post_status' => 'publish',
							'post_type'   => 'page',
						)
					);
					if ( $front_id && ! is_wp_error( $front_id ) ) {
						update_option( 'page_on_front', $front_id );
					}
				}
			}
		}
	}

	/**
	 * Seed sample events and opportunities.
	 */
	public static function seed_sample_data() {
		if ( get_option( 'lnkup_sample_data_seeded' ) ) {
			return;
		}

		$organizer_id = self::get_or_create_demo_organizer();
		$samples      = array(
			array(
				'event' => 'Dirty South Rodeo Charlotte',
				'city'  => 'Charlotte', 'state' => 'NC', 'date' => '2026-08-16',
				'attendance' => 12000, 'type' => 'Rodeo', 'image' => 'rodeo',
				'fee' => 250, 'spots' => 40, 'remaining' => 6,
				'categories' => array( 'Food Truck', 'Drinks', 'Clothing', 'Retail' ),
			),
			array(
				'event' => 'Soul District Block Party',
				'city'  => 'Atlanta', 'state' => 'GA', 'date' => '2026-07-04',
				'attendance' => 8500, 'type' => 'Block Party', 'image' => 'block-party',
				'fee' => 180, 'spots' => 50, 'remaining' => 12,
				'categories' => array( 'Food Vendor', 'Desserts', 'Beauty', 'Art' ),
			),
			array(
				'event' => 'Sunset & Soul Miami',
				'city'  => 'Miami', 'state' => 'FL', 'date' => '2026-09-05',
				'attendance' => 15000, 'type' => 'Festival', 'image' => 'sunset-miami',
				'fee' => 400, 'spots' => 35, 'remaining' => 3,
				'categories' => array( 'Drinks', 'Food Truck', 'Jewelry', 'Clothing' ),
			),
			array(
				'event' => 'NC Greek Picnic',
				'city'  => 'Raleigh', 'state' => 'NC', 'date' => '2026-06-21',
				'attendance' => 20000, 'type' => 'Greek Event', 'image' => 'greek-picnic',
				'fee' => 300, 'spots' => 60, 'remaining' => 9,
				'categories' => array( 'Food Vendor', 'Clothing', 'Photo Booth', 'Services' ),
			),
			array(
				'event' => 'GHOE Vendor Market',
				'city'  => 'Greensboro', 'state' => 'NC', 'date' => '2026-11-01',
				'attendance' => 30000, 'type' => 'Market', 'image' => 'ghoe-market',
				'fee' => 350, 'spots' => 80, 'remaining' => 18,
				'categories' => array( 'Retail', 'Clothing', 'Art', 'Beauty', 'Desserts' ),
			),
		);

		$settings = lnkup_get_settings();

		foreach ( $samples as $sample ) {
			$event_id = wp_insert_post(
				array(
					'post_title'   => $sample['event'],
					'post_status'  => 'publish',
					'post_type'    => 'lnkup_event',
					'post_content' => sprintf(
						/* translators: %s: event name */
						__( 'Vendor opportunities available for %s.', 'lnkup-marketplace' ),
						$sample['event']
					),
				)
			);
			if ( ! $event_id || is_wp_error( $event_id ) ) {
				continue;
			}

			update_post_meta( $event_id, '_lnkup_organizer_user_id', $organizer_id );
			update_post_meta( $event_id, '_lnkup_event_date', $sample['date'] );
			update_post_meta( $event_id, '_lnkup_city', $sample['city'] );
			update_post_meta( $event_id, '_lnkup_state', $sample['state'] );
			update_post_meta( $event_id, '_lnkup_expected_attendance', $sample['attendance'] );
			update_post_meta( $event_id, '_lnkup_ticketing_platform', 'Manual' );
			update_post_meta( $event_id, '_lnkup_status', 'published' );
			update_post_meta( $event_id, '_lnkup_venue_hidden', true );

			wp_set_object_terms( $event_id, $sample['type'], 'lnkup_event_type' );

			$opp_id = wp_insert_post(
				array(
					'post_title'  => $sample['event'] . ' — Vendor Opportunity',
					'post_status' => 'publish',
					'post_type'   => 'lnkup_opportunity',
				)
			);
			if ( ! $opp_id || is_wp_error( $opp_id ) ) {
				continue;
			}

			update_post_meta( $opp_id, '_lnkup_event_id', $event_id );
			update_post_meta( $opp_id, '_lnkup_spots_total', $sample['spots'] );
			update_post_meta( $opp_id, '_lnkup_spots_remaining', $sample['remaining'] );
			update_post_meta( $opp_id, '_lnkup_vendor_fee', $sample['fee'] );
			update_post_meta( $opp_id, '_lnkup_lnkup_fee', $settings['default_fee'] );
			update_post_meta( $opp_id, '_lnkup_application_deadline', gmdate( 'Y-m-d', strtotime( $sample['date'] . ' -30 days' ) ) );
			update_post_meta( $opp_id, '_lnkup_opportunity_status', 'open' );

			wp_set_object_terms( $opp_id, $sample['categories'], 'lnkup_vendor_category' );
		}

		update_option( 'lnkup_sample_data_seeded', true );
	}

	/**
	 * Get or create demo organizer user.
	 */
	private static function get_or_create_demo_organizer() {
		$user = get_user_by( 'login', 'lnkup_demo_organizer' );
		if ( $user ) {
			return $user->ID;
		}
		$id = wp_insert_user(
			array(
				'user_login'   => 'lnkup_demo_organizer',
				'user_pass'    => wp_generate_password(),
				'user_email'   => 'organizer@lnkup.local',
				'display_name' => 'Demo Organizer',
				'role'         => 'lnkup_organizer',
			)
		);
		return is_wp_error( $id ) ? 1 : $id;
	}
}
