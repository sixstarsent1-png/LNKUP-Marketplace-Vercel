<?php
/**
 * AJAX form handlers.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Ajax {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( 'wp_ajax_lnkup_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( 'wp_ajax_lnkup_save_profile', array( __CLASS__, 'handle_save_profile' ) );
		add_action( 'wp_ajax_lnkup_upload_document', array( __CLASS__, 'handle_upload_document' ) );
		add_action( 'wp_ajax_lnkup_review_application', array( __CLASS__, 'handle_review_application' ) );
		add_action( 'wp_ajax_lnkup_create_event', array( __CLASS__, 'handle_create_event' ) );
		add_action( 'wp_ajax_lnkup_create_opportunity', array( __CLASS__, 'handle_create_opportunity' ) );
		add_action( 'wp_ajax_lnkup_download_document', array( 'LNKup_Documents', 'handle_download' ) );
		add_action( 'wp_ajax_lnkup_export_vendors', array( __CLASS__, 'handle_export_vendors' ) );
	}

	/**
	 * Handle vendor application.
	 */
	public static function handle_apply() {
		LNKup_Security::verify_nonce( 'lnkup_apply' );
		LNKup_Capabilities::require_cap( 'lnkup_submit_applications' );

		$opp_id  = isset( $_POST['opportunity_id'] ) ? absint( $_POST['opportunity_id'] ) : 0;
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

		$key = 'lnkup_apply_' . get_current_user_id();
		if ( get_transient( $key ) ) {
			wp_send_json_error( array( 'message' => __( 'Please wait before submitting again.', 'lnkup-marketplace' ) ) );
		}
		set_transient( $key, 1, 30 );

		$result = LNKup_Applications::submit( $opp_id, get_current_user_id(), $message );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Application submitted successfully!', 'lnkup-marketplace' ) ) );
	}

	/**
	 * Handle vendor profile save.
	 */
	public static function handle_save_profile() {
		LNKup_Security::verify_nonce( 'lnkup_profile' );
		LNKup_Capabilities::require_cap( 'lnkup_manage_own_profile' );

		$user_id    = get_current_user_id();
		$profile_id = lnkup_get_vendor_profile_id( $user_id );
		$business   = isset( $_POST['business_name'] ) ? sanitize_text_field( wp_unslash( $_POST['business_name'] ) ) : '';

		if ( ! $business ) {
			wp_send_json_error( array( 'message' => __( 'Business name is required.', 'lnkup-marketplace' ) ) );
		}

		$data = array(
			'post_title'   => $business,
			'post_type'    => 'lnkup_vendor_profile',
			'post_status'  => 'publish',
			'post_content' => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
		);

		if ( $profile_id ) {
			$data['ID'] = $profile_id;
			$profile_id = wp_update_post( $data );
		} else {
			$profile_id = wp_insert_post( $data );
			update_post_meta( $profile_id, '_lnkup_owner_user_id', $user_id );
			update_post_meta( $profile_id, '_lnkup_verification_status', 'pending' );
		}

		$fields = array( 'website', 'instagram', 'tiktok', 'contact_email', 'contact_phone', 'city', 'state', 'setup_type', 'space_needed', 'power_needed', 'water_needed' );
		foreach ( $fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$val = 'contact_email' === $field ? sanitize_email( wp_unslash( $_POST[ $field ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
				update_post_meta( $profile_id, '_lnkup_' . $field, $val );
			}
		}
		if ( isset( $_POST['years_in_business'] ) ) {
			update_post_meta( $profile_id, '_lnkup_years_in_business', absint( $_POST['years_in_business'] ) );
		}
		update_post_meta( $profile_id, '_lnkup_business_name', $business );

		if ( ! empty( $_POST['categories'] ) && is_array( $_POST['categories'] ) ) {
			$cats = array_map( 'sanitize_text_field', wp_unslash( $_POST['categories'] ) );
			wp_set_object_terms( $profile_id, $cats, 'lnkup_vendor_category' );
		}

		wp_send_json_success( array( 'message' => __( 'Profile saved.', 'lnkup-marketplace' ), 'profile_id' => $profile_id ) );
	}

	/**
	 * Handle document upload.
	 */
	public static function handle_upload_document() {
		LNKup_Security::verify_nonce( 'lnkup_document' );
		LNKup_Capabilities::require_cap( 'lnkup_manage_own_documents' );

		$type = isset( $_POST['document_type'] ) ? sanitize_text_field( wp_unslash( $_POST['document_type'] ) ) : '';
		$exp  = isset( $_POST['expiration_date'] ) ? sanitize_text_field( wp_unslash( $_POST['expiration_date'] ) ) : '';

		if ( empty( $_FILES['lnkup_document'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file selected.', 'lnkup-marketplace' ) ) );
		}

		$result = LNKup_Documents::upload( $_FILES['lnkup_document'], get_current_user_id(), $type, $exp );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Document uploaded.', 'lnkup-marketplace' ) ) );
	}

	/**
	 * Handle organizer application review.
	 */
	public static function handle_review_application() {
		LNKup_Security::verify_nonce( 'lnkup_review' );
		LNKup_Capabilities::require_cap( 'lnkup_review_applications' );

		$app_id = isset( $_POST['application_id'] ) ? absint( $_POST['application_id'] ) : 0;
		$action = isset( $_POST['review_action'] ) ? sanitize_text_field( wp_unslash( $_POST['review_action'] ) ) : '';

		$result = LNKup_Applications::handle_organizer_action( $app_id, $action, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Application updated.', 'lnkup-marketplace' ) ) );
	}

	/**
	 * Handle event creation/import.
	 */
	public static function handle_create_event() {
		LNKup_Security::verify_nonce( 'lnkup_event' );
		LNKup_Capabilities::require_cap( 'lnkup_manage_own_events' );

		$name = isset( $_POST['event_name'] ) ? sanitize_text_field( wp_unslash( $_POST['event_name'] ) ) : '';
		if ( ! $name ) {
			wp_send_json_error( array( 'message' => __( 'Event name is required.', 'lnkup-marketplace' ) ) );
		}

		$event_id = wp_insert_post(
			array(
				'post_title'   => $name,
				'post_type'    => 'lnkup_event',
				'post_status'  => 'publish',
				'post_content' => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			)
		);

		update_post_meta( $event_id, '_lnkup_organizer_user_id', get_current_user_id() );
		$meta_fields = array( 'event_date', 'start_time', 'end_time', 'city', 'state', 'venue_name', 'venue_address', 'expected_attendance', 'ticketing_platform', 'ticketing_url' );
		foreach ( $meta_fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$val = 'ticketing_url' === $field ? esc_url_raw( wp_unslash( $_POST[ $field ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
				update_post_meta( $event_id, '_lnkup_' . $field, $val );
			}
		}
		update_post_meta( $event_id, '_lnkup_venue_hidden', ! empty( $_POST['venue_hidden'] ) );
		update_post_meta( $event_id, '_lnkup_status', 'published' );

		if ( ! empty( $_POST['event_type'] ) ) {
			wp_set_object_terms( $event_id, sanitize_text_field( wp_unslash( $_POST['event_type'] ) ), 'lnkup_event_type' );
		}

		wp_send_json_success( array( 'message' => __( 'Event created.', 'lnkup-marketplace' ), 'event_id' => $event_id ) );
	}

	/**
	 * Handle opportunity creation.
	 */
	public static function handle_create_opportunity() {
		LNKup_Security::verify_nonce( 'lnkup_opportunity' );
		LNKup_Capabilities::require_cap( 'lnkup_manage_own_opportunities' );

		$event_id = isset( $_POST['event_id'] ) ? absint( $_POST['event_id'] ) : 0;
		$event    = get_post( $event_id );
		if ( ! $event || ! LNKup_Capabilities::user_owns_post( $event_id, get_current_user_id(), '_lnkup_organizer_user_id' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid event.', 'lnkup-marketplace' ) ) );
		}

		$settings = lnkup_get_settings();
		$spots    = isset( $_POST['spots_total'] ) ? absint( $_POST['spots_total'] ) : 10;
		$fee      = isset( $_POST['vendor_fee'] ) ? LNKup_Security::sanitize_money( $_POST['vendor_fee'] ) : 0;

		$opp_id = wp_insert_post(
			array(
				'post_title'  => $event->post_title . ' — ' . __( 'Vendor Opportunity', 'lnkup-marketplace' ),
				'post_type'   => 'lnkup_opportunity',
				'post_status' => 'publish',
			)
		);

		update_post_meta( $opp_id, '_lnkup_event_id', $event_id );
		update_post_meta( $opp_id, '_lnkup_spots_total', $spots );
		update_post_meta( $opp_id, '_lnkup_spots_remaining', $spots );
		update_post_meta( $opp_id, '_lnkup_vendor_fee', $fee );
		update_post_meta( $opp_id, '_lnkup_lnkup_fee', $settings['default_fee'] );
		update_post_meta( $opp_id, '_lnkup_application_deadline', isset( $_POST['deadline'] ) ? sanitize_text_field( wp_unslash( $_POST['deadline'] ) ) : '' );
		update_post_meta( $opp_id, '_lnkup_opportunity_status', 'open' );
		update_post_meta( $opp_id, '_lnkup_organizer_notes', isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '' );

		if ( ! empty( $_POST['categories'] ) && is_array( $_POST['categories'] ) ) {
			wp_set_object_terms( $opp_id, array_map( 'sanitize_text_field', wp_unslash( $_POST['categories'] ) ), 'lnkup_vendor_category' );
		}

		wp_send_json_success( array( 'message' => __( 'Opportunity created.', 'lnkup-marketplace' ), 'opportunity_id' => $opp_id ) );
	}

	/**
	 * Export vendor list CSV.
	 */
	public static function handle_export_vendors() {
		LNKup_Security::verify_nonce( 'lnkup_export' );
		LNKup_Capabilities::require_cap( 'lnkup_manage_own_events' );

		$event_id = isset( $_GET['event_id'] ) ? absint( $_GET['event_id'] ) : 0;
		if ( ! LNKup_Capabilities::user_owns_post( $event_id, get_current_user_id(), '_lnkup_organizer_user_id' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'lnkup-marketplace' ), 403 );
		}

		$apps = get_posts(
			array(
				'post_type'      => 'lnkup_application',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array( 'key' => '_lnkup_event_id', 'value' => $event_id ),
					array( 'key' => '_lnkup_application_status', 'value' => array( 'paid', 'approved', 'payment_required' ), 'compare' => 'IN' ),
				),
			)
		);

		header( 'Content-Type: text/csv' );
		header( 'Content-Disposition: attachment; filename="vendors-event-' . $event_id . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Vendor', 'Status', 'Submitted', 'Paid' ) );
		foreach ( $apps as $app ) {
			$vendor_id = (int) get_post_meta( $app->ID, '_lnkup_vendor_user_id', true );
			$user      = get_userdata( $vendor_id );
			fputcsv(
				$out,
				array(
					$user ? $user->display_name : '',
					get_post_meta( $app->ID, '_lnkup_application_status', true ),
					get_post_meta( $app->ID, '_lnkup_submitted_at', true ),
					get_post_meta( $app->ID, '_lnkup_paid_at', true ),
				)
			);
		}
		fclose( $out );
		exit;
	}
}
