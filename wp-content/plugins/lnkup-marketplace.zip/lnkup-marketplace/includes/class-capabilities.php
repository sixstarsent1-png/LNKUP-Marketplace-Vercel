<?php
/**
 * Capability and ownership checks.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Capabilities {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_filter( 'map_meta_cap', array( __CLASS__, 'map_meta_cap' ), 10, 4 );
	}

	/**
	 * Map meta capabilities for ownership.
	 *
	 * @param array  $caps    Caps.
	 * @param string $cap     Cap.
	 * @param int    $user_id User ID.
	 * @param array  $args    Args.
	 */
	public static function map_meta_cap( $caps, $cap, $user_id, $args ) {
		if ( user_can( $user_id, 'lnkup_manage_all' ) ) {
			return array( 'lnkup_manage_all' );
		}
		return $caps;
	}

	/**
	 * Check if user owns a post via meta key.
	 *
	 * @param int    $post_id  Post ID.
	 * @param int    $user_id  User ID.
	 * @param string $meta_key Meta key for owner user ID.
	 */
	public static function user_owns_post( $post_id, $user_id, $meta_key = '_lnkup_owner_user_id' ) {
		if ( user_can( $user_id, 'lnkup_manage_all' ) ) {
			return true;
		}
		$owner = (int) get_post_meta( $post_id, $meta_key, true );
		if ( $owner && $owner === (int) $user_id ) {
			return true;
		}
		$vendor_user = (int) get_post_meta( $post_id, '_lnkup_vendor_user_id', true );
		if ( $vendor_user && $vendor_user === (int) $user_id ) {
			return true;
		}
		$organizer_user = (int) get_post_meta( $post_id, '_lnkup_organizer_user_id', true );
		if ( $organizer_user && $organizer_user === (int) $user_id ) {
			return true;
		}
		return false;
	}

	/**
	 * Require capability or die.
	 *
	 * @param string $cap Capability.
	 */
	public static function require_cap( $cap ) {
		if ( ! current_user_can( $cap ) && ! current_user_can( 'lnkup_manage_all' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'lnkup-marketplace' ), 403 );
		}
	}

	/**
	 * Require login.
	 */
	public static function require_login() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( get_permalink() ) );
			exit;
		}
	}
}
