<?php
/**
 * Document upload and verification.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Documents {

	/**
	 * Document types.
	 */
	public static function document_types() {
		return array(
			'certificate_of_insurance' => __( 'Certificate of Insurance', 'lnkup-marketplace' ),
			'health_permit'            => __( 'Health Permit', 'lnkup-marketplace' ),
			'business_license'         => __( 'Business License', 'lnkup-marketplace' ),
			'w9'                       => __( 'W9', 'lnkup-marketplace' ),
			'sales_tax_certificate'    => __( 'Sales Tax Certificate', 'lnkup-marketplace' ),
			'other'                    => __( 'Other', 'lnkup-marketplace' ),
		);
	}

	/**
	 * Upload document.
	 *
	 * @param array $file       $_FILES entry.
	 * @param int   $user_id    User ID.
	 * @param string $type      Document type.
	 */
	public static function upload( $file, $user_id, $type, $expiration = '' ) {
		if ( empty( $file['tmp_name'] ) ) {
			return new WP_Error( 'no_file', __( 'No file uploaded.', 'lnkup-marketplace' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		add_filter( 'upload_mimes', array( 'LNKup_Security', 'filter_upload_mimes' ) );
		$attachment_id = media_handle_upload( 'lnkup_document', 0 );
		remove_filter( 'upload_mimes', array( 'LNKup_Security', 'filter_upload_mimes' ) );

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		$profile_id = lnkup_get_vendor_profile_id( $user_id );
		$types      = self::document_types();
		$label      = $types[ $type ] ?? $type;

		$doc_id = wp_insert_post(
			array(
				'post_title'  => $label . ' — ' . wp_get_current_user()->display_name,
				'post_type'   => 'lnkup_document',
				'post_status' => 'publish',
			)
		);

		update_post_meta( $doc_id, '_lnkup_vendor_user_id', $user_id );
		update_post_meta( $doc_id, '_lnkup_vendor_profile_id', $profile_id );
		update_post_meta( $doc_id, '_lnkup_document_type', sanitize_text_field( $type ) );
		update_post_meta( $doc_id, '_lnkup_attachment_id', $attachment_id );
		update_post_meta( $doc_id, '_lnkup_expiration_date', sanitize_text_field( $expiration ) );
		update_post_meta( $doc_id, '_lnkup_verification_status', 'pending' );

		LNKup_Notifications::send_document_pending_admin( $doc_id );

		return $doc_id;
	}

	/**
	 * Get documents for vendor.
	 *
	 * @param int $user_id User ID.
	 */
	public static function get_for_vendor( $user_id ) {
		return get_posts(
			array(
				'post_type'      => 'lnkup_document',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_vendor_user_id',
				'meta_value'     => $user_id,
			)
		);
	}

	/**
	 * Secure download URL.
	 *
	 * @param int $doc_id Document ID.
	 */
	public static function download_url( $doc_id ) {
		return add_query_arg(
			array(
				'action'   => 'lnkup_download_document',
				'doc_id'   => $doc_id,
				'lnkup_nonce' => wp_create_nonce( 'lnkup_download_' . $doc_id ),
			),
			admin_url( 'admin-ajax.php' )
		);
	}

	/**
	 * Handle secure download.
	 */
	public static function handle_download() {
		$doc_id = isset( $_GET['doc_id'] ) ? absint( $_GET['doc_id'] ) : 0;
		LNKup_Security::verify_nonce( 'lnkup_download_' . $doc_id );

		$vendor_id    = (int) get_post_meta( $doc_id, '_lnkup_vendor_user_id', true );
		$current_user = get_current_user_id();

		if ( $current_user !== $vendor_id && ! current_user_can( 'lnkup_verify_documents' ) && ! current_user_can( 'lnkup_manage_all' ) ) {
			wp_die( esc_html__( 'Access denied.', 'lnkup-marketplace' ), 403 );
		}

		$attachment_id = (int) get_post_meta( $doc_id, '_lnkup_attachment_id', true );
		$file          = get_attached_file( $attachment_id );
		if ( ! $file || ! file_exists( $file ) ) {
			wp_die( esc_html__( 'File not found.', 'lnkup-marketplace' ), 404 );
		}

		$mime = get_post_mime_type( $attachment_id );
		header( 'Content-Type: ' . $mime );
		header( 'Content-Disposition: attachment; filename="' . basename( $file ) . '"' );
		readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}
}
