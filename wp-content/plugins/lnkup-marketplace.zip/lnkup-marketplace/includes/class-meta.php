<?php
/**
 * Post meta registration and admin meta boxes.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Meta {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta_boxes' ), 10, 2 );
	}

	/**
	 * Register post meta.
	 */
	public static function register_meta() {
		$meta_fields = self::get_meta_schema();
		foreach ( $meta_fields as $post_type => $fields ) {
			foreach ( $fields as $key => $config ) {
				register_post_meta(
					$post_type,
					$key,
					array_merge(
						array(
							'single'       => true,
							'show_in_rest' => true,
							'auth_callback' => function () {
								return current_user_can( 'edit_posts' );
							},
						),
						$config
					)
				);
			}
		}
	}

	/**
	 * Meta schema per post type.
	 */
	public static function get_meta_schema() {
		return array(
			'lnkup_vendor_profile' => array(
				'_lnkup_business_name'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_owner_user_id'       => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_website'             => array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ),
				'_lnkup_instagram'           => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_tiktok'              => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_contact_email'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_email' ),
				'_lnkup_contact_phone'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_city'                => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_state'               => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_setup_type'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_space_needed'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_power_needed'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_water_needed'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_years_in_business'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_verification_status' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
			'lnkup_event' => array(
				'_lnkup_organizer_user_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_event_date'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_start_time'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_end_time'            => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_city'                => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_state'               => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_venue_name'          => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_venue_address'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_venue_hidden'        => array( 'type' => 'boolean' ),
				'_lnkup_expected_attendance' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_ticketing_platform'  => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_ticketing_url'       => array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ),
				'_lnkup_status'              => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
			'lnkup_opportunity' => array(
				'_lnkup_event_id'            => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_spots_total'         => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_spots_remaining'     => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_fee'          => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_lnkup_fee'           => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_application_deadline' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_required_documents'  => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_organizer_notes'     => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_opportunity_status'  => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
			'lnkup_application' => array(
				'_lnkup_vendor_profile_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_opportunity_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_event_id'            => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_organizer_user_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_application_status'  => array( 'type' => 'string', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_application_status' ) ),
				'_lnkup_submitted_at'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_approved_at'         => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_payment_due_at'      => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_paid_at'             => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_rejection_reason'    => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_internal_notes'      => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
			),
			'lnkup_document' => array(
				'_lnkup_vendor_user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_profile_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_document_type'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_attachment_id'       => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_expiration_date'     => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_verification_status' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_admin_notes'         => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
			),
			'lnkup_payment' => array(
				'_lnkup_application_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_organizer_user_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_event_id'            => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_opportunity_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_spot_fee'     => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_lnkup_fee'           => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_processing_fee'      => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_total_amount'        => array( 'type' => 'number', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_money' ) ),
				'_lnkup_payment_status'      => array( 'type' => 'string', 'sanitize_callback' => array( 'LNKup_Security', 'sanitize_payment_status' ) ),
				'_lnkup_stripe_payment_intent' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_stripe_transfer_id'  => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_paid_at'             => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
			'lnkup_packet' => array(
				'_lnkup_event_id'            => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_opportunity_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_application_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_vendor_user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_load_in_time'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_load_out_time'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_booth_assignment'    => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_vendor_rules'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_parking_info'        => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_venue_address'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'_lnkup_map_attachment_id'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'_lnkup_qr_pass'             => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'_lnkup_packet_locked'       => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * Add admin meta boxes.
	 */
	public static function add_meta_boxes() {
		$boxes = array(
			'lnkup_event'       => __( 'Event Details', 'lnkup-marketplace' ),
			'lnkup_opportunity' => __( 'Opportunity Details', 'lnkup-marketplace' ),
			'lnkup_application' => __( 'Application Details', 'lnkup-marketplace' ),
		);
		foreach ( $boxes as $post_type => $title ) {
			add_meta_box(
				'lnkup_' . $post_type . '_meta',
				$title,
				array( __CLASS__, 'render_meta_box' ),
				$post_type,
				'normal',
				'high'
			);
		}
	}

	/**
	 * Render generic meta box.
	 *
	 * @param WP_Post $post Post object.
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field( 'lnkup_save_meta', 'lnkup_meta_nonce' );
		$schema = self::get_meta_schema();
		if ( empty( $schema[ $post->post_type ] ) ) {
			return;
		}
		echo '<table class="form-table"><tbody>';
		foreach ( $schema[ $post->post_type ] as $key => $config ) {
			$value = get_post_meta( $post->ID, $key, true );
			$label = str_replace( array( '_lnkup_', '_' ), array( '', ' ' ), $key );
			echo '<tr><th><label for="' . esc_attr( $key ) . '">' . esc_html( ucwords( $label ) ) . '</label></th>';
			echo '<td><input type="text" class="widefat" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $value ) . '" /></td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Save meta boxes.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public static function save_meta_boxes( $post_id, $post ) {
		if ( ! isset( $_POST['lnkup_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lnkup_meta_nonce'] ) ), 'lnkup_save_meta' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$schema = self::get_meta_schema();
		if ( empty( $schema[ $post->post_type ] ) ) {
			return;
		}
		foreach ( $schema[ $post->post_type ] as $key => $config ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] );
			$sanitize = $config['sanitize_callback'] ?? 'sanitize_text_field';
			$value = is_callable( $sanitize ) ? call_user_func( $sanitize, $raw ) : sanitize_text_field( $raw );
			update_post_meta( $post_id, $key, $value );
		}
	}
}
