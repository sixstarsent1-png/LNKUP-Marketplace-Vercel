<?php
/**
 * Email notifications.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Notifications {

	/**
	 * Send branded email.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    HTML body.
	 */
	public static function send( $to, $subject, $body ) {
		$settings = lnkup_get_settings();
		$html     = self::wrap_template( $body );
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );
		return wp_mail( $to, $subject, $html, $headers );
	}

	/**
	 * Email wrapper template.
	 *
	 * @param string $content Content.
	 */
	public static function wrap_template( $content ) {
		ob_start();
		include LNKUP_PLUGIN_DIR . 'templates/emails/wrapper.php';
		return ob_get_clean();
	}

	/**
	 * Send application submitted.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_submitted( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application submitted — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your application has been submitted. The organizer will review it soon.', 'lnkup-marketplace' ) . '</p>'
		);

		$organizer_id = (int) get_post_meta( $app_id, '_lnkup_organizer_user_id', true );
		$organizer    = get_userdata( $organizer_id );
		if ( $organizer && ! empty( $settings['notify_organizer'] ) ) {
			self::send(
				$organizer->user_email,
				__( 'New vendor application — LNKup', 'lnkup-marketplace' ),
				'<p>' . esc_html__( 'A vendor has applied to one of your opportunities.', 'lnkup-marketplace' ) . '</p>'
			);
		}
	}

	/**
	 * Send application approved.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_approved( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application approved — payment required', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Congratulations! You have been approved. Please complete payment to secure your spot.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send payment required.
	 *
	 * @param int $app_id     Application ID.
	 * @param int $payment_id Payment ID.
	 */
	public static function send_payment_required( $app_id, $payment_id ) {
		self::send_application_approved( $app_id );
	}

	/**
	 * Send payment confirmed.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_payment_confirmed( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Payment confirmed — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your payment has been received. Your vendor packet is now unlocked.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send packet unlocked.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_packet_unlocked( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Vendor packet unlocked — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'Your load-in details and QR pass are now available in your dashboard.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Send application rejected.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_rejected( $app_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_vendor'] ) ) {
			return;
		}
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		$reason = get_post_meta( $app_id, '_lnkup_rejection_reason', true );
		$body   = '<p>' . esc_html__( 'Your application was not accepted for this event.', 'lnkup-marketplace' ) . '</p>';
		if ( $reason ) {
			$body .= '<p><strong>' . esc_html__( 'Reason:', 'lnkup-marketplace' ) . '</strong> ' . esc_html( $reason ) . '</p>';
		}
		self::send( $user->user_email, __( 'Application update — LNKup', 'lnkup-marketplace' ), $body );
	}

	/**
	 * Send waitlisted notification.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function send_application_waitlisted( $app_id ) {
		$vendor_id = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$user      = get_userdata( $vendor_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Application waitlisted — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'You have been waitlisted for this opportunity. The organizer may contact you if a spot opens.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Notify organizer of vendor payment.
	 *
	 * @param int $payment_id Payment ID.
	 */
	public static function send_organizer_vendor_paid( $payment_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_organizer'] ) ) {
			return;
		}
		$organizer_id = (int) get_post_meta( $payment_id, '_lnkup_organizer_user_id', true );
		$user         = get_userdata( $organizer_id );
		if ( ! $user ) {
			return;
		}
		self::send(
			$user->user_email,
			__( 'Vendor payment received — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'A vendor has completed payment for your event.', 'lnkup-marketplace' ) . '</p>'
		);
	}

	/**
	 * Notify admin of pending document.
	 *
	 * @param int $doc_id Document ID.
	 */
	public static function send_document_pending_admin( $doc_id ) {
		$settings = lnkup_get_settings();
		if ( empty( $settings['notify_admin'] ) ) {
			return;
		}
		$email = $settings['support_email'] ?: get_option( 'admin_email' );
		self::send(
			$email,
			__( 'Document pending verification — LNKup', 'lnkup-marketplace' ),
			'<p>' . esc_html__( 'A new vendor document requires verification.', 'lnkup-marketplace' ) . '</p>'
		);
	}
}
