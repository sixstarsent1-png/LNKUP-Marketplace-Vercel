<?php
/**
 * Vendor packet lock/unlock logic.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Packets {

	/**
	 * Unlock packet for paid application.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function unlock_for_application( $app_id ) {
		$packets = get_posts(
			array(
				'post_type'      => 'lnkup_packet',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
			)
		);

		if ( $packets ) {
			update_post_meta( $packets[0]->ID, '_lnkup_packet_locked', false );
			LNKup_Notifications::send_packet_unlocked( $app_id );
			return $packets[0]->ID;
		}

		$event_id = (int) get_post_meta( $app_id, '_lnkup_event_id', true );
		$opp_id   = (int) get_post_meta( $app_id, '_lnkup_opportunity_id', true );
		$vendor   = (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true );
		$event    = $event_id ? get_post( $event_id ) : null;
		$settings = lnkup_get_settings();

		$packet_id = wp_insert_post(
			array(
				'post_title'  => sprintf( __( 'Packet: Application #%d', 'lnkup-marketplace' ), $app_id ),
				'post_type'   => 'lnkup_packet',
				'post_status' => 'publish',
			)
		);

		update_post_meta( $packet_id, '_lnkup_application_id', $app_id );
		update_post_meta( $packet_id, '_lnkup_event_id', $event_id );
		update_post_meta( $packet_id, '_lnkup_opportunity_id', $opp_id );
		update_post_meta( $packet_id, '_lnkup_vendor_user_id', $vendor );
		update_post_meta( $packet_id, '_lnkup_packet_locked', false );
		update_post_meta( $packet_id, '_lnkup_qr_pass', 'LNKUP-' . strtoupper( wp_generate_password( 8, false ) ) );

		if ( $event ) {
			$venue = get_post_meta( $event_id, '_lnkup_venue_address', true );
			update_post_meta( $packet_id, '_lnkup_venue_address', $venue );
			update_post_meta( $packet_id, '_lnkup_load_in_time', get_post_meta( $event_id, '_lnkup_start_time', true ) );
			update_post_meta( $packet_id, '_lnkup_vendor_rules', __( 'Follow all venue and organizer guidelines. Check in at vendor registration on arrival.', 'lnkup-marketplace' ) );
		}

		LNKup_Notifications::send_packet_unlocked( $app_id );

		return $packet_id;
	}

	/**
	 * Check if packet is accessible.
	 *
	 * @param int $packet_id Packet ID.
	 */
	public static function is_unlocked( $packet_id ) {
		$locked = get_post_meta( $packet_id, '_lnkup_packet_locked', true );
		if ( false === $locked || '0' === $locked || 0 === $locked ) {
			return true;
		}
		$app_id = (int) get_post_meta( $packet_id, '_lnkup_application_id', true );
		$payment = $app_id ? LNKup_Payments::get_for_application( $app_id ) : null;
		if ( $payment && 'paid' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Get venue address visibility for event.
	 *
	 * @param int $event_id Event ID.
	 * @param int $app_id   Application ID.
	 */
	public static function get_venue_address( $event_id, $app_id = 0 ) {
		$hidden = (bool) get_post_meta( $event_id, '_lnkup_venue_hidden', true );
		if ( ! $hidden ) {
			return get_post_meta( $event_id, '_lnkup_venue_address', true );
		}
		if ( $app_id ) {
			$payment = LNKup_Payments::get_for_application( $app_id );
			if ( $payment && 'paid' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) {
				return get_post_meta( $event_id, '_lnkup_venue_address', true );
			}
		}
		return __( 'Hidden until payment is complete.', 'lnkup-marketplace' );
	}

	/**
	 * Render packet for vendor.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function render_for_vendor( $app_id ) {
		$packets = get_posts(
			array(
				'post_type'      => 'lnkup_packet',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
			)
		);
		if ( ! $packets ) {
			return '<p class="lnkup-empty">' . esc_html__( 'Packet not yet available.', 'lnkup-marketplace' ) . '</p>';
		}

		$packet = $packets[0];
		if ( ! self::is_unlocked( $packet->ID ) ) {
			return '<div class="lnkup-alert lnkup-alert--warning">' . esc_html__( 'Complete payment to unlock your vendor packet.', 'lnkup-marketplace' ) . '</div>';
		}

		ob_start();
		?>
		<div class="lnkup-panel">
			<h3 class="lnkup-panel__title"><?php esc_html_e( 'Vendor Packet', 'lnkup-marketplace' ); ?></h3>
			<p><strong><?php esc_html_e( 'QR Pass:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_qr_pass', true ) ); ?></p>
			<p><strong><?php esc_html_e( 'Load-in:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_load_in_time', true ) ?: '—' ); ?></p>
			<p><strong><?php esc_html_e( 'Booth:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_booth_assignment', true ) ?: __( 'TBD', 'lnkup-marketplace' ) ); ?></p>
			<p><strong><?php esc_html_e( 'Venue:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_venue_address', true ) ); ?></p>
			<p><strong><?php esc_html_e( 'Parking:', 'lnkup-marketplace' ); ?></strong> <?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_parking_info', true ) ?: '—' ); ?></p>
			<p><?php echo esc_html( get_post_meta( $packet->ID, '_lnkup_vendor_rules', true ) ); ?></p>
		</div>
		<?php
		return ob_get_clean();
	}
}
