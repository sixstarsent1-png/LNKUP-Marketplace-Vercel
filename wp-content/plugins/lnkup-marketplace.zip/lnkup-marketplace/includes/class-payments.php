<?php
/**
 * Payment records and fee logic.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Payments {

	/**
	 * Create payment from approved application.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function create_from_application( $app_id ) {
		$existing = get_posts(
			array(
				'post_type'      => 'lnkup_payment',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
				'fields'         => 'ids',
			)
		);
		if ( $existing ) {
			return $existing[0];
		}

		$opp_id       = (int) get_post_meta( $app_id, '_lnkup_opportunity_id', true );
		$vendor_fee   = (float) get_post_meta( $opp_id, '_lnkup_vendor_fee', true );
		$lnkup_fee    = (float) get_post_meta( $opp_id, '_lnkup_lnkup_fee', true );
		if ( ! $lnkup_fee ) {
			$settings  = lnkup_get_settings();
			$lnkup_fee = (float) $settings['default_fee'];
		}
		$processing   = round( ( $vendor_fee + $lnkup_fee ) * 0.029 + 0.30, 2 );
		$total        = $vendor_fee + $lnkup_fee + $processing;

		$payment_id = wp_insert_post(
			array(
				'post_title'  => sprintf( __( 'Payment for Application #%d', 'lnkup-marketplace' ), $app_id ),
				'post_type'   => 'lnkup_payment',
				'post_status' => 'publish',
			)
		);

		update_post_meta( $payment_id, '_lnkup_application_id', $app_id );
		update_post_meta( $payment_id, '_lnkup_vendor_user_id', (int) get_post_meta( $app_id, '_lnkup_vendor_user_id', true ) );
		update_post_meta( $payment_id, '_lnkup_organizer_user_id', (int) get_post_meta( $app_id, '_lnkup_organizer_user_id', true ) );
		update_post_meta( $payment_id, '_lnkup_event_id', (int) get_post_meta( $app_id, '_lnkup_event_id', true ) );
		update_post_meta( $payment_id, '_lnkup_opportunity_id', $opp_id );
		update_post_meta( $payment_id, '_lnkup_vendor_spot_fee', $vendor_fee );
		update_post_meta( $payment_id, '_lnkup_lnkup_fee', $lnkup_fee );
		update_post_meta( $payment_id, '_lnkup_processing_fee', $processing );
		update_post_meta( $payment_id, '_lnkup_total_amount', $total );
		update_post_meta( $payment_id, '_lnkup_payment_status', 'pending' );

		LNKup_Notifications::send_payment_required( $app_id, $payment_id );

		return $payment_id;
	}

	/**
	 * Mark payment as paid.
	 *
	 * @param int    $payment_id Payment ID.
	 * @param string $intent_id  Stripe intent ID.
	 */
	public static function mark_paid( $payment_id, $intent_id = '' ) {
		update_post_meta( $payment_id, '_lnkup_payment_status', 'paid' );
		update_post_meta( $payment_id, '_lnkup_paid_at', current_time( 'mysql' ) );
		if ( $intent_id ) {
			update_post_meta( $payment_id, '_lnkup_stripe_payment_intent', sanitize_text_field( $intent_id ) );
		}

		$app_id = (int) get_post_meta( $payment_id, '_lnkup_application_id', true );
		if ( $app_id ) {
			update_post_meta( $app_id, '_lnkup_application_status', 'paid' );
			update_post_meta( $app_id, '_lnkup_paid_at', current_time( 'mysql' ) );
			LNKup_Applications::transition( $app_id, 'paid' );
		}

		LNKup_Notifications::send_organizer_vendor_paid( $payment_id );

		return true;
	}

	/**
	 * Get payment for application.
	 *
	 * @param int $app_id Application ID.
	 */
	public static function get_for_application( $app_id ) {
		$posts = get_posts(
			array(
				'post_type'      => 'lnkup_payment',
				'posts_per_page' => 1,
				'meta_key'       => '_lnkup_application_id',
				'meta_value'     => $app_id,
			)
		);
		return $posts[0] ?? null;
	}
}
