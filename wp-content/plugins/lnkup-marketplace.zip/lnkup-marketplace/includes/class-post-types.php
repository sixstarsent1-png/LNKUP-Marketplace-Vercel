<?php
/**
 * Custom post types.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Post_Types {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register all CPTs.
	 */
	public static function register() {
		$types = array(
			'lnkup_vendor_profile' => array(
				'label'  => __( 'Vendor Profiles', 'lnkup-marketplace' ),
				'public' => false,
				'show_ui' => true,
				'menu_icon' => 'dashicons-store',
				'supports' => array( 'title', 'editor', 'thumbnail' ),
			),
			'lnkup_event' => array(
				'label'  => __( 'Events', 'lnkup-marketplace' ),
				'public' => true,
				'show_ui' => true,
				'menu_icon' => 'dashicons-calendar-alt',
				'supports' => array( 'title', 'editor', 'thumbnail' ),
				'has_archive' => false,
			),
			'lnkup_opportunity' => array(
				'label'  => __( 'Opportunities', 'lnkup-marketplace' ),
				'public' => true,
				'show_ui' => true,
				'menu_icon' => 'dashicons-tickets-alt',
				'supports' => array( 'title', 'editor' ),
			),
			'lnkup_application' => array(
				'label'  => __( 'Applications', 'lnkup-marketplace' ),
				'public' => false,
				'show_ui' => true,
				'menu_icon' => 'dashicons-clipboard',
				'supports' => array( 'title', 'editor' ),
			),
			'lnkup_document' => array(
				'label'  => __( 'Documents', 'lnkup-marketplace' ),
				'public' => false,
				'show_ui' => true,
				'menu_icon' => 'dashicons-media-document',
				'supports' => array( 'title' ),
			),
			'lnkup_payment' => array(
				'label'  => __( 'Payments', 'lnkup-marketplace' ),
				'public' => false,
				'show_ui' => true,
				'menu_icon' => 'dashicons-money-alt',
				'supports' => array( 'title' ),
			),
			'lnkup_packet' => array(
				'label'  => __( 'Vendor Packets', 'lnkup-marketplace' ),
				'public' => false,
				'show_ui' => true,
				'menu_icon' => 'dashicons-portfolio',
				'supports' => array( 'title', 'editor' ),
			),
		);

		foreach ( $types as $slug => $args ) {
			register_post_type(
				$slug,
				array_merge(
					array(
						'labels'       => array(
							'name'          => $args['label'],
							'singular_name' => $args['label'],
						),
						'public'       => $args['public'],
						'show_ui'      => $args['show_ui'],
						'show_in_rest' => true,
						'menu_icon'    => $args['menu_icon'],
						'supports'     => $args['supports'],
						'capability_type' => 'post',
						'map_meta_cap' => true,
					),
					isset( $args['has_archive'] ) ? array( 'has_archive' => $args['has_archive'] ) : array()
				)
			);
		}
	}
}
