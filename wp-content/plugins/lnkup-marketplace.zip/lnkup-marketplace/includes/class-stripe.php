<?php
/**
 * Stripe gateway abstraction.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Stripe {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( 'wp_ajax_lnkup_create_checkout', array( __CLASS__, 'ajax_create_checkout' ) );
		add_action( 'wp_ajax_lnkup_simulate_payment', array( __CLASS__, 'ajax_simulate_payment' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_webhook' ) );
	}

	/**
	 * Check if Stripe is configured.
	 */
	public static function is_configured() {
		$settings = lnkup_get_settings();
		return ! empty( $settings['stripe_secret_key'] ) && ! empty( $settings['stripe_public_key'] );
	}

	/**
	 * Create checkout session or return simulation URL.
	 *
	 * @param int $payment_id Payment ID.
	 */
	public static function create_checkout( $payment_id ) {
		$payment = get_post( $payment_id );
		if ( ! $payment || 'lnkup_payment' !== $payment->post_type ) {
			return new WP_Error( 'invalid', __( 'Invalid payment.', 'lnkup-marketplace' ) );
		}

		$vendor_id = (int) get_post_meta( $payment_id, '_lnkup_vendor_user_id', true );
		if ( get_current_user_id() !== $vendor_id && ! current_user_can( 'lnkup_manage_all' ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'lnkup-marketplace' ) );
		}

		$settings = lnkup_get_settings();
		$total    = (float) get_post_meta( $payment_id, '_lnkup_total_amount', true );
		$amount   = (int) round( $total * 100 );

		if ( ! self::is_configured() || $settings['test_mode'] ) {
			return array(
				'mode' => 'simulation',
				'url'  => add_query_arg(
					array(
						'action'     => 'lnkup_simulate_payment',
						'payment_id' => $payment_id,
						'lnkup_nonce' => wp_create_nonce( 'lnkup_simulate_' . $payment_id ),
					),
					admin_url( 'admin-ajax.php' )
				),
			);
		}

		$response = wp_remote_post(
			'https://api.stripe.com/v1/checkout/sessions',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $settings['stripe_secret_key'],
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => array(
					'mode'                 => 'payment',
					'success_url'          => add_query_arg( array( 'lnkup_payment' => 'success', 'payment_id' => $payment_id ), lnkup_page_url_helper( 'vendor-dashboard' ) ),
					'cancel_url'           => add_query_arg( array( 'lnkup_payment' => 'cancel' ), lnkup_page_url_helper( 'vendor-dashboard' ) ),
					'client_reference_id'  => (string) $payment_id,
					'line_items[0][price_data][currency]' => 'usd',
					'line_items[0][price_data][product_data][name]' => $payment->post_title,
					'line_items[0][price_data][unit_amount]' => $amount,
					'line_items[0][quantity]' => 1,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['url'] ) ) {
			return new WP_Error( 'stripe_error', __( 'Could not create checkout session.', 'lnkup-marketplace' ) );
		}

		if ( ! empty( $body['payment_intent'] ) ) {
			update_post_meta( $payment_id, '_lnkup_stripe_payment_intent', sanitize_text_field( $body['payment_intent'] ) );
		}

		return array(
			'mode' => 'stripe',
			'url'  => $body['url'],
		);
	}

	/**
	 * AJAX: create checkout.
	 */
	public static function ajax_create_checkout() {
		$payment_id = isset( $_POST['payment_id'] ) ? absint( $_POST['payment_id'] ) : 0;
		if ( isset( $_POST['lnkup_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lnkup_nonce'] ) ), 'lnkup_action' ) ) {
			// ok
		} elseif ( isset( $_POST['lnkup_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lnkup_nonce'] ) ), 'lnkup_checkout' ) ) {
			// ok
		} else {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'lnkup-marketplace' ) ) );
		}
		$payment_id = isset( $_POST['payment_id'] ) ? absint( $_POST['payment_id'] ) : 0;
		$result = self::create_checkout( $payment_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( $result );
	}

	/**
	 * AJAX: simulate payment in test mode.
	 */
	public static function ajax_simulate_payment() {
		$payment_id = isset( $_GET['payment_id'] ) ? absint( $_GET['payment_id'] ) : 0;
		LNKup_Security::verify_nonce( 'lnkup_simulate_' . $payment_id );
		LNKup_Payments::mark_paid( $payment_id, 'sim_' . wp_generate_password( 12, false ) );
		wp_safe_redirect( add_query_arg( 'lnkup_payment', 'success', lnkup_page_url_helper( 'vendor-dashboard' ) ) );
		exit;
	}

	/**
	 * Register Stripe webhook endpoint.
	 */
	public static function register_webhook() {
		register_rest_route(
			'lnkup/v1',
			'/stripe-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_webhook' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Handle Stripe webhook.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public static function handle_webhook( $request ) {
		$payload = $request->get_json_params();
		if ( empty( $payload['type'] ) || 'checkout.session.completed' !== $payload['type'] ) {
			return new WP_REST_Response( array( 'received' => true ), 200 );
		}

		$session    = $payload['data']['object'] ?? array();
		$payment_id = isset( $session['client_reference_id'] ) ? absint( $session['client_reference_id'] ) : 0;
		$intent     = $session['payment_intent'] ?? '';

		if ( $payment_id ) {
			LNKup_Payments::mark_paid( $payment_id, $intent );
		}

		return new WP_REST_Response( array( 'received' => true ), 200 );
	}
}
