<?php
/**
 * Taxonomies.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Taxonomies {

	/**
	 * Init hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register taxonomies.
	 */
	public static function register() {
		register_taxonomy(
			'lnkup_vendor_category',
			array( 'lnkup_vendor_profile', 'lnkup_opportunity' ),
			array(
				'label'        => __( 'Vendor Categories', 'lnkup-marketplace' ),
				'public'       => true,
				'show_ui'      => true,
				'show_in_rest' => true,
				'hierarchical' => false,
			)
		);

		register_taxonomy(
			'lnkup_event_type',
			array( 'lnkup_event' ),
			array(
				'label'        => __( 'Event Types', 'lnkup-marketplace' ),
				'public'       => true,
				'show_ui'      => true,
				'show_in_rest' => true,
				'hierarchical' => false,
			)
		);

		register_taxonomy(
			'lnkup_market',
			array( 'lnkup_event', 'lnkup_opportunity' ),
			array(
				'label'        => __( 'Markets', 'lnkup-marketplace' ),
				'public'       => true,
				'show_ui'      => true,
				'show_in_rest' => true,
				'hierarchical' => true,
			)
		);
	}

	/**
	 * Seed default terms.
	 */
	public static function seed_terms() {
		$vendor_categories = array(
			'Food Vendor', 'Food Truck', 'Desserts', 'Drinks', 'Retail', 'Clothing',
			'Beauty', 'Jewelry', 'Art', 'Photo Booth', 'Services', 'Wellness', 'Merchandise',
		);
		foreach ( $vendor_categories as $term ) {
			if ( ! term_exists( $term, 'lnkup_vendor_category' ) ) {
				wp_insert_term( $term, 'lnkup_vendor_category' );
			}
		}

		$event_types = array(
			'Festival', 'Rodeo', 'Homecoming', 'Greek Event', 'Day Party', 'Block Party',
			'Food Festival', 'Market', 'Community Event', 'Cultural Event', 'College Event', 'Nightlife Event',
		);
		foreach ( $event_types as $term ) {
			if ( ! term_exists( $term, 'lnkup_event_type' ) ) {
				wp_insert_term( $term, 'lnkup_event_type' );
			}
		}
	}
}
