<?php
/**
 * Helper functions.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

/**
 * Format currency.
 *
 * @param float $amount Amount.
 */
function lnkup_currency( $amount ) {
	return '$' . number_format( (float) $amount, 2 );
}

/**
 * Get vendor profile for user.
 *
 * @param int $user_id User ID.
 */
function lnkup_get_vendor_profile_id( $user_id = 0 ) {
	$user_id = $user_id ?: get_current_user_id();
	$posts = get_posts(
		array(
			'post_type'      => 'lnkup_vendor_profile',
			'posts_per_page' => 1,
			'meta_key'       => '_lnkup_owner_user_id',
			'meta_value'     => $user_id,
			'fields'         => 'ids',
		)
	);
	return $posts[0] ?? 0;
}

/**
 * Get featured opportunities.
 *
 * @param int $limit Limit.
 */
function lnkup_get_featured_opportunities( $limit = 6 ) {
	$posts = get_posts(
		array(
			'post_type'      => 'lnkup_opportunity',
			'posts_per_page' => $limit,
			'post_status'    => 'publish',
			'meta_query'     => array(
				array(
					'key'   => '_lnkup_opportunity_status',
					'value' => 'open',
				),
			),
		)
	);
	$result = array();
	foreach ( $posts as $post ) {
		$result[] = lnkup_format_opportunity( $post );
	}
	return $result;
}

/**
 * Format opportunity for display.
 *
 * @param WP_Post $opp Opportunity post.
 */
function lnkup_format_opportunity( $opp ) {
	$event_id = (int) get_post_meta( $opp->ID, '_lnkup_event_id', true );
	$event    = $event_id ? get_post( $event_id ) : null;
	$terms    = wp_get_post_terms( $opp->ID, 'lnkup_vendor_category', array( 'fields' => 'names' ) );

	return array(
		'id'           => $opp->ID,
		'name'         => $event ? $event->post_title : $opp->post_title,
		'city'         => $event ? get_post_meta( $event_id, '_lnkup_city', true ) : '',
		'state'        => $event ? get_post_meta( $event_id, '_lnkup_state', true ) : '',
		'date'         => $event ? get_post_meta( $event_id, '_lnkup_event_date', true ) : '',
		'attendance'   => $event ? (int) get_post_meta( $event_id, '_lnkup_expected_attendance', true ) : 0,
		'vendor_fee'   => (float) get_post_meta( $opp->ID, '_lnkup_vendor_fee', true ),
		'spots_remaining' => (int) get_post_meta( $opp->ID, '_lnkup_spots_remaining', true ),
		'total_spots'  => (int) get_post_meta( $opp->ID, '_lnkup_spots_total', true ),
		'categories'   => is_array( $terms ) ? $terms : array(),
		'deadline'     => get_post_meta( $opp->ID, '_lnkup_application_deadline', true ),
		'opportunity_id' => $opp->ID,
		'event_id'     => $event_id,
	);
}

/**
 * Render event card HTML.
 *
 * @param array $opp Opportunity data.
 */
function lnkup_render_event_card( $opp ) {
	$low_spots = ( $opp['spots_remaining'] ?? 0 ) <= 5;
	$apply_url = add_query_arg( array( 'apply' => $opp['opportunity_id'] ?? $opp['id'] ), lnkup_page_url_helper( 'opportunities' ) );

	ob_start();
	?>
	<article class="lnkup-event-card">
		<div class="lnkup-event-card__media">
			<div style="width:100%;height:100%;background:linear-gradient(135deg, var(--accent), var(--muted));"></div>
			<span class="lnkup-badge" style="position:absolute;top:0.75rem;left:0.75rem;"><?php echo esc_html( lnkup_currency( $opp['vendor_fee'] ) ); ?> vendor fee</span>
			<?php if ( $low_spots ) : ?>
				<span class="lnkup-badge lnkup-badge--destructive" style="position:absolute;top:0.75rem;right:0.75rem;"><?php echo esc_html( (string) $opp['spots_remaining'] ); ?> spots left</span>
			<?php endif; ?>
		</div>
		<div class="lnkup-event-card__body">
			<h3><?php echo esc_html( $opp['name'] ); ?></h3>
			<div class="lnkup-event-card__meta">
				<span><?php echo esc_html( $opp['city'] . ', ' . $opp['state'] ); ?></span>
				<?php if ( ! empty( $opp['date'] ) ) : ?>
					<span><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $opp['date'] ) ) ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $opp['attendance'] ) ) : ?>
					<span><?php echo esc_html( number_format( $opp['attendance'] ) ); ?> expected attendance</span>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $opp['categories'] ) ) : ?>
				<div style="display:flex;flex-wrap:wrap;gap:0.375rem;">
					<?php foreach ( array_slice( $opp['categories'], 0, 3 ) as $cat ) : ?>
						<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( $cat ); ?></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="lnkup-event-card__footer">
				<span class="lnkup-badge lnkup-badge--secondary"><?php echo esc_html( (string) $opp['spots_remaining'] . '/' . $opp['total_spots'] ); ?> spots</span>
				<a href="<?php echo esc_url( $apply_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Apply', 'lnkup-marketplace' ); ?></a>
			</div>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Page URL helper (works without theme).
 *
 * @param string $slug Page slug.
 */
function lnkup_page_url_helper( $slug ) {
	$pages = get_option( 'lnkup_pages_created', array() );
	if ( ! empty( $pages[ $slug ] ) ) {
		return get_permalink( $pages[ $slug ] );
	}
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Query applications for user.
 *
 * @param int    $user_id User ID.
 * @param string $role    vendor|organizer.
 */
function lnkup_get_applications_for_user( $user_id, $role = 'vendor' ) {
	$key = 'vendor' === $role ? '_lnkup_vendor_user_id' : '_lnkup_organizer_user_id';
	return get_posts(
		array(
			'post_type'      => 'lnkup_application',
			'posts_per_page' => -1,
			'meta_key'       => $key,
			'meta_value'     => $user_id,
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);
}

/**
 * Get payments for user.
 *
 * @param int    $user_id User ID.
 * @param string $role    vendor|organizer.
 */
function lnkup_get_payments_for_user( $user_id, $role = 'vendor' ) {
	$key = 'vendor' === $role ? '_lnkup_vendor_user_id' : '_lnkup_organizer_user_id';
	return get_posts(
		array(
			'post_type'      => 'lnkup_payment',
			'posts_per_page' => -1,
			'meta_key'       => $key,
			'meta_value'     => $user_id,
		)
	);
}
