<?php
/**
 * Plugin Name: LNKup Marketplace
 * Plugin URI: https://lnkup.com
 * Description: Custom marketplace functionality for LNKup — vendor opportunities, applications, payments, and event management.
 * Version: 1.0.0
 * Author: LNKup
 * Author URI: https://lnkup.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: lnkup-marketplace
 * Requires at least: 6.0
 * Requires PHP: 8.0
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

define( 'LNKUP_VERSION', '1.0.0' );
define( 'LNKUP_PLUGIN_FILE', __FILE__ );
define( 'LNKUP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LNKUP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once LNKUP_PLUGIN_DIR . 'includes/class-security.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-roles.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-post-types.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-taxonomies.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-meta.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-capabilities.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-activator.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-applications.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-payments.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-packets.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-stripe.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-documents.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-notifications.php';
require_once LNKUP_PLUGIN_DIR . 'includes/class-ajax.php';
require_once LNKUP_PLUGIN_DIR . 'includes/helpers.php';
require_once LNKUP_PLUGIN_DIR . 'public/class-shortcodes.php';
require_once LNKUP_PLUGIN_DIR . 'admin/class-admin.php';

register_activation_hook( __FILE__, array( 'LNKup_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'LNKup_Activator', 'deactivate' ) );

/**
 * Bootstrap plugin.
 */
function lnkup_marketplace_init() {
	LNKup_Roles::init();
	LNKup_Post_Types::init();
	LNKup_Taxonomies::init();
	LNKup_Meta::init();
	LNKup_Capabilities::init();
	LNKup_Shortcodes::init();
	LNKup_Admin::init();
	LNKup_Ajax::init();
	LNKup_Stripe::init();
}
add_action( 'plugins_loaded', 'lnkup_marketplace_init' );

/**
 * Get plugin settings with defaults.
 */
function lnkup_get_settings() {
	$defaults = array(
		'default_fee'           => 19.99,
		'stripe_public_key'     => '',
		'stripe_secret_key'     => '',
		'test_mode'             => true,
		'default_packet_lock'   => true,
		'default_documents'     => array( 'certificate_of_insurance', 'business_license' ),
		'notify_vendor'         => true,
		'notify_organizer'      => true,
		'notify_admin'          => true,
		'support_email'         => get_option( 'admin_email' ),
	);
	return wp_parse_args( get_option( 'lnkup_settings', array() ), $defaults );
}
