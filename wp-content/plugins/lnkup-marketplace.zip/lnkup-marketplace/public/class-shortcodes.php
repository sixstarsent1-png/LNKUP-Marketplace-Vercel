<?php
/**
 * Frontend shortcodes.
 *
 * @package LNKup_Marketplace
 */

defined( 'ABSPATH' ) || exit;

class LNKup_Shortcodes {

	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$codes = array(
			'lnkup_vendor_dashboard',
			'lnkup_organizer_dashboard',
			'lnkup_opportunities_feed',
			'lnkup_vendor_profile_form',
			'lnkup_organizer_events',
			'lnkup_applications_manager',
			'lnkup_documents_manager',
			'lnkup_payments_dashboard',
		);
		foreach ( $codes as $code ) {
			add_shortcode( $code, array( __CLASS__, str_replace( 'lnkup_', 'render_', $code ) ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue plugin frontend assets.
	 */
	public static function enqueue_assets() {
		wp_enqueue_script(
			'lnkup-marketplace',
			LNKUP_PLUGIN_URL . 'public/js/marketplace.js',
			array(),
			LNKUP_VERSION,
			true
		);
		wp_localize_script(
			'lnkup-marketplace',
			'lnkupAjax',
			array(
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'lnkup_action' ),
			)
		);
	}

	/**
	 * Vendor dashboard shortcode.
	 */
	public static function render_vendor_dashboard() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_vendor() && ! current_user_can( 'lnkup_manage_all' ) ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Vendor access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$user_id      = get_current_user_id();
		$applications = lnkup_get_applications_for_user( $user_id, 'vendor' );
		$payments     = lnkup_get_payments_for_user( $user_id, 'vendor' );
		$documents    = LNKup_Documents::get_for_vendor( $user_id );
		$profile_id   = lnkup_get_vendor_profile_id( $user_id );
		$opportunities = lnkup_get_featured_opportunities( 3 );

		$pending_apps = array_filter(
			$applications,
			function ( $a ) {
				$s = get_post_meta( $a->ID, '_lnkup_application_status', true );
				return in_array( $s, array( 'submitted', 'under_review', 'approved', 'payment_required' ), true );
			}
		);
		$due_payments = array_filter(
			$payments,
			function ( $p ) {
				return 'pending' === get_post_meta( $p->ID, '_lnkup_payment_status', true );
			}
		);
		$missing_docs = array_filter(
			$documents,
			function ( $d ) {
				return 'approved' !== get_post_meta( $d->ID, '_lnkup_verification_status', true );
			}
		);

		ob_start();
		?>
		<div class="lnkup-mp">
			<?php if ( isset( $_GET['lnkup_payment'] ) && 'success' === $_GET['lnkup_payment'] ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="lnkup-alert lnkup-alert--success"><?php esc_html_e( 'Payment successful! Your packet is unlocked.', 'lnkup-marketplace' ); ?></div>
			<?php endif; ?>

			<p class="lnkup-muted"><?php printf( esc_html__( 'Welcome back, %s', 'lnkup-marketplace' ), esc_html( wp_get_current_user()->display_name ) ); ?></p>

			<div class="lnkup-grid lnkup-grid--4" style="margin-bottom:1.5rem;">
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $pending_apps ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Active applications', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( array_filter( $applications, fn( $a ) => 'paid' === get_post_meta( $a->ID, '_lnkup_application_status', true ) ) ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Confirmed bookings', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $due_payments ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Payments due', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $missing_docs ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Documents needed', 'lnkup-marketplace' ); ?></p></div>
			</div>

			<?php if ( $due_payments ) : ?>
				<div class="lnkup-panel" id="payments">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Payments Due', 'lnkup-marketplace' ); ?></h2>
					<?php foreach ( $due_payments as $payment ) : ?>
						<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
							<span><?php echo esc_html( $payment->post_title ); ?> — <strong><?php echo esc_html( lnkup_currency( get_post_meta( $payment->ID, '_lnkup_total_amount', true ) ) ); ?></strong></span>
							<button type="button" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm lnkup-pay-btn" data-payment-id="<?php echo esc_attr( (string) $payment->ID ); ?>"><?php esc_html_e( 'Pay Now', 'lnkup-marketplace' ); ?></button>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="lnkup-panel" id="applications">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Recent Applications', 'lnkup-marketplace' ); ?></h2>
				<?php if ( $applications ) : ?>
					<table class="lnkup-table">
						<thead><tr><th><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></th><th><?php esc_html_e( 'Status', 'lnkup-marketplace' ); ?></th><th><?php esc_html_e( 'Submitted', 'lnkup-marketplace' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( array_slice( $applications, 0, 10 ) as $app ) : ?>
							<?php
							$event_id = (int) get_post_meta( $app->ID, '_lnkup_event_id', true );
							$event    = $event_id ? get_post( $event_id ) : null;
							$status   = get_post_meta( $app->ID, '_lnkup_application_status', true );
							?>
							<tr>
								<td><?php echo esc_html( $event ? $event->post_title : $app->post_title ); ?></td>
								<td><span class="lnkup-status lnkup-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( str_replace( '_', ' ', $status ) ); ?></span></td>
								<td><?php echo esc_html( get_post_meta( $app->ID, '_lnkup_submitted_at', true ) ); ?></td>
							</tr>
							<?php if ( 'paid' === $status ) : ?>
								<tr><td colspan="3"><?php echo LNKup_Packets::render_for_vendor( $app->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr>
							<?php endif; ?>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<p class="lnkup-empty"><?php esc_html_e( 'No applications yet.', 'lnkup-marketplace' ); ?></p>
				<?php endif; ?>
			</div>

			<div class="lnkup-panel" id="documents">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Documents', 'lnkup-marketplace' ); ?></h2>
				<?php echo self::render_documents_manager(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<div class="lnkup-panel">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Recommended Opportunities', 'lnkup-marketplace' ); ?></h2>
				<div class="lnkup-event-grid">
					<?php foreach ( $opportunities as $opp ) : ?>
						<?php echo lnkup_render_event_card( $opp ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endforeach; ?>
				</div>
			</div>

			<?php if ( ! $profile_id ) : ?>
				<div class="lnkup-alert lnkup-alert--warning"><?php esc_html_e( 'Complete your vendor profile to start applying.', 'lnkup-marketplace' ); ?> <a href="<?php echo esc_url( lnkup_page_url_helper( 'vendor-profile' ) ); ?>"><?php esc_html_e( 'Create profile', 'lnkup-marketplace' ); ?></a></div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Organizer dashboard shortcode.
	 */
	public static function render_organizer_dashboard() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_organizer() && ! current_user_can( 'lnkup_manage_all' ) ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Organizer access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$user_id = get_current_user_id();
		$events  = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);
		$opps = get_posts(
			array(
				'post_type'      => 'lnkup_opportunity',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'     => '_lnkup_event_id',
						'value'   => wp_list_pluck( $events, 'ID' ),
						'compare' => 'IN',
					),
				),
			)
		);
		$apps     = lnkup_get_applications_for_user( $user_id, 'organizer' );
		$new_apps = array_filter(
			$apps,
			function ( $a ) {
				return 'submitted' === get_post_meta( $a->ID, '_lnkup_application_status', true );
			}
		);
		$payments = lnkup_get_payments_for_user( $user_id, 'organizer' );
		$collected = array_reduce(
			$payments,
			function ( $sum, $p ) {
				if ( 'paid' === get_post_meta( $p->ID, '_lnkup_payment_status', true ) ) {
					return $sum + (float) get_post_meta( $p->ID, '_lnkup_vendor_spot_fee', true );
				}
				return $sum;
			},
			0
		);

		ob_start();
		?>
		<div class="lnkup-mp">
			<div class="lnkup-grid lnkup-grid--4" style="margin-bottom:1.5rem;">
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $events ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Upcoming events', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $opps ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Open opportunities', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( (string) count( $new_apps ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'New applications', 'lnkup-marketplace' ); ?></p></div>
				<div class="lnkup-stat-card"><p class="lnkup-stat-card__value"><?php echo esc_html( lnkup_currency( $collected ) ); ?></p><p class="lnkup-stat-card__label"><?php esc_html_e( 'Payments collected', 'lnkup-marketplace' ); ?></p></div>
			</div>

			<div class="lnkup-panel" id="import">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Import Event', 'lnkup-marketplace' ); ?></h2>
				<p class="lnkup-muted"><?php esc_html_e( 'Paste a Posh, Eventbrite, or Universe URL, then confirm event details manually.', 'lnkup-marketplace' ); ?></p>
				<?php echo self::render_event_import_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<div class="lnkup-panel" id="events">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Your Events', 'lnkup-marketplace' ); ?></h2>
				<?php echo self::render_organizer_events(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<div class="lnkup-panel" id="applications">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Review Applications', 'lnkup-marketplace' ); ?></h2>
				<?php echo self::render_applications_manager(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<div class="lnkup-panel" id="payments">
				<h2 class="lnkup-panel__title"><?php esc_html_e( 'Payments', 'lnkup-marketplace' ); ?></h2>
				<?php echo self::render_payments_dashboard( 'organizer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Opportunities feed shortcode.
	 */
	public static function render_opportunities_feed() {
		$city   = isset( $_GET['city'] ) ? sanitize_text_field( wp_unslash( $_GET['city'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$state  = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$apply  = isset( $_GET['apply'] ) ? absint( $_GET['apply'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$query_args = array(
			'post_type'      => 'lnkup_opportunity',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'meta_query'     => array(
				array( 'key' => '_lnkup_opportunity_status', 'value' => 'open' ),
			),
		);

		$opps = get_posts( $query_args );
		$items = array();

		foreach ( $opps as $opp ) {
			$formatted = lnkup_format_opportunity( $opp );
			if ( $city && stripos( $formatted['city'], $city ) === false ) {
				continue;
			}
			if ( $state && strtoupper( $formatted['state'] ) !== strtoupper( $state ) ) {
				continue;
			}
			$items[] = $formatted;
		}

		ob_start();
		?>
		<div class="lnkup-mp">
			<h1 class="lnkup-heading lnkup-heading--page"><?php esc_html_e( 'Find Events', 'lnkup-marketplace' ); ?></h1>
			<form class="lnkup-filters" method="get">
				<input type="text" name="city" placeholder="<?php esc_attr_e( 'City', 'lnkup-marketplace' ); ?>" value="<?php echo esc_attr( $city ); ?>" />
				<input type="text" name="state" placeholder="<?php esc_attr_e( 'State', 'lnkup-marketplace' ); ?>" value="<?php echo esc_attr( $state ); ?>" maxlength="2" />
				<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Filter', 'lnkup-marketplace' ); ?></button>
			</form>

			<?php if ( $apply ) : ?>
				<div class="lnkup-panel">
					<h2 class="lnkup-panel__title"><?php esc_html_e( 'Apply to Opportunity', 'lnkup-marketplace' ); ?></h2>
					<?php if ( is_user_logged_in() && LNKup_Roles::is_vendor() ) : ?>
						<form class="lnkup-form lnkup-apply-form" data-opportunity-id="<?php echo esc_attr( (string) $apply ); ?>">
							<?php wp_nonce_field( 'lnkup_apply', 'lnkup_nonce' ); ?>
							<input type="hidden" name="action" value="lnkup_apply" />
							<input type="hidden" name="opportunity_id" value="<?php echo esc_attr( (string) $apply ); ?>" />
							<div class="lnkup-form-row">
								<label for="apply_message"><?php esc_html_e( 'Message to organizer', 'lnkup-marketplace' ); ?></label>
								<textarea id="apply_message" name="message" rows="4"></textarea>
							</div>
							<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Submit Application (Free)', 'lnkup-marketplace' ); ?></button>
						</form>
					<?php else : ?>
						<p><?php esc_html_e( 'Please log in as a vendor to apply.', 'lnkup-marketplace' ); ?> <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>"><?php esc_html_e( 'Log in', 'lnkup-marketplace' ); ?></a></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="lnkup-event-grid">
				<?php if ( $items ) : ?>
					<?php foreach ( $items as $opp ) : ?>
						<?php echo lnkup_render_event_card( $opp ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endforeach; ?>
				<?php else : ?>
					<p class="lnkup-empty"><?php esc_html_e( 'No opportunities found.', 'lnkup-marketplace' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Vendor profile form shortcode.
	 */
	public static function render_vendor_profile_form() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_vendor() && ! current_user_can( 'lnkup_manage_all' ) ) {
			return '<p class="lnkup-alert lnkup-alert--error">' . esc_html__( 'Vendor access required.', 'lnkup-marketplace' ) . '</p>';
		}

		$profile_id = lnkup_get_vendor_profile_id( get_current_user_id() );
		$profile    = $profile_id ? get_post( $profile_id ) : null;
		$terms      = get_terms( array( 'taxonomy' => 'lnkup_vendor_category', 'hide_empty' => false ) );

		ob_start();
		?>
		<div class="lnkup-mp">
			<h1 class="lnkup-heading lnkup-heading--page"><?php esc_html_e( 'Vendor Profile', 'lnkup-marketplace' ); ?></h1>
			<form class="lnkup-form lnkup-profile-form">
				<?php wp_nonce_field( 'lnkup_profile', 'lnkup_nonce' ); ?>
				<input type="hidden" name="action" value="lnkup_save_profile" />
				<div class="lnkup-grid lnkup-grid--2">
					<div class="lnkup-form-row">
						<label for="business_name"><?php esc_html_e( 'Business Name', 'lnkup-marketplace' ); ?> *</label>
						<input type="text" id="business_name" name="business_name" required value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_business_name', true ) : '' ); ?>" />
					</div>
					<div class="lnkup-form-row">
						<label for="contact_email"><?php esc_html_e( 'Contact Email', 'lnkup-marketplace' ); ?></label>
						<input type="email" id="contact_email" name="contact_email" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_contact_email', true ) : '' ); ?>" />
					</div>
					<div class="lnkup-form-row">
						<label for="contact_phone"><?php esc_html_e( 'Contact Phone', 'lnkup-marketplace' ); ?></label>
						<input type="text" id="contact_phone" name="contact_phone" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_contact_phone', true ) : '' ); ?>" />
					</div>
					<div class="lnkup-form-row">
						<label for="city"><?php esc_html_e( 'City', 'lnkup-marketplace' ); ?></label>
						<input type="text" id="city" name="city" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_city', true ) : '' ); ?>" />
					</div>
					<div class="lnkup-form-row">
						<label for="state"><?php esc_html_e( 'State', 'lnkup-marketplace' ); ?></label>
						<input type="text" id="state" name="state" maxlength="2" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_state', true ) : '' ); ?>" />
					</div>
					<div class="lnkup-form-row">
						<label for="website"><?php esc_html_e( 'Website', 'lnkup-marketplace' ); ?></label>
						<input type="url" id="website" name="website" value="<?php echo esc_attr( $profile ? get_post_meta( $profile_id, '_lnkup_website', true ) : '' ); ?>" />
					</div>
				</div>
				<div class="lnkup-form-row">
					<label for="description"><?php esc_html_e( 'Description', 'lnkup-marketplace' ); ?></label>
					<textarea id="description" name="description" rows="5"><?php echo esc_textarea( $profile ? $profile->post_content : '' ); ?></textarea>
				</div>
				<div class="lnkup-form-row">
					<label><?php esc_html_e( 'Vendor Categories', 'lnkup-marketplace' ); ?></label>
					<div style="display:flex;flex-wrap:wrap;gap:0.5rem;">
						<?php
						$selected = $profile_id ? wp_get_post_terms( $profile_id, 'lnkup_vendor_category', array( 'fields' => 'names' ) ) : array();
						foreach ( $terms as $term ) :
							?>
							<label style="display:flex;align-items:center;gap:0.25rem;font-weight:400;">
								<input type="checkbox" name="categories[]" value="<?php echo esc_attr( $term->name ); ?>" <?php checked( in_array( $term->name, $selected, true ) ); ?> />
								<?php echo esc_html( $term->name ); ?>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
				<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Save Profile', 'lnkup-marketplace' ); ?></button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Organizer events shortcode.
	 */
	public static function render_organizer_events() {
		$user_id = get_current_user_id();
		$events  = get_posts(
			array(
				'post_type'      => 'lnkup_event',
				'posts_per_page' => -1,
				'meta_key'       => '_lnkup_organizer_user_id',
				'meta_value'     => $user_id,
			)
		);

		ob_start();
		if ( $events ) {
			echo '<table class="lnkup-table"><thead><tr><th>' . esc_html__( 'Event', 'lnkup-marketplace' ) . '</th><th>' . esc_html__( 'Date', 'lnkup-marketplace' ) . '</th><th>' . esc_html__( 'City', 'lnkup-marketplace' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $events as $event ) {
				$export_url = add_query_arg(
					array(
						'action'      => 'lnkup_export_vendors',
						'event_id'    => $event->ID,
						'lnkup_nonce' => wp_create_nonce( 'lnkup_export' ),
					),
					admin_url( 'admin-ajax.php' )
				);
				echo '<tr>';
				echo '<td>' . esc_html( $event->post_title ) . '</td>';
				echo '<td>' . esc_html( get_post_meta( $event->ID, '_lnkup_event_date', true ) ) . '</td>';
				echo '<td>' . esc_html( get_post_meta( $event->ID, '_lnkup_city', true ) . ', ' . get_post_meta( $event->ID, '_lnkup_state', true ) ) . '</td>';
				echo '<td><a href="' . esc_url( $export_url ) . '" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline">' . esc_html__( 'Export Vendors', 'lnkup-marketplace' ) . '</a></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p class="lnkup-empty">' . esc_html__( 'No events yet. Import or create one below.', 'lnkup-marketplace' ) . '</p>';
		}

		echo '<h3 style="margin-top:1.5rem;">' . esc_html__( 'Create Opportunity', 'lnkup-marketplace' ) . '</h3>';
		if ( $events ) {
			?>
			<form class="lnkup-form lnkup-opportunity-form">
				<?php wp_nonce_field( 'lnkup_opportunity', 'lnkup_nonce' ); ?>
				<input type="hidden" name="action" value="lnkup_create_opportunity" />
				<div class="lnkup-form-row">
					<label for="opp_event_id"><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></label>
					<select id="opp_event_id" name="event_id" required>
						<?php foreach ( $events as $event ) : ?>
							<option value="<?php echo esc_attr( (string) $event->ID ); ?>"><?php echo esc_html( $event->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="lnkup-grid lnkup-grid--2">
					<div class="lnkup-form-row">
						<label for="spots_total"><?php esc_html_e( 'Number of Spots', 'lnkup-marketplace' ); ?></label>
						<input type="number" id="spots_total" name="spots_total" min="1" value="10" required />
					</div>
					<div class="lnkup-form-row">
						<label for="vendor_fee"><?php esc_html_e( 'Vendor Fee ($)', 'lnkup-marketplace' ); ?></label>
						<input type="number" id="vendor_fee" name="vendor_fee" min="0" step="0.01" value="250" required />
					</div>
					<div class="lnkup-form-row">
						<label for="deadline"><?php esc_html_e( 'Application Deadline', 'lnkup-marketplace' ); ?></label>
						<input type="date" id="deadline" name="deadline" />
					</div>
				</div>
				<div class="lnkup-form-row">
					<label for="notes"><?php esc_html_e( 'Organizer Notes', 'lnkup-marketplace' ); ?></label>
					<textarea id="notes" name="notes" rows="3"></textarea>
				</div>
				<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Create Opportunity', 'lnkup-marketplace' ); ?></button>
			</form>
			<?php
		}
		return ob_get_clean();
	}

	/**
	 * Event import form.
	 */
	private static function render_event_import_form() {
		ob_start();
		?>
		<form class="lnkup-form lnkup-event-form">
			<?php wp_nonce_field( 'lnkup_event', 'lnkup_nonce' ); ?>
			<input type="hidden" name="action" value="lnkup_create_event" />
			<div class="lnkup-form-row">
				<label for="ticketing_url"><?php esc_html_e( 'Ticketing URL (Posh, Eventbrite, Universe)', 'lnkup-marketplace' ); ?></label>
				<input type="url" id="ticketing_url" name="ticketing_url" placeholder="https://" />
			</div>
			<div class="lnkup-grid lnkup-grid--2">
				<div class="lnkup-form-row">
					<label for="event_name"><?php esc_html_e( 'Event Name', 'lnkup-marketplace' ); ?> *</label>
					<input type="text" id="event_name" name="event_name" required />
				</div>
				<div class="lnkup-form-row">
					<label for="event_date"><?php esc_html_e( 'Event Date', 'lnkup-marketplace' ); ?></label>
					<input type="date" id="event_date" name="event_date" />
				</div>
				<div class="lnkup-form-row">
					<label for="event_city"><?php esc_html_e( 'City', 'lnkup-marketplace' ); ?></label>
					<input type="text" id="event_city" name="city" />
				</div>
				<div class="lnkup-form-row">
					<label for="event_state"><?php esc_html_e( 'State', 'lnkup-marketplace' ); ?></label>
					<input type="text" id="event_state" name="state" maxlength="2" />
				</div>
				<div class="lnkup-form-row">
					<label for="venue_name"><?php esc_html_e( 'Venue Name', 'lnkup-marketplace' ); ?></label>
					<input type="text" id="venue_name" name="venue_name" />
				</div>
				<div class="lnkup-form-row">
					<label for="expected_attendance"><?php esc_html_e( 'Expected Attendance', 'lnkup-marketplace' ); ?></label>
					<input type="number" id="expected_attendance" name="expected_attendance" min="0" />
				</div>
				<div class="lnkup-form-row">
					<label for="ticketing_platform"><?php esc_html_e( 'Ticketing Platform', 'lnkup-marketplace' ); ?></label>
					<select id="ticketing_platform" name="ticketing_platform">
						<option value="Posh">Posh</option>
						<option value="Eventbrite">Eventbrite</option>
						<option value="Universe">Universe</option>
						<option value="Manual">Manual</option>
					</select>
				</div>
				<div class="lnkup-form-row">
					<label for="event_type"><?php esc_html_e( 'Event Type', 'lnkup-marketplace' ); ?></label>
					<select id="event_type" name="event_type">
						<?php
						$types = get_terms( array( 'taxonomy' => 'lnkup_event_type', 'hide_empty' => false ) );
						foreach ( $types as $type ) {
							echo '<option value="' . esc_attr( $type->name ) . '">' . esc_html( $type->name ) . '</option>';
						}
						?>
					</select>
				</div>
			</div>
			<div class="lnkup-form-row">
				<label for="venue_address"><?php esc_html_e( 'Venue Address', 'lnkup-marketplace' ); ?></label>
				<textarea id="venue_address" name="venue_address" rows="2"></textarea>
			</div>
			<div class="lnkup-form-row">
				<label><input type="checkbox" name="venue_hidden" value="1" checked /> <?php esc_html_e( 'Hide venue address until vendor payment', 'lnkup-marketplace' ); ?></label>
			</div>
			<div class="lnkup-form-row">
				<label for="description"><?php esc_html_e( 'Description', 'lnkup-marketplace' ); ?></label>
				<textarea id="description" name="description" rows="4"></textarea>
			</div>
			<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Create Event', 'lnkup-marketplace' ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Applications manager shortcode.
	 */
	public static function render_applications_manager() {
		LNKup_Capabilities::require_login();
		if ( ! LNKup_Roles::is_organizer() && ! current_user_can( 'lnkup_manage_all' ) ) {
			return '';
		}

		$apps = lnkup_get_applications_for_user( get_current_user_id(), 'organizer' );

		ob_start();
		if ( ! $apps ) {
			echo '<p class="lnkup-empty">' . esc_html__( 'No applications yet.', 'lnkup-marketplace' ) . '</p>';
			return ob_get_clean();
		}
		?>
		<table class="lnkup-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Vendor', 'lnkup-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Event', 'lnkup-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Status', 'lnkup-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'lnkup-marketplace' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $apps as $app ) : ?>
				<?php
				$vendor_id = (int) get_post_meta( $app->ID, '_lnkup_vendor_user_id', true );
				$vendor    = get_userdata( $vendor_id );
				$event_id  = (int) get_post_meta( $app->ID, '_lnkup_event_id', true );
				$event     = $event_id ? get_post( $event_id ) : null;
				$status    = get_post_meta( $app->ID, '_lnkup_application_status', true );
				?>
				<tr>
					<td><?php echo esc_html( $vendor ? $vendor->display_name : '—' ); ?></td>
					<td><?php echo esc_html( $event ? $event->post_title : '—' ); ?></td>
					<td><span class="lnkup-status lnkup-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( str_replace( '_', ' ', $status ) ); ?></span></td>
					<td>
						<?php if ( in_array( $status, array( 'submitted', 'under_review', 'waitlisted' ), true ) ) : ?>
							<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary lnkup-review-btn" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="approve"><?php esc_html_e( 'Approve', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--outline lnkup-review-btn" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="waitlist"><?php esc_html_e( 'Waitlist', 'lnkup-marketplace' ); ?></button>
							<button type="button" class="lnkup-btn lnkup-btn--sm lnkup-review-btn" data-app-id="<?php echo esc_attr( (string) $app->ID ); ?>" data-action="reject"><?php esc_html_e( 'Reject', 'lnkup-marketplace' ); ?></button>
						<?php else : ?>
							—
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		return ob_get_clean();
	}

	/**
	 * Documents manager shortcode.
	 */
	public static function render_documents_manager() {
		LNKup_Capabilities::require_login();
		$docs   = LNKup_Documents::get_for_vendor( get_current_user_id() );
		$types  = LNKup_Documents::document_types();

		ob_start();
		?>
		<?php if ( $docs ) : ?>
			<table class="lnkup-table">
				<thead><tr><th><?php esc_html_e( 'Type', 'lnkup-marketplace' ); ?></th><th><?php esc_html_e( 'Status', 'lnkup-marketplace' ); ?></th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $docs as $doc ) : ?>
					<tr>
						<td><?php echo esc_html( $types[ get_post_meta( $doc->ID, '_lnkup_document_type', true ) ] ?? $doc->post_title ); ?></td>
						<td><?php echo esc_html( get_post_meta( $doc->ID, '_lnkup_verification_status', true ) ); ?></td>
						<td><a href="<?php echo esc_url( LNKup_Documents::download_url( $doc->ID ) ); ?>"><?php esc_html_e( 'Download', 'lnkup-marketplace' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<form class="lnkup-form lnkup-document-form" enctype="multipart/form-data" style="margin-top:1rem;">
			<?php wp_nonce_field( 'lnkup_document', 'lnkup_nonce' ); ?>
			<input type="hidden" name="action" value="lnkup_upload_document" />
			<div class="lnkup-grid lnkup-grid--2">
				<div class="lnkup-form-row">
					<label for="document_type"><?php esc_html_e( 'Document Type', 'lnkup-marketplace' ); ?></label>
					<select id="document_type" name="document_type" required>
						<?php foreach ( $types as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="lnkup-form-row">
					<label for="expiration_date"><?php esc_html_e( 'Expiration Date', 'lnkup-marketplace' ); ?></label>
					<input type="date" id="expiration_date" name="expiration_date" />
				</div>
			</div>
			<div class="lnkup-form-row">
				<label for="lnkup_document"><?php esc_html_e( 'File (PDF, JPG, PNG)', 'lnkup-marketplace' ); ?></label>
				<input type="file" id="lnkup_document" name="lnkup_document" accept=".pdf,.jpg,.jpeg,.png" required />
			</div>
			<button type="submit" class="lnkup-btn lnkup-btn--primary"><?php esc_html_e( 'Upload Document', 'lnkup-marketplace' ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Payments dashboard shortcode.
	 *
	 * @param string $role vendor|organizer.
	 */
	public static function render_payments_dashboard( $role = 'vendor' ) {
		LNKup_Capabilities::require_login();
		$payments = lnkup_get_payments_for_user( get_current_user_id(), $role );

		ob_start();
		if ( ! $payments ) {
			echo '<p class="lnkup-empty">' . esc_html__( 'No payments yet.', 'lnkup-marketplace' ) . '</p>';
			return ob_get_clean();
		}
		?>
		<table class="lnkup-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Description', 'lnkup-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Amount', 'lnkup-marketplace' ); ?></th>
					<th><?php esc_html_e( 'Status', 'lnkup-marketplace' ); ?></th>
					<?php if ( 'vendor' === $role ) : ?><th></th><?php endif; ?>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $payments as $payment ) : ?>
				<tr>
					<td><?php echo esc_html( $payment->post_title ); ?></td>
					<td><?php echo esc_html( lnkup_currency( get_post_meta( $payment->ID, '_lnkup_total_amount', true ) ) ); ?></td>
					<td><?php echo esc_html( get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ); ?></td>
					<?php if ( 'vendor' === $role && 'pending' === get_post_meta( $payment->ID, '_lnkup_payment_status', true ) ) : ?>
						<td><button type="button" class="lnkup-btn lnkup-btn--sm lnkup-btn--primary lnkup-pay-btn" data-payment-id="<?php echo esc_attr( (string) $payment->ID ); ?>"><?php esc_html_e( 'Pay', 'lnkup-marketplace' ); ?></button></td>
					<?php elseif ( 'vendor' === $role ) : ?>
						<td></td>
					<?php endif; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		return ob_get_clean();
	}
}
