(function () {
  function postForm(form) {
    var data = new FormData(form);
    if (!data.get('lnkup_nonce') && window.lnkupAjax) {
      data.append('lnkup_nonce', window.lnkupAjax.nonce);
    }
    return fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
      .then(function (r) { return r.json(); });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.classList.contains('lnkup-profile-form') &&
        !form.classList.contains('lnkup-apply-form') &&
        !form.classList.contains('lnkup-event-form') &&
        !form.classList.contains('lnkup-opportunity-form')) {
      if (form.classList.contains('lnkup-document-form')) {
        e.preventDefault();
        postForm(form).then(function (res) {
          alert(res.success ? res.data.message : res.data.message);
          if (res.success) location.reload();
        });
      }
      return;
    }
    e.preventDefault();
    postForm(form).then(function (res) {
      alert(res.success ? res.data.message : res.data.message);
      if (res.success) location.reload();
    });
  });

  document.addEventListener('click', function (e) {
    var payBtn = e.target.closest('.lnkup-pay-btn');
    if (payBtn) {
      var paymentId = payBtn.getAttribute('data-payment-id');
      var data = new FormData();
      data.append('action', 'lnkup_create_checkout');
      data.append('payment_id', paymentId);
      data.append('lnkup_nonce', window.lnkupAjax.nonce);
      fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res.success && res.data.url) {
            window.location.href = res.data.url;
          } else {
            alert(res.data && res.data.message ? res.data.message : 'Payment error');
          }
        });
    }

    var reviewBtn = e.target.closest('.lnkup-review-btn');
    if (reviewBtn) {
      var appId = reviewBtn.getAttribute('data-app-id');
      var action = reviewBtn.getAttribute('data-action');
      var data = new FormData();
      data.append('action', 'lnkup_review_application');
      data.append('application_id', appId);
      data.append('review_action', action);
      data.append('lnkup_nonce', window.lnkupAjax.nonce);
      if (action === 'reject') {
        var reason = prompt('Rejection reason (optional):');
        if (reason) data.append('rejection_reason', reason);
      }
      fetch(window.lnkupAjax.url, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          alert(res.success ? res.data.message : res.data.message);
          if (res.success) location.reload();
        });
    }
  });
})();
