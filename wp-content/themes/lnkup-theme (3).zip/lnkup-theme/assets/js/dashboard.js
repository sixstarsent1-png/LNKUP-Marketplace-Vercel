document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.getElementById('lnkup-menu-toggle');
  var sidebar = document.getElementById('lnkup-sidebar');
  var overlay = document.getElementById('lnkup-sidebar-overlay');

  function setSidebarOpen(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('is-open', open);
    if (overlay) overlay.hidden = !open;
    document.body.classList.toggle('lnkup-sidebar-open', open);
  }

  if (toggle && sidebar) {
    toggle.addEventListener('click', function () {
      setSidebarOpen(!sidebar.classList.contains('is-open'));
    });
  }

  if (overlay) {
    overlay.addEventListener('click', function () {
      setSidebarOpen(false);
    });
  }

  /**
   * Highlight nav for hash anchors (organizer).
   */
  function syncHashNav() {
    var hash = (window.location.hash || '').replace(/^#/, '');
    document.querySelectorAll('.lnkup-dashboard__nav-link[data-hash]').forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('data-hash') === hash);
    });
    document.querySelectorAll('.lnkup-dashboard__nav-link:not([data-hash])').forEach(function (link) {
      if (link.href && link.href.indexOf('organizer-dashboard') > -1 && link.href.indexOf('#') === -1) {
        link.classList.toggle('is-active', !hash);
      }
    });
  }

  /**
   * Highlight nav for vendor ?view= param.
   */
  function syncViewNav() {
    var params = new URLSearchParams(window.location.search);
    var view = params.get('view') || '';
    var path = window.location.pathname;

    document.querySelectorAll('.lnkup-dashboard__nav-link').forEach(function (link) {
      link.classList.remove('is-active');
    });

    document.querySelectorAll('.lnkup-dashboard__nav-link[data-view]').forEach(function (link) {
      var linkView = link.getAttribute('data-view') || '';
      if (linkView && linkView === view && path.indexOf('vendor-dashboard') > -1) {
        link.classList.add('is-active');
      }
    });

    var homeLink = document.querySelector('.lnkup-dashboard__nav-link[href*="vendor-dashboard"]:not([data-view])');
    if (homeLink && path.indexOf('vendor-dashboard') > -1 && !view) {
      homeLink.classList.add('is-active');
    }

    if (path.indexOf('opportunities') > -1) {
      document.querySelectorAll('.lnkup-dashboard__nav-link[href*="opportunities"]').forEach(function (link) {
        link.classList.add('is-active');
      });
    }

    if (path.indexOf('vendor-profile') > -1) {
      document.querySelectorAll('.lnkup-dashboard__nav-link[href*="vendor-profile"]').forEach(function (link) {
        link.classList.add('is-active');
      });
    }
  }

  window.addEventListener('hashchange', syncHashNav);
  syncHashNav();
  syncViewNav();

  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var id = anchor.getAttribute('href');
      if (!id || id === '#') return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (sidebar && sidebar.classList.contains('is-open')) setSidebarOpen(false);
      }
    });
  });

  /**
   * Application table tabs.
   */
  document.querySelectorAll('[data-app-tab]').forEach(function (btn) {
    if (btn.tagName !== 'BUTTON') return;
    btn.addEventListener('click', function () {
      var tab = btn.getAttribute('data-app-tab');
      document.querySelectorAll('.lnkup-dash-tabs__btn').forEach(function (b) {
        b.classList.toggle('is-active', b === btn);
      });
      document.querySelectorAll('#lnkup-vendor-apps-table tbody tr').forEach(function (row) {
        var rowTab = row.getAttribute('data-app-tab');
        var show = tab === 'all' || rowTab === tab;
        row.hidden = !show;
      });
    });
  });

  /**
   * Document card upload triggers.
   */
  document.querySelectorAll('[data-doc-upload]').forEach(function (trigger) {
    trigger.addEventListener('click', function () {
      var type = trigger.getAttribute('data-doc-upload');
      var form = document.getElementById('lnkup-document-upload-form');
      if (!form) return;
      var select = form.querySelector('#document_type');
      var file = form.querySelector('#lnkup_document');
      if (select && type) select.value = type;
      if (file) file.click();
    });
  });

  var docFile = document.getElementById('lnkup_document');
  if (docFile) {
    docFile.addEventListener('change', function () {
      if (docFile.files && docFile.files.length) {
        var form = document.getElementById('lnkup-document-upload-form');
        if (form) form.requestSubmit();
      }
    });
  }
});
