<?php
/**
 * Template tags and helpers.
 *
 * @package LNKup_Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render the LNKup logo.
 *
 * @param bool $show_wordmark Whether to show wordmark.
 */
function lnkup_logo( $show_wordmark = true ) {
	?>
	<span class="lnkup-logo">
		<span class="lnkup-logo__mark" aria-hidden="true">
			<svg viewBox="0 0 24 24" fill="none" class="lnkup-logo__icon">
				<path d="M7 13.5 12 8l5 5.5M5 17l3.5-4M19 17l-3.5-4" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
			</svg>
		</span>
		<?php if ( $show_wordmark ) : ?>
			<span class="lnkup-logo__text">LNKup</span>
		<?php endif; ?>
	</span>
	<?php
}

/**
 * Get a theme asset URL.
 *
 * @param string $path Relative path from assets/.
 */
function lnkup_theme_asset( $path ) {
	return LNKUP_THEME_URI . '/assets/' . ltrim( $path, '/' );
}

/**
 * Get page URL by slug with fallback.
 *
 * @param string $slug Page slug.
 */
function lnkup_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Check if current page uses a dashboard template.
 */
function lnkup_theme_is_dashboard_page() {
	if ( ! is_page() ) {
		return false;
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	if ( in_array(
		$slug,
		array( 'vendor-dashboard', 'organizer-dashboard', 'opportunities', 'vendor-profile' ),
		true
	) ) {
		return true;
	}
	$template = get_page_template_slug();
	return in_array(
		$template,
		array(
			'page-templates/vendor-dashboard.php',
			'page-templates/vendor-shell.php',
			'page-templates/organizer-dashboard.php',
		),
		true
	);
}

/**
 * Output a button link.
 *
 * @param string $url    URL.
 * @param string $label  Label.
 * @param string $class  CSS classes.
 */
function lnkup_button_link( $url, $label, $class = 'lnkup-btn lnkup-btn--primary' ) {
	printf(
		'<a href="%s" class="%s">%s</a>',
		esc_url( $url ),
		esc_attr( $class ),
		esc_html( $label )
	);
}

/**
 * Ensure inline SVG icons have explicit dimensions.
 *
 * @param string $svg  SVG markup.
 * @param int    $size Width and height in pixels.
 */
function lnkup_inline_icon( $svg, $size = 18 ) {
	if ( false !== strpos( $svg, 'width=' ) ) {
		return $svg;
	}
	return preg_replace( '/<svg\s/', '<svg width="' . (int) $size . '" height="' . (int) $size . '" ', $svg, 1 );
}
