<?php
/**
 * Hero section partial.
 *
 * @package LNKup_Theme
 */

$opportunities_url = lnkup_page_url( 'opportunities' );
$profile_url       = lnkup_page_url( 'vendor-profile' );
$hero_image        = lnkup_theme_asset( 'images/events/block-party.svg' );
?>
<section class="lnkup-hero">
	<div class="lnkup-hero__glow" aria-hidden="true"></div>
	<div class="lnkup-container lnkup-hero__grid">
		<div class="lnkup-hero__content">
			<span class="lnkup-pill">
				<span class="lnkup-pill__dot"></span>
				<?php esc_html_e( 'The opportunity network for live events', 'lnkup-theme' ); ?>
			</span>
			<h1 class="lnkup-heading lnkup-heading--hero"><?php esc_html_e( 'Find Your Next Event', 'lnkup-theme' ); ?></h1>
			<p class="lnkup-hero__lead">
				<?php esc_html_e( 'LNKup helps vendors discover festivals, rodeos, block parties, homecomings, markets, food festivals, and cultural events.', 'lnkup-theme' ); ?>
			</p>
			<div class="lnkup-hero__cta">
				<a href="<?php echo esc_url( $opportunities_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--lg"><?php esc_html_e( 'Find Events', 'lnkup-theme' ); ?></a>
				<a href="<?php echo esc_url( $profile_url ); ?>" class="lnkup-btn lnkup-btn--outline lnkup-btn--lg"><?php esc_html_e( 'List My Business', 'lnkup-theme' ); ?></a>
			</div>
			<ul class="lnkup-hero__trust-list">
				<li><?php esc_html_e( 'Free to join & apply', 'lnkup-theme' ); ?></li>
				<li><?php esc_html_e( 'Pay only when accepted', 'lnkup-theme' ); ?></li>
				<li><?php esc_html_e( 'Events in 40+ cities', 'lnkup-theme' ); ?></li>
			</ul>
		</div>
		<div class="lnkup-hero__visual">
			<div class="lnkup-hero__image-wrap">
				<img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php esc_attr_e( 'Vibrant outdoor block party with vendor booths', 'lnkup-theme' ); ?>" width="720" height="560" loading="eager" />
			</div>
			<div class="lnkup-hero__card lnkup-hero__card--opportunity">
				<p class="lnkup-hero__card-label"><?php esc_html_e( 'New opportunity', 'lnkup-theme' ); ?></p>
				<p class="lnkup-hero__card-title"><?php esc_html_e( 'Soul District Block Party', 'lnkup-theme' ); ?></p>
				<div class="lnkup-hero__card-meta">
					<span>Atlanta, GA</span>
					<span class="lnkup-badge lnkup-badge--accent">12 spots left</span>
				</div>
			</div>
			<div class="lnkup-hero__card lnkup-hero__card--stat">
				<p class="lnkup-hero__stat">4,800+</p>
				<p class="lnkup-hero__card-label"><?php esc_html_e( 'active vendors', 'lnkup-theme' ); ?></p>
			</div>
		</div>
	</div>
</section>
