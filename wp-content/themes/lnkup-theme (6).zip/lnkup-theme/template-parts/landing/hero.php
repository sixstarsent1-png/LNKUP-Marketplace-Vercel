<?php
/**
 * Hero section partial.
 *
 * @package LNKup_Theme
 */

$signup_url       = lnkup_theme_registration_url();
$opportunities_url = lnkup_page_url( 'opportunities' );
$profile_url      = lnkup_page_url( 'vendor-profile' );
$hero_image       = lnkup_theme_asset( 'images/events/block-party.svg' );
$launch_label     = lnkup_theme_launch_label();
$marketplace_open = lnkup_theme_marketplace_open();
$primary_url      = is_user_logged_in() ? $profile_url : $signup_url;
$primary_label    = is_user_logged_in() ? __( 'Complete your profile', 'lnkup-theme' ) : __( 'Create free account', 'lnkup-theme' );
?>
<section class="lnkup-hero lnkup-reveal">
	<div class="lnkup-hero__glow" aria-hidden="true"></div>
	<div class="lnkup-container lnkup-hero__grid">
		<div class="lnkup-hero__content">
			<?php if ( ! $marketplace_open && $launch_label ) : ?>
				<span class="lnkup-pill lnkup-pill--launch" data-testid="lnkup-hero-launch-pill">
					<span class="lnkup-pill__dot"></span>
					<?php echo esc_html( sprintf( __( 'Launching %s', 'lnkup-theme' ), $launch_label ) ); ?>
				</span>
			<?php else : ?>
				<span class="lnkup-pill">
					<span class="lnkup-pill__dot"></span>
					<?php esc_html_e( 'The opportunity network for live events', 'lnkup-theme' ); ?>
				</span>
			<?php endif; ?>
			<h1 class="lnkup-heading lnkup-heading--hero"><?php esc_html_e( 'Find Your Next Event', 'lnkup-theme' ); ?></h1>
			<p class="lnkup-hero__lead">
				<?php esc_html_e( 'LNKup helps vendors discover festivals, rodeos, block parties, homecomings, markets, food festivals, and cultural events.', 'lnkup-theme' ); ?>
			</p>
			<?php if ( ! $marketplace_open ) : ?>
				<p class="lnkup-hero__sublead"><?php echo esc_html( $launch_label ? sprintf( __( 'Create your free account today. Browse and apply when we launch %s.', 'lnkup-theme' ), $launch_label ) : __( 'Create your free account today. Browse and apply at launch.', 'lnkup-theme' ) ); ?></p>
			<?php endif; ?>
			<div class="lnkup-hero__cta">
				<a href="<?php echo esc_url( $primary_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--lg" data-testid="lnkup-hero-cta-primary">
					<?php echo esc_html( $primary_label ); ?>
					<svg class="lnkup-btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
				</a>
				<?php if ( $marketplace_open ) : ?>
					<a href="<?php echo esc_url( $opportunities_url ); ?>" class="lnkup-btn lnkup-btn--outline lnkup-btn--lg"><?php esc_html_e( 'Find Events', 'lnkup-theme' ); ?></a>
				<?php else : ?>
					<a href="#how-it-works" class="lnkup-btn lnkup-btn--outline lnkup-btn--lg"><?php esc_html_e( 'How it works', 'lnkup-theme' ); ?></a>
				<?php endif; ?>
			</div>
			<ul class="lnkup-hero__trust-list">
				<li>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 12 11 14 15 10"/><circle cx="12" cy="12" r="9"/></svg>
					<?php esc_html_e( 'Free to join & apply', 'lnkup-theme' ); ?>
				</li>
				<li>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m12 2 3 7h7l-5.5 4 2 7-6.5-4.5L5.5 20l2-7L2 9h7z"/></svg>
					<?php esc_html_e( 'Pay only when accepted', 'lnkup-theme' ); ?>
				</li>
				<li>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 21s7-4.5 7-11a7 7 0 1 0-14 0c0 6.5 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/></svg>
					<?php esc_html_e( 'Events in 40+ cities', 'lnkup-theme' ); ?>
				</li>
			</ul>
		</div>
		<div class="lnkup-hero__visual">
			<div class="lnkup-hero__image-wrap">
				<img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php esc_attr_e( 'Vibrant outdoor block party with vendor booths', 'lnkup-theme' ); ?>" width="720" height="560" loading="eager" />
			</div>
			<div class="lnkup-hero__card lnkup-hero__card--opportunity">
				<p class="lnkup-hero__card-label"><?php esc_html_e( 'New opportunity', 'lnkup-theme' ); ?></p>
				<p class="lnkup-hero__card-title"><?php esc_html_e( 'Soul District Block Party', 'lnkup-theme' ); ?></p>
				<div class="lnkup-hero__card-meta">
					<span>Atlanta, GA</span>
					<span class="lnkup-badge lnkup-badge--accent">12 spots left</span>
				</div>
			</div>
			<div class="lnkup-hero__card lnkup-hero__card--stat">
				<p class="lnkup-hero__stat">4,800+</p>
				<p class="lnkup-hero__card-label"><?php esc_html_e( 'active vendors', 'lnkup-theme' ); ?></p>
			</div>
		</div>
	</div>
</section>
