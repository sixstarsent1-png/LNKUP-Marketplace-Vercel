document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.getElementById('lnkup-menu-toggle');
  var sidebar = document.getElementById('lnkup-sidebar');
  if (toggle && sidebar) {
    toggle.addEventListener('click', function () {
      sidebar.classList.toggle('is-open');
    });
  }
});
