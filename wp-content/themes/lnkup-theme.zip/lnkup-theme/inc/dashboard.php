<?php
/**
 * Dashboard access control and shell helpers.
 *
 * @package LNKup_Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Require login for dashboard pages.
 */
function lnkup_require_login() {
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( wp_login_url( get_permalink() ) );
		exit;
	}
}

/**
 * Require one of the given roles.
 *
 * @param array $roles Role slugs.
 */
function lnkup_require_roles( array $roles ) {
	lnkup_require_login();
	$user = wp_get_current_user();
	if ( ! array_intersect( $roles, (array) $user->roles ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'lnkup-theme' ), 403 );
	}
}

/**
 * Get dashboard nav items for a role.
 *
 * @param string $role vendor|organizer.
 */
function lnkup_get_dashboard_nav( $role ) {
	if ( 'vendor' === $role ) {
		return array(
			array( 'label' => __( 'Overview', 'lnkup-theme' ), 'href' => lnkup_page_url( 'vendor-dashboard' ), 'slug' => 'vendor-dashboard' ),
			array( 'label' => __( 'Find Events', 'lnkup-theme' ), 'href' => lnkup_page_url( 'opportunities' ), 'slug' => 'opportunities' ),
			array( 'label' => __( 'Applications', 'lnkup-theme' ), 'href' => lnkup_page_url( 'vendor-dashboard' ) . '#applications', 'slug' => 'applications' ),
			array( 'label' => __( 'Profile', 'lnkup-theme' ), 'href' => lnkup_page_url( 'vendor-profile' ), 'slug' => 'vendor-profile' ),
			array( 'label' => __( 'Documents', 'lnkup-theme' ), 'href' => lnkup_page_url( 'vendor-dashboard' ) . '#documents', 'slug' => 'documents' ),
			array( 'label' => __( 'Payments', 'lnkup-theme' ), 'href' => lnkup_page_url( 'vendor-dashboard' ) . '#payments', 'slug' => 'payments' ),
		);
	}

	return array(
		array( 'label' => __( 'Overview', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ), 'slug' => 'organizer-dashboard' ),
		array( 'label' => __( 'Events', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ) . '#events', 'slug' => 'events' ),
		array( 'label' => __( 'Import Event', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ) . '#import', 'slug' => 'import' ),
		array( 'label' => __( 'Applications', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ) . '#applications', 'slug' => 'applications' ),
		array( 'label' => __( 'Vendors', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ) . '#vendors', 'slug' => 'vendors' ),
		array( 'label' => __( 'Payments', 'lnkup-theme' ), 'href' => lnkup_page_url( 'organizer-dashboard' ) . '#payments', 'slug' => 'payments' ),
	);
}

/**
 * Render dashboard shell opening markup.
 *
 * @param string $role    vendor|organizer.
 * @param string $title   Page title.
 */
function lnkup_dashboard_shell_open( $role, $title ) {
	$nav   = lnkup_get_dashboard_nav( $role );
	$user  = wp_get_current_user();
	$active_slug = get_post_field( 'post_name', get_queried_object_id() );
	?>
	<div class="lnkup-dashboard">
		<aside class="lnkup-dashboard__sidebar" id="lnkup-sidebar">
			<div class="lnkup-dashboard__brand">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php lnkup_logo(); ?></a>
			</div>
			<nav class="lnkup-dashboard__nav">
				<?php foreach ( $nav as $item ) : ?>
					<?php
					$active = ( $active_slug === $item['slug'] ) || ( isset( $_GET['section'] ) && $_GET['section'] === $item['slug'] );
					?>
					<a href="<?php echo esc_url( $item['href'] ); ?>" class="lnkup-dashboard__nav-link<?php echo $active ? ' is-active' : ''; ?>">
						<?php echo esc_html( $item['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>
			<div class="lnkup-dashboard__user">
				<span class="lnkup-dashboard__user-name"><?php echo esc_html( $user->display_name ); ?></span>
				<span class="lnkup-dashboard__user-role"><?php echo esc_html( ucfirst( $role ) ); ?></span>
			</div>
		</aside>
		<div class="lnkup-dashboard__main">
			<header class="lnkup-dashboard__header">
				<button type="button" class="lnkup-dashboard__menu-toggle" id="lnkup-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'lnkup-theme' ); ?>">
					<span></span><span></span><span></span>
				</button>
				<h1 class="lnkup-dashboard__title"><?php echo esc_html( $title ); ?></h1>
				<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="lnkup-btn lnkup-btn--ghost lnkup-btn--sm"><?php esc_html_e( 'Log out', 'lnkup-theme' ); ?></a>
			</header>
			<div class="lnkup-dashboard__content">
	<?php
}

/**
 * Render dashboard shell closing markup.
 */
function lnkup_dashboard_shell_close() {
	?>
			</div>
		</div>
	</div>
	<?php
}
