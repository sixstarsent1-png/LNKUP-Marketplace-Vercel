<?php
/**
 * Vendor dashboard page template.
 *
 * Template Name: Vendor Dashboard
 *
 * @package LNKup_Theme
 */

lnkup_require_roles( array( 'lnkup_vendor', 'lnkup_admin', 'administrator' ) );

get_header();
lnkup_dashboard_shell_open( 'vendor', __( 'Vendor Dashboard', 'lnkup-theme' ) );
echo do_shortcode( '[lnkup_vendor_dashboard]' );
lnkup_dashboard_shell_close();
get_footer();
