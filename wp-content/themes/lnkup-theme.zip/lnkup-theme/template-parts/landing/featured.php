<?php
/**
 * Featured opportunities section.
 *
 * @package LNKup_Theme
 */

$opportunities_url = lnkup_page_url( 'opportunities' );

if ( function_exists( 'lnkup_get_featured_opportunities' ) ) {
	$featured = lnkup_get_featured_opportunities( 6 );
} else {
	$featured = array();
}
?>
<section id="opportunities" class="lnkup-section lnkup-section--muted lnkup-section--bordered">
	<div class="lnkup-container">
		<div class="lnkup-section__header-row">
			<div class="lnkup-section__intro">
				<p class="lnkup-eyebrow"><?php esc_html_e( 'Featured opportunities', 'lnkup-theme' ); ?></p>
				<h2 class="lnkup-heading lnkup-heading--section"><?php esc_html_e( 'Events booking vendors right now', 'lnkup-theme' ); ?></h2>
			</div>
			<a href="<?php echo esc_url( $opportunities_url ); ?>" class="lnkup-btn lnkup-btn--outline"><?php esc_html_e( 'View all events', 'lnkup-theme' ); ?></a>
		</div>
		<div class="lnkup-event-grid">
			<?php if ( ! empty( $featured ) ) : ?>
				<?php foreach ( $featured as $opp ) : ?>
					<?php echo lnkup_render_event_card( $opp ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endforeach; ?>
			<?php else : ?>
				<?php
				$fallback = array(
					array( 'name' => 'Dirty South Rodeo Charlotte', 'city' => 'Charlotte', 'state' => 'NC', 'fee' => 250, 'spots' => 6, 'total' => 40, 'image' => 'rodeo.svg' ),
					array( 'name' => 'Soul District Block Party', 'city' => 'Atlanta', 'state' => 'GA', 'fee' => 180, 'spots' => 12, 'total' => 50, 'image' => 'block-party.svg' ),
					array( 'name' => 'Sunset & Soul Miami', 'city' => 'Miami', 'state' => 'FL', 'fee' => 400, 'spots' => 3, 'total' => 35, 'image' => 'sunset-miami.svg' ),
				);
				foreach ( $fallback as $event ) :
					?>
					<article class="lnkup-event-card">
						<div class="lnkup-event-card__media">
							<img src="<?php echo esc_url( lnkup_theme_asset( 'images/events/' . $event['image'] ) ); ?>" alt="<?php echo esc_attr( $event['name'] ); ?>" />
							<span class="lnkup-badge">$<?php echo esc_html( (string) $event['fee'] ); ?> vendor fee</span>
						</div>
						<div class="lnkup-event-card__body">
							<h3><?php echo esc_html( $event['name'] ); ?></h3>
							<p><?php echo esc_html( $event['city'] . ', ' . $event['state'] ); ?></p>
							<a href="<?php echo esc_url( $opportunities_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--sm"><?php esc_html_e( 'Apply', 'lnkup-theme' ); ?></a>
						</div>
					</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
