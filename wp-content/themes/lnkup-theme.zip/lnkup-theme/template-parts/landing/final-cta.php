<?php
/**
 * Final CTA section.
 *
 * @package LNKup_Theme
 */

$opportunities_url = lnkup_page_url( 'opportunities' );
$profile_url       = lnkup_page_url( 'vendor-profile' );
?>
<section class="lnkup-section lnkup-section--cta">
	<div class="lnkup-container">
		<div class="lnkup-cta-banner">
			<h2 class="lnkup-heading lnkup-heading--section"><?php esc_html_e( 'Ready to link up with your next event?', 'lnkup-theme' ); ?></h2>
			<p><?php esc_html_e( 'Create your vendor profile, browse opportunities, and apply for free. Pay only when an organizer accepts you.', 'lnkup-theme' ); ?></p>
			<div class="lnkup-hero__cta">
				<a href="<?php echo esc_url( $opportunities_url ); ?>" class="lnkup-btn lnkup-btn--primary lnkup-btn--lg"><?php esc_html_e( 'Find Events', 'lnkup-theme' ); ?></a>
				<a href="<?php echo esc_url( $profile_url ); ?>" class="lnkup-btn lnkup-btn--outline lnkup-btn--lg lnkup-btn--on-dark"><?php esc_html_e( 'List My Business', 'lnkup-theme' ); ?></a>
			</div>
		</div>
	</div>
</section>
