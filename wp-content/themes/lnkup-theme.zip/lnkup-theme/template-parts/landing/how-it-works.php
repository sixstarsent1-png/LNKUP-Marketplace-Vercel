<?php
/**
 * How it works section.
 *
 * @package LNKup_Theme
 */

$steps = array(
	array(
		'title' => __( 'Create your vendor profile', 'lnkup-theme' ),
		'desc'  => __( 'Build a profile that shows organizers who you are, what you sell, and where you set up.', 'lnkup-theme' ),
	),
	array(
		'title' => __( 'Browse event opportunities', 'lnkup-theme' ),
		'desc'  => __( 'Filter by city, date, attendance, and vendor fee to find events that fit your business.', 'lnkup-theme' ),
	),
	array(
		'title' => __( 'Apply for free', 'lnkup-theme' ),
		'desc'  => __( 'Submit applications to as many events as you want — applying never costs a thing.', 'lnkup-theme' ),
	),
	array(
		'title' => __( 'Pay only when accepted', 'lnkup-theme' ),
		'desc'  => __( 'No upfront fees. You only pay your vendor spot once an organizer approves you.', 'lnkup-theme' ),
	),
);
?>
<section id="how-it-works" class="lnkup-section lnkup-section--muted lnkup-section--bordered">
	<div class="lnkup-container">
		<div class="lnkup-section__intro">
			<p class="lnkup-eyebrow"><?php esc_html_e( 'How it works', 'lnkup-theme' ); ?></p>
			<h2 class="lnkup-heading lnkup-heading--section"><?php esc_html_e( 'From profile to paid in four steps', 'lnkup-theme' ); ?></h2>
		</div>
		<ol class="lnkup-steps">
			<?php foreach ( $steps as $i => $step ) : ?>
				<li class="lnkup-card lnkup-step">
					<div class="lnkup-step__top">
						<span class="lnkup-step__icon"><?php echo esc_html( $i + 1 ); ?></span>
						<span class="lnkup-step__number">0<?php echo esc_html( (string) ( $i + 1 ) ); ?></span>
					</div>
					<h3 class="lnkup-step__title"><?php echo esc_html( $step['title'] ); ?></h3>
					<p class="lnkup-step__desc"><?php echo esc_html( $step['desc'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
