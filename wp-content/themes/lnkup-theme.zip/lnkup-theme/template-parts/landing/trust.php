<?php
/**
 * Trust section.
 *
 * @package LNKup_Theme
 */
?>
<section class="lnkup-section">
	<div class="lnkup-container">
		<div class="lnkup-trust">
			<div class="lnkup-trust__intro">
				<p class="lnkup-eyebrow"><?php esc_html_e( 'Trusted by vendors', 'lnkup-theme' ); ?></p>
				<h2 class="lnkup-heading lnkup-heading--section"><?php esc_html_e( 'Built for the live event economy', 'lnkup-theme' ); ?></h2>
				<p class="lnkup-trust__lead"><?php esc_html_e( 'LNKup is strictly the vendor opportunity layer — not ticketing. Organizers keep selling tickets on Posh, Eventbrite, and Universe while vendors find and book spots through LNKup.', 'lnkup-theme' ); ?></p>
			</div>
			<div class="lnkup-trust__stats">
				<div class="lnkup-stat-card">
					<p class="lnkup-stat-card__value">4,800+</p>
					<p class="lnkup-stat-card__label"><?php esc_html_e( 'Active vendors', 'lnkup-theme' ); ?></p>
				</div>
				<div class="lnkup-stat-card">
					<p class="lnkup-stat-card__value">$2.4M</p>
					<p class="lnkup-stat-card__label"><?php esc_html_e( 'Vendor bookings', 'lnkup-theme' ); ?></p>
				</div>
				<div class="lnkup-stat-card">
					<p class="lnkup-stat-card__value">40+</p>
					<p class="lnkup-stat-card__label"><?php esc_html_e( 'Cities', 'lnkup-theme' ); ?></p>
				</div>
				<div class="lnkup-stat-card">
					<p class="lnkup-stat-card__value">98%</p>
					<p class="lnkup-stat-card__label"><?php esc_html_e( 'Vendor satisfaction', 'lnkup-theme' ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>
